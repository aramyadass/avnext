package CampaignPortal_Auto;

public class LocType {
	
	static public String id="id";
	static public String name="name";
	static public String className="className";
	static public String xpath="xpath";
	static public String cssSelector="cssSelector";
	static public String linkText="linkText";
	static public String partialLinkText="partialLinkText";
	static public String tagName="tagName";

}
