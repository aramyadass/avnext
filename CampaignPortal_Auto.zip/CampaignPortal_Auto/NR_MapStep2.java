package CampaignPortal_Auto;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Auto.BaseClass;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.PagesScomo;
import CampaignPortal_Pages.Pages_MapCampaign;

public class NR_MapStep2 extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\TestData1.xlsx";
	String b = "window.open('"+getProperty("AdminPortal")+"','_blank')";
	@Test(priority = 0)
	
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(3000);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
		pause(3000);
	}
	

	@Test(priority=2)  
	public void MapStep2_1039292() throws IOException, InterruptedException {
		
		String Step2campaignName=excel(file, 1, 8, 1)+getTimeStamp();
		btnClick(Pages1.New, "New");
		pause(2000);
		enterText(Pages1.Campaign_Title,"Campaign_Title", Step2campaignName);
		pause(2000);
		selectDropdown(Pages1.SelectBrand, "SelectBrand", "RENAULT");
		pause(2000);
		selectDropdown(Pages1.SelectCampaignType,"Map campaign", "Automatic Map Update");
		pause(5000);
		selectDropdown(Pages_MapCampaign.MapStep2, "MapStep2", "Step 2");
		btnClick(Pages_MapCampaign.MapStep2SelectEcu,"MapStep2SelectEcu");	
		btnClick(Pages_MapCampaign.MapStep2AddAll,"MapStep2AddAll");	
		pause(2000);
		enterText(Pages1.Campaign_Vin, "VIN =VF1SYMMPU170NA446", "where c.vin ='VF1SYMMPU170NA446'");
		pause(3000);
		btnClick(PagesScomo.ExecutionSettings,"ExecutionSettings");
	    selectDropdown(Pages1.FOTA_type,"Fota type = SILENT","SILENT");
	    btnClick(Pages1.Save_Campaign, "Save_Campaign");
		
		pause(10000);
		pause(7000);
		childTest.log(Status.PASS, "Create Campaign Passed");
		
		pause(20000);	
		btnClick("//*[@data-campname='"+Step2campaignName+"']","Campaign Name");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign,"Run campaign");
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		CompareText("//td[.='"+Step2campaignName+"']//following-sibling::td[7]/label","Ongoing","Campaign status");
		childTest.log(Status.PASS, "Run Campaign Passed");

			
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
				pause(5000);
				Set <String> winHandles = driver.getWindowHandles();
				String parentWinHandle = driver.getWindowHandle();
				 String lastWindowHandle = "";
				
				pause(10000);
				 for(String handle: winHandles)
				 {
			            if(!handle.equals(parentWinHandle))
			            {
			            driver.switchTo().window(handle);
			            pause(5000);
			            enterText(Pages1.xUsername, "xUsername", "sneha.sharavan-kumar@rntbci.com");
			    		enterTextSecure(Pages1.xPassword,"xPassword", "Aadithsg@1910");
			    		btnClick(Pages1.xLogin, "xLogin");
			    		pause(9000);
			    		btnClick(Pages1.xCampaignManagement, "xCampaignManagement");
			    		pause(9000);
			    		btnClick(Pages1.xCampaignList, "xCampaignList");
			    		pause(10000);
			    		enterText("//*[@id='campaignName']", "CampaignName", Step2campaignName);
			    		pause(5000);
			         	btnClick("//*[@class='card-body-wrapper clearfix']/section/section/div/div/div/div","xSelectCampaign");
			    		pause(20000);
			    		CompareText("//*[@id=\"campaign-status-widget\"]/div/div[2]/div/span","Active","XCampaignStatus");
						childTest.log(Status.PASS, "Redbend Status ");
			            }
				 }
			            driver.switchTo().window(parentWinHandle);
			          
				 
			        pause(5000);
					btnClick_link(Step2campaignName);
					pause(5000);
					scrollToElement(Pages1.Stop);	
					pause(6000);
					//btnClick(Pages1.StopSure);
					btnClick("//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]","Stop_Campaign_Confirm");
					pause(15000);
					driver.navigate().refresh();
					pause(15000);
					driver.navigate().refresh();
					if(findElementPassIfNotFound(Pages1.Stop,"stop"))
					{
						scrollToElement(Pages1.Stop);	
						pause(6000);
						//btnClick(Pages1.StopSure);
						btnClick("//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]","Stop_Campaign_Confirm");
						pause(3000);
						childTest.log(Status.PASS, "Redbend Status ");
					}
						
					pause(15000);
					CompareText("//td[.='"+Step2campaignName+"']//following-sibling::td[7]/label","Finished","Campiagn Status");
					childTest.log(Status.PASS, "Campaign Portal Status");
					
				pause(5000);
				 for(String handle: winHandles)
				 {
			            if(!handle.equals(parentWinHandle))
			            {
			            driver.switchTo().window(handle);
			            pause(5000);
			            driver.navigate().refresh();
			            pause(15000);
			            CompareText("//*[@id='campaign-status-widget']/div/div[2]/div/span", "Closed", "xCampaignStatus");
			       		childTest.log(Status.PASS, "Redbend Status ");
			       		driver.close();
			          }
				 }
				 
				 driver.switchTo().window(parentWinHandle);
	}
	@Test(priority=3)
	public void MapVinVerificationStep1_1039293() throws IOException, InterruptedException {
		driver.get(getProperty("CampaignPortal"));
		pause(5000);
		btnClick_link("Campaigns");
		pause(5000);
		btnClick(Pages1.New, "New");
		pause(2000);
		enterText(Pages1.Campaign_Title,"Campaign_Title", excel(file,1,13,1)+getTimeStamp());
		pause(2000);
		selectDropdown(Pages1.SelectBrand, "SelectBrand", "RENAULT");	
		pause(2000);
		selectDropdown(Pages1.SelectCampaignType,"Map campaign", "Automatic Map Update");
		pause(5000);
		selectDropdown(PagesScomo.SelectECUtype,"SelectECUtype", "IVI");
		enterText(Pages1.Campaign_Vin,"Campaign_Vin", "where c.vin ='VF1SYMMPU170NA446'");
		pause(3000);
		btnClick(PagesScomo.ExecutionSettings,"ExecutionSettings");
		 selectDropdown(Pages1.FOTA_type,"FOTA_type","SILENT");
		 btnClick(PagesScomo.DynamicHMI,"DynamicHMI");
		 pause(5000);

		 btnClick(Pages1.Save_Campaign, "Save_Campaign");
			pause(10000);
			pause(10000);
			childTest.log(Status.PASS, "Campaign creation failed");
			
	}
	@Test(priority=4)
	public void MapVinVerificationStep2_1039293() throws IOException, InterruptedException {
		driver.get(getProperty("CampaignPortal"));
		pause(5000);
		btnClick_link("Campaigns");
		pause(7000);
		btnClick(Pages1.New, "New");
		pause(2000);
		enterText(Pages1.Campaign_Title,"Campaign_Title", excel(file,1,14,1)+getTimeStamp());
		pause(2000);
		selectDropdown(Pages1.SelectBrand, "SelectBrand", "RENAULT");
		pause(2000);
		selectDropdown(Pages1.SelectCampaignType,"Map campaign", "Automatic Map Update");
		pause(5000);
		selectDropdown(Pages_MapCampaign.MapStep2,"MapStep2", "Step 2");
		btnClick(Pages_MapCampaign.MapStep2SelectEcu,"MapStep2SelectEcu");	
		
		btnClick(Pages_MapCampaign.MapStep2AddAll,"MapStep2AddAll");	
		pause(2000);
	//	selectDropdown(PagesScomo.SelectECUtype, "IVI","SelectECUtype");
		enterText(Pages1.Campaign_Vin,"Campaign_Vin", "where c.vin ='VF1CUSTBJATEST001'");
		pause(3000);
		btnClick(PagesScomo.ExecutionSettings,"ExecutionSettings");
		 selectDropdown(Pages1.FOTA_type,"FOTA_type","SILENT");
		// btnClick(PagesScomo.DynamicHMI,"DynamicHMI");
		 pause(5000);
			/*btnClick(PagesScomo.DynamicHMI,"DynamicHMI");
			sleep(5000);
			btnClick(PagesScomo.DownloadSilent,"DownloadSilent");
			sleep(2000);
			btnClick(PagesScomo.InstallSilent,"InstallSilent");
			sleep(2000);
			btnClick(PagesScomo.ActivateSilent,"ActivateSilent");
			*/
			btnClick(Pages1.Save_Campaign,"Save_Campaign");
			pause(10000);
			pause(10000);
			childTest.log(Status.PASS, "Campaign creation failed");
			
	}
}
	
