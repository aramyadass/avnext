package CampaignPortal_Auto;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.sikuli.script.FindFailed;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
//import com.relevantcodes.extentreports.LogStatus;
import AdminPortal_Auto.AdminPortal;
//import com.relevantcodes.extentreports.LogStatus;
import CampaignPortal_Auto.BaseClass;
import CampaignPortal_Pages.CampaignPortalReg_Page1;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.PagesExtraInfo;
import CampaignPortal_Pages.PagesScomo;
import CampaignPortal_Pages.PagesVinManagement;
import CampaignPortal_Pages.Pages_NR_Descmo;
import CampaignPortal_Pages.Pages_NR_GrpMgt;

public class NR_GroupMgt extends ReUsableMethods {

	static String campaignName;
	static String GroupName;
	static String campaignName_95614;
	static String lastfileName;
	
	//String a = "window.open('https://outlook.office365.com/mail/inbox','_blank')";
	String a="https://outlook.office365.com/mail/inbox";
	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";

	static String vinSTG=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My_STG.csv";
	static String vinSIT=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My - SIT.csv";
	
	
	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}
	
	
	@Test(priority=1)
	public static void ReadVIN_Information_95611() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		
		btnClick_link("Groups Management");
		pause(4000);
		getTextFromElement(Pages_NR_GrpMgt.Grp_name," - GroupName : ");
		getTextFromElement(Pages_NR_GrpMgt.Grp_Vin," - Group Vin count : ");
		pause(4000);
		btnClick(Pages_NR_GrpMgt.Grp_name,"Group VIN");
		pause(2000);
		movetoElement(LocType.xpath, Pages_NR_GrpMgt.Grp_ExportCSV," Groups - ExportCSV");
		btnClick(Pages_NR_GrpMgt.Grp_ExportCSV," Groups - ExportCSV");
		pause(15000);

		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);
		childTest.log(Status.INFO,"File : "+downloadPath+lastDownloadFile);
		System.out.println(downloadPath+lastDownloadFile);
		read_File_Data(new File(System.getProperty("user.dir")+"\\Downloads\\"+lastDownloadFile));
	
	}

	@Test(priority=2)
	public static void createGroup_CreateCampaign_95612() throws IOException, InterruptedException {
		
		enterUrl(AdminPortal.campaignPortal_URL);
		
		pause(5000);
		
		btnClick_link("Groups Management");
		childTest.log(Status.INFO, "Click on Groups Management");
		campaignName =excel(file,4,2,1)+getTimeStamp();
		GroupName = excel(file,4,0,1)+getTimeStamp();
		pause(4000);
		btnClick(Pages_NR_GrpMgt.Grp_NewGrp," NEW Group Button");
		enterText(Pages_NR_GrpMgt.Grp_TitleName, " Group Name :  ",GroupName);
		pause(2000);
		enterText(Pages_NR_GrpMgt.Grp_VINvalue, " VIN :  ",excel(file,4,1,1));
		btnClick(Pages_NR_GrpMgt.Grp_create," - Create Button");
		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);
		
		pause(9000);
		click(LocType.linkText, "Campaigns", "Campaigns");
		//driver.findElementByLinkText("Campaigns").click();
		pause(5000);

		btnClick(Pages1.New,"NEW Button");
		pause(5000);
		enterText(Pages1.Campaign_Title,"Campaign Name is : ",campaignName);
		selectDropdown(Pages1.SelectBrand, " Brand :  ","RENAULT");
		selectDropdown(Pages1.SelectCampaignType, " CampaignType :  ", "Inventory");

		pause(5000);
		btnClick(Pages_NR_GrpMgt.Grp_ExistingScope,"Existing Scope Radio Button");
		pause(3000);
		btnClick(Pages_NR_GrpMgt.Grp_AddExistingScope,"Add Existing Scope Button");
		pause(3000);
		btnClick(Pages_NR_GrpMgt.Grp_AddExistingScope,"Grp_AddExistingScope");
		pause(7000);
		enterText(Pages_NR_GrpMgt.Grp_NameText, "GroupName :  ",GroupName);

		btnClick(Pages_NR_GrpMgt.Grp_Apply,"Apply Button");
		pause(5000);
		
		click(LocType.xpath, "//td[.='"+GroupName+"']//parent::td//preceding::td[1]/input", GroupName+" - Checkbox");
		pause(4000);
		scrollToElement("//*[@id='btnAddExistingGroupList']");
		pause(4000);
		click(LocType.xpath, "//*[@id='btnAddExistingGroupList']", " Add Selected Groups Button");
		pause(10000);
		btnClick(Pages1.Save_Campaign,"SAVE Button");
		
		//ExcludedVInsPOpup();
		
		pause(5000);
		childTest.log(Status.INFO, "Create Campaign Passed");
		childTest.addScreenCaptureFromPath(captureScreen());
		
		btnClick("//td[.='"+campaignName+"']//parent::td//preceding::td[1]/input","campaignName");
		System.out.println("Found checkbox");
		pause(7000);
		btnClick(Pages1.Run_Campaign,"Run Button");
		
		//ExcludedVInsPOpup();
		
		pause(10000);
		getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", campaignName+" Status - ");
		childTest.log(Status.INFO, " Run Campaign Passed ");
		childTest.addScreenCaptureFromPath(captureScreen());
		
		pause(10000);
		
		click(LocType.linkText, campaignName,campaignName);
		childTest.log(Status.INFO, "Click on "+campaignName);
		btnClick(Pages1.Stop,"STOP Button");	
		pause(6000);
		btnClick("//div[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]","Stop Campaign Confirm - OK");
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label","campaignName");

		childTest.log(Status.INFO, "Campaign Portal Status");
		childTest.addScreenCaptureFromPath(captureScreen());

	}
	
	@Test(priority=3)
	public static void GroupManagement_List_95613() throws IOException, InterruptedException {	
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(5000);
		btnClick_link("Groups Management");
		pause(2000);
		getTextFromElement_1("//*[@id='entry-grid-groups-list']/thead/tr", "Name Created by Vins Count Creation date Update date");
		//childTest.log(Status.INFO,);
		childTest.addScreenCaptureFromPath(captureScreen());
	}
	
	
	@Test(priority=4)
	public static void ExportcsvGroup_withoutDuplicateVIN_95614() throws IOException, InterruptedException {	
		enterUrl(AdminPortal.campaignPortal_URL);
		
		refresh();
		campaignName_95614 = excel(file,4,3,1)+getTimeStamp();
		pause(9000);
		btnClick_link("Campaigns");
		childTest.log(Status.INFO, " Click on Campaigns");
		pause(5000);
		btnClick(Pages1.New,"New Button");
		enterText(Pages1.Campaign_Title," campaignName :  ",campaignName_95614);
		selectDropdown(Pages1.SelectBrand, " Brand :  ","RENAULT");
		selectDropdown(Pages1.SelectCampaignType, " CampaignType :  ","Inventory");
		pause(5000);
		//selectDropdown(PagesScomo.SelectECUtype, "IVC","SelectECUtype");
		pause(2000);
		btnClick(Pages_NR_Descmo.Import,"Import Radio Button");
		btnClick(Pages_NR_Descmo.Browse,"Browse Button");      
		pause(5000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(vinSIT);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(vinSTG);
			//ExcludedVInsPOpup();
		}
		
		//childTest.log(Status.INFO,"File upload : "+vin1);
		scrollPageBy(0, 2000);
		movetoElement(LocType.xpath, Pages1.Save_Campaign,"SAVE Button");
		pause(2000);
		btnClick(Pages1.Save_Campaign,"SAVE Button");
		pause(2000);
		
		pause(10000);
		
		btnClick("//td[.='"+campaignName_95614+"']//parent::td//preceding::td[1]/input", campaignName_95614);
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign,"RUN Button");
		
		
		
		//ExcludedVInsPOpup();
		
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campaignName_95614+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Campaign status is : "+status);
		childTest.log(Status.PASS,"Campaign status is : "+status);
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(4000);
		click(LocType.linkText, campaignName_95614, campaignName_95614);
		//btnClick_link(campaignName_95614);
		pause(5000);
		btnClick("//*[@id='CampaignTabs']/label[3]/span","ExecutionLogs");
		pause(2000);
		WebElement getName = driver.findElementByXPath("//*[@id='content7']/div/campaignlogs/div[3]/div[2]/div/span");
		String ABC = getName.getText();
		System.out.println(ABC);
		childTest.log(Status.INFO,"Execution Logs Name : "+ABC);
		pause(2000);
		for (int i = 0; i < ABC.length(); i++) {
			String[] namesplit = ABC.split("_");
			String name = namesplit[1];
			System.out.println("The name is "+name);
			childTest.log(Status.INFO, "The name of campaign : "+name);	
		}
		
		pause(5000);
		btnClick(PagesExtraInfo.Description,"Description");

		pause(7000);
		btnClick("//*[@class='file-name']/span/a","fileName");
		pause(9000);
		getLatestFilefromDir(System.getProperty("user.dir")+"\\Downloads");
		System.out.println(lastfileName);

		childTest.log(Status.PASS, "Last File Name :  "+lastfileName);
		pause(5000);
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);
		childTest.log(Status.INFO,"File : "+downloadPath+lastDownloadFile);
		System.out.println(downloadPath+lastDownloadFile);
		read_File_Data(new File(System.getProperty("user.dir")+"\\Downloads\\"+lastDownloadFile));
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(10000);
	
	}

	@Test(priority=5)
	public static void createCampaign_utilizeExistingGroups_95615() throws IOException, InterruptedException {
		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);
		
		campaignName = excel(file,4,3,1)+getTimeStamp();
		pause(5000);
		btnClick_link("Campaigns");
		childTest.log(Status.INFO,"Click on Campaigns");
		pause(5000);
		btnClick(Pages1.New,"New Button");
		pause(5000);
		enterText(Pages1.Campaign_Title," CampaignName :  ",campaignName);
		selectDropdown(Pages1.SelectBrand, " Brand :  ","RENAULT");
		selectDropdown(Pages1.SelectCampaignType, " CampaignType :  ","Inventory");
		pause(5000);
		btnClick(Pages_NR_GrpMgt.Grp_ExistingScope,"Existing Scope Button");
		pause(3000);
		btnClick(Pages_NR_GrpMgt.Grp_AddExistingScope,"Add Existing Scope Button");
		pause(3000);
		btnClick(Pages_NR_GrpMgt.Grp_AddExistingScope,"Add Existing Scope Button");
		getTextFromElement("//*[@id='entry-grid-groups-list']/tbody/tr[1]/td[2]","GroupsList");
		pause(5000);
		ClearText("//input[@id='pageGridSizeGroupManagementList']");
		enterText("//input[@id='pageGridSizeGroupManagementList']","Page Size :  ", "5");
		click(LocType.xpath, "//div[@id='modalBody']/groups-management-list/div[2]/div/div/div/div/button", "Apply Button");
		
		pause(7000);
		enterText(Pages_NR_GrpMgt.Grp_name_home," GroupName :  "+GroupName,  GroupName);
		pause(2000);
		btnClick(Pages_NR_GrpMgt.Grp_Apply,  "Apply Button");
		
		btnClick("//table[@id='entry-grid-groups-list']/tbody/tr[1]/td[1]/input","GroupsList");
		
		pause(4000);
		//scrollToElement(Pages_NR_GrpMgt.Grp_AddSelected);
		scrollToElement("//*[@id='btnAddExistingGroupList']");
		pause(2000);
		click(LocType.xpath,"//*[@id='btnAddExistingGroupList']", "btnAddExistingGroupList Button");
		pause(7000);
		btnClick(Pages1.Save_Campaign,"SAVE Button");
		
		//ExcludedVInsPOpup();
				
		pause(15000);
		childTest.log(Status.PASS," Create Campaign Passed ");
		childTest.addScreenCaptureFromPath(captureScreen());
	}

	@Test(priority=6)
	public static void Groups_ExportALL__95616() throws IOException, InterruptedException {
		
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(5000);
		btnClick_link("Groups Management");
		btnClick(Pages_NR_GrpMgt.Grp_ExportAllCSV,"Grp_ExportAllCSV");
		btnClick(Pages_NR_GrpMgt.Grp_ExportAllOkay,"Grp_ExportAllOkay");
		
		String win=driver.getWindowHandle();
		((JavascriptExecutor)driver).executeScript("window.open(arguments[0])", "https://outlook.office365.com");
		pause(2000);
		String winpage=driver.getWindowHandle();
				int i=0;
		Set<String> ins=driver.getWindowHandles();
		System.out.println("wins : "+ins);
		
		getSwitchWindow(1);
		pause(2000);
		System.out.println(" switch to win1");
		//driver.switchTo().window(win1);
		//enterUrl("https://outlook.office365.com/mail/inbox");
		pause(10000);

		DTA_SendKeys(LocType.xpath, CampaignPortalReg_Page1.Search, " Search :  ","Email Service GroupsManagement");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		
		WebElement searchbox1=identifyElement(LocType.xpath, CampaignPortalReg_Page1.Search);
		pause(1000);
		searchbox1.sendKeys(Keys.ENTER);
		pause(5000);
		click(LocType.xpath, PagesVinManagement.Filter, "Filter Dropdown");
		pause(2000);
		click(LocType.xpath,PagesVinManagement.Unread," Unread");
		pause(4000);
		click(LocType.xpath, CampaignPortalReg_Page1.EmailService,"Email");
		pause(7000);
		click(LocType.xpath, CampaignPortalReg_Page1.MAILLink,"Mail link");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(50000);
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);
		childTest.log(Status.INFO,"File : "+downloadPath+lastDownloadFile);
		System.out.println(downloadPath+lastDownloadFile);
		
		
		pause(50000);
		driver.close();
        zipFile(downloadPath+lastDownloadFile);
		driver.switchTo().window(win);
		
		
		getSwitchWindow(0);
		pause(2000);
		getSwitchWindow(1);
		pause(2000);
		closeBrowser();
		pause(2000);
		driver.switchTo().window(win);
		pause(2000);
		
		
		}
	

	@Test(priority=7)
	public static void Groups_LoadMORE_95618() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(5000);
		btnClick_link("Groups Management");
		childTest.log(Status.INFO, "Groups Management");
		pause(4000);
		ClearText(Pages_NR_GrpMgt.PageSize);
		enterText(Pages_NR_GrpMgt.PageSize,  " PageSize :  ","5");
		btnClick("//div[@id='groupsManagement']/div/div[2]/div/div/div/div/button", "APPLY Button");
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		//getTextFromElement(Pages_NR_GrpMgt.Grp_Vin,"VIN's Count :");
		//getTextFromElement(Pages_NR_GrpMgt.Grp_Vin_2,"Grp_Vin_2");
		scrollToElement(Pages_NR_GrpMgt.Grp_LoadMore);
		pause(2000);
		click(LocType.xpath,Pages_NR_GrpMgt.Grp_LoadMore,"LOAD Button");
		childTest.log(Status.INFO, "Click on LOAD Button");
		scrollPageBy(0, 2000);
		pause(15000);
		childTest.addScreenCaptureFromPath(captureScreen());
		

	}
}

