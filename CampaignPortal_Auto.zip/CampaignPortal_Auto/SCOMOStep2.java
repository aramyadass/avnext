package CampaignPortal_Auto;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import AdminPortal_Auto.ContentManagement_Step1;
import AdminPortal_Auto.ContentMgt_Step2;
import AdminPotal_Pages.ContentManagement_Page;
import CampaignPortal_Pages.CampaignPor_TemplatePage;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.SCOMOStep2_Page;

public class SCOMOStep2 extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String FotaType;
	static String ECUModel;
	static String campType;
	static String SCOMOstep2_vin_SIT=System.getProperty("user.dir")+"\\UploadFiles\\SCOMO step2_SIT.csv";
	static String SCOMOstep2_vin_STG=System.getProperty("user.dir")+"\\UploadFiles\\SCOMO step2_STG.csv";
	static String campaignName;
	static String ecuType;
	static String fromVersionSIT;
	static String fromVersionSTG;
	
	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}

	@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);

		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");

	}
	
	//@Test(priority = 2)
	public static void SCOMOMONO_IVI_DELTA_709029() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		ecuType=excel(file,6,1,1);
		campName="SCOMOMONO_IVI_DELTA-"+ getTimeStamp();
		fromVersionSIT=excel(file,6,1,2);
		fromVersionSTG=excel(file,6,1,5);
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			SCOMOMONO_ECU_DELTA(campName,ecuType,fromVersionSIT);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			SCOMOMONO_ECU_DELTA(campName,ecuType,fromVersionSTG);
		}
	}

	//@Test(priority = 3)
	public static void SCOMOMONO_IVC_DELTA_709066() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		campName="SCOMOMONO_IVC_DELTA-"+ getTimeStamp();
		ecuType=excel(file,6,2,1);
		fromVersionSIT=excel(file,6,2,2);
		fromVersionSTG=excel(file,6,2,5);
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			SCOMOMONO_ECU_DELTA(campName,ecuType,fromVersionSIT);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			SCOMOMONO_ECU_DELTA(campName,ecuType,fromVersionSTG);
		}
		
		//SCOMOMONO_ECU_DELTA(ecuType,fromVersionSTG);
	}
	
	@Test(priority = 4)
	public static void SCOMOdELTAMultiECUIVInIVC_709067() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		SCOMOMultiIVInIVC("IVC", "IVI");
		//MultiVINSCOMOMonoECUType("IVI");
	}

	//@Test(priority = 5)
	public static void MultiVINSCOMOMonoIVI_709068() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		campName="MultiVINSCOMOMonoIVI-"+ getTimeStamp();
		MultiVINSCOMOMonoECUType(campName,"IVI","RDO.SOFTWARE");
	}

	//@Test(priority = 6)
	public static void MultiVINSCOMOMonoIVC_709069() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		campName="MultiVINSCOMOMonoIVC-"+ getTimeStamp();
		MultiVINSCOMOMonoECUType(campName,"IVC","TCU.SOFTWARE");
	}

	//@Test(priority = 7)
	public static void MultiVINDelta_SCOMOMultiECU_IVCIVI_709075() throws InterruptedException, IOException {
		getSwitchWindow(0);
		refresh();
		
		enterUrl(AdminPortal.campaignPortal_URL);
		String contentVersion_sit="283C37314A_BAR.08.08.30.Q2S_sit.userdebug";
		String contentVersion_stg="C08063000F_CUB.08.06.30.Q2M_stg.userdebug";
		campName="MultiVIN_SCOMOMultiECU-"+getTimeStamp(); 
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(7000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);

		pause(2000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", "IVI");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", "IVC");

		pause(2000);
		click(LocType.id, "btnRightECU", " ADD Button");
		pause(4000);
		movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}
		

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		scrollPageBy(0, -20);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			movetoElement(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[3]/span", " Contents ");
			click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[3]/span", " Contents ");
			
			movetoElement(LocType.xpath,"//td[.='"+contentVersion_sit+"']//parent::td//preceding::td[6]"," Contents "); 
			//SCOMOStep2_Page.Contents, " Contents ");
			click(LocType.xpath, "//td[.='"+contentVersion_sit+"']//parent::td//preceding::td[6]", " Contents ");
			pause(2000);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			movetoElement(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[3]/span", " Contents ");
			click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[3]/span", " Contents ");
			
			
			movetoElement(LocType.xpath,"//td[.='"+contentVersion_stg+"']//parent::td//preceding::td[6]"," Contents "); 
			//SCOMOStep2_Page.Contents, " Contents ");
			click(LocType.xpath, "//td[.='"+contentVersion_stg+"']//parent::td//preceding::td[6]", " Contents ");
			pause(2000);
		}
		
		
		select_Dropdown_Value(LocType.xpath, SCOMOStep2_Page.TCUSOFTWARE, "TCU.SOFTWARE");
		click(LocType.xpath, SCOMOStep2_Page.TCUSoftware_checkbox, "TCU Software - checkbox");
		//click(LocType.xpath, "//table[@id='content-grid']/tbody/tr[1]/td[1]/input", "TCU Software - checkbox");
		pause(2000);
		//select_Dropdown_Value(LocType.xpath, SCOMOStep2_Page.RDOSOFTWARE, "RDO.SOFTWARE");
		//click(LocType.xpath, SCOMOStep2_Page.RDOSoftware_checkbox, "RDO Software - checkbox");
		
		pause(2000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		pause(7000);
		enterUrl(AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, "Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());
		btnClick("//input[@data-campname='"+campName+"']", "CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign, "Run_Campaign");
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		childTest.log(Status.PASS, "Run campaign Passed. ");
		//childTest.addScreenCaptureFromPath(captureScreen());

		
		/*
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, "URL :  "+AdminPortal.Redbend_URL);
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				btnClick(Pages1.xLogin, "Login Button");
				pause(9000);
				btnClick(Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				btnClick(Pages1.xCampaignList, "CampaignList");
				//btnClick(Pages1.xCampaignList, "xCampaignList");
				pause(10000);
				enterText(Pages1.Campaign_Title, campName, campName);
				pause(5000);
				btnClick(Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				getTextFromElement(Pages1.xCampaignStatus, " Campaign Status ");


				childTest.log(Status.PASS, "RedBend Status : ");
				//childTest.addScreenCaptureFromPath(captureScreen());

				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);

		 */
		pause(4000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	
		btnClick_link(campName);
		pause(4000);
		click(LocType.xpath, SCOMOStep2_Page.ExecutionLogs, "Execution Logs");

		pause(7000);
		scrollPageBy(0, 500);
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton1, " MORE1 buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		readDownloadLastFile();

		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		readDownloadLastFile();
		pause(5000);
		
		click(LocType.xpath, SCOMOStep2_Page.MOREButton1_close, "More1 Close button");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton2, " MORE2 buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		readDownloadLastFile();

		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		readDownloadLastFile();

		pause(5000);

	}
	
	//@Test(priority = 8)
	public static void SCOMOMono_IVIFULL_1085031() throws InterruptedException, IOException {
		
		campName="SCOMOMono_IVIFULL- "+getTimeStamp();
		//campName="SCOMOMono_FULL-"+ getTimeStamp(); 
		String SCOMOIVI_FULL_SIT="283C36666R_CUB.08.10.30.Q2S_sit_user";
		String SCOMOIVI_FULL_STG="283C31877R_BAR.08.05.32.Q2M_stg.userdebug";
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			SCOMOMono_ECUType_WITHFULLCONTENT(campName,"IVI",SCOMOIVI_FULL_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			SCOMOMono_ECUType_WITHFULLCONTENT(campName,"IVI",SCOMOIVI_FULL_STG);
		}
		
				//"532C02321R_CUB.09.05.32.Q2M_sit.userdebug");
				
				//"532C02321R_CUB.09.05.32.Q2M_sit.userdebug");

	}
	
	//@Test(priority = 9)
	public static void SCOMOMONO_IVCFULL_1085032() throws InterruptedException, IOException {
		campName="SCOMOMONO_IVCFULL-"+ getTimeStamp(); 
		String versionSTG="21901H94KY";
		String versionSIT="217169992X";
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			SCOMOMono_ECUType_WITHFULLCONTENT(campName,"IVC",versionSIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			SCOMOMono_ECUType_WITHFULLCONTENT(campName,"IVC",versionSTG);	
		}
		
				//"208012222X");
	}

	//@Test(priority = 10)
	public static void CreateSCOMOStep2Campaign_from_CampaignTemp1085033() throws InterruptedException, IOException {
		
		String campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		ecuType=excel(file,6,1,1);
		fromVersionSIT=excel(file,6,1,2);
		fromVersionSTG=excel(file,6,3,5);
		campName="SCOMOStep2_from_CampTemp-"+getTimeStamp();
		Campaign_Templates.CreateTemplate(campTempName);
		pause(2000);
		click(LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td",campTempName+" - Checkbox");
		pause(2000);
		click(LocType.id, CampaignPor_TemplatePage.CreateCampaignUsingTemplate,"CreateCampaignUsingTemplate Button");
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignUsingTemplateDialog,"CreateCampaignUsingTemplateDialog - YES Button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName, " CampaignName :  ",campName);
		
		pause(2000);
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.txtBrand, " Brand :  ", "RENAULT");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");

		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", "IVI");

		pause(2000);
		click(LocType.id, SCOMOStep2_Page.ADDButton, " ADD Button");
		pause(4000);
		//scrollPageBy(0, 500);
		movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);

		scrollPageBy(0, -40);
		click(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		pause(7000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			click(LocType.xpath, "//td[.='"+fromVersionSIT+"']//parent::td//preceding::td[7]", " Content - checkbox");	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			click(LocType.xpath, "//td[.='"+fromVersionSTG+"']//parent::td//preceding::td[7]", " Content - checkbox");	
		}
		//IVI : from version :283C39740R_BAR.08.02.34.Q2M_stg.userdebug
		
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, " SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, " SAVE Button");

		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, " Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());

		
	}
	
	public static void SCOMOMONO_ECU_DELTA(String campName,String ECUType,String fromVersion) throws InterruptedException, IOException {
		
		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		//campName="SCOMOMultiIVIn - "+ getTimeStamp(); 
		
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(7000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);

	
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");

		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", ECUType);

		pause(2000);
		click(LocType.id, "btnRightECU", " ADD Button");
		pause(4000);
		//scrollPageBy(0, 500);
		movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);
		
		scrollPageBy(0, -20);
		movetoElement(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		click(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		pause(7000);

		//IVI : from version :283C39740R_BAR.08.02.34.Q2M_stg.userdebug
		click(LocType.xpath, "//td[.='"+fromVersion+"']//parent::td//preceding::td[7]", fromVersion + " content - checkbox");
		/*
		int i;
		for(i=1;i<i+1;i++) {
			
			WebElement ele2=identifyElement(LocType.xpath, "//td[.="+R+"'R317RDO00N']//parent::td//preceding::td[7]");
					//identifyElement(LocType.xpath, "//table[@id='content-grid']/tbody/tr["+i+"]/td[8]");
			//WebElement el2=identifyElement(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[8]/span");
			String null1=ele2.getText();
			System.out.println("from sw : "+null1);
			String bar="BAR";
			if((null1).startsWith("R")) {
				click(LocType.xpath, ele2, "content Software - checkbox");
				break;
			}
				
		}
		*/
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");
		pause(2000);;
		
		childTest.log(Status.INFO, "Go To Campaign Page");
		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, "Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Campaign Status is :  "+status1.getText());
		btnClick("//input[@data-campname='"+campName+"']", campName+" - CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign, campName+" RUN Button");
		pause(10000);
		WebElement web = identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
				//driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		//String status = web.getText();
		System.out.println("Caampaign status is : "+web.getText());
	//	pause(5000);
		//childTest.addScreenCaptureFromPath(captureScreen());

		childTest.log(Status.PASS, "Run campaign Status :  "+web.getText());
		//childTest.addScreenCaptureFromPath(captureScreen());

		pause(4000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');")
		
		/*
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, "Go To URL :  "+AdminPortal.Redbend_URL);
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				//childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				btnClick(Pages1.xLogin, "Login Button");
				pause(9000);
				btnClick(Pages1.xCampaignManagement, "Campaign Management");
				pause(9000);
				btnClick(Pages1.xCampaignList, "CampaignList Button");
				//btnClick(Pages1.xCampaignList, "xCampaignList");
				pause(10000);
				enterText(Pages1.Campaign_Title, campName+" campaign Name : ", campName);
				pause(5000);
				btnClick(Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				getTextFromElement(Pages1.xCampaignStatus, " Campaign Status ");

				WebElement statuss=identifyElement(LocType.xpath, Pages1.xCampaignStatus);	
				String stattus=statuss.getText();
				childTest.log(Status.PASS, campName+" RedBend Status : "+stattus);
				//childTest.addScreenCaptureFromPath(captureScreen());
				//close redbend
				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);

	*/
		pause(2000);
		btnClick_link(campName);

		pause(7000);
		click(LocType.xpath, SCOMOStep2_Page.ExecutionLogs, "Execution Logs");
		scrollPageBy(0, 500);
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");

		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		childTest.log(Status.INFO, "Inventory JSON file Data : ");
		readDownloadLastFile();


		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		childTest.log(Status.INFO, "Events history JSON file Data : ");
		readDownloadLastFile();

		pause(5000);
		
		
	}


	public static void MultiVINSCOMOMonoECUType(String campName,String ECUType1,String Content) throws InterruptedException, IOException {

		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);

		//campName="SCOMOMultiIVInECU - "+ getTimeStamp(); 
		
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(7000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);

		pause(2000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", ECUType1);

		pause(2000);
		click(LocType.id, SCOMOStep2_Page.ADDButton, " ADD Button");
		pause(4000);
		movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		scrollPageBy(0, -50);
		movetoElement(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		click(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		pause(2000);
		click(LocType.xpath,"//td[.='"+Content+"']//parent::td//preceding::td[1]"," Content Software - checkbox");
				//"//td[contains(text(),SOFTWARE)]//parent::td//preceding::td[1]"," Content Software - checkbox");
				//"//td[.='RDO.SOFTWARE']//parent::td//preceding::td[1]"," Content Software - checkbox"); 
				//"//table[@id='content-grid']/tbody/tr[1]/td[1]/input", "TCU Software - checkbox");
		pause(2000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		pause(5000);
		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, "Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());
		btnClick("//input[@data-campname='"+campName+"']", "CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign, "Run_Campaign");
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		childTest.log(Status.PASS, "Run campaign Passed. ");
		//childTest.addScreenCaptureFromPath(captureScreen());

		
		/*
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, "URL :  "+AdminPortal.Redbend_URL);
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				pause(5000);
				enterText(Pages1.xUsername, AdminPortal.RedbendUser,"rakesh.gm-extern@rntbci.com");
				enterText(Pages1.xPassword, AdminPortal.RedbendPassword,"Rntbci@75Rntbci@75");
				btnClick(Pages1.xLogin, "Login Button");
				pause(9000);
				btnClick(Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				btnClick(Pages1.xCampaignList, "CampaignList");
				//btnClick(Pages1.xCampaignList, "xCampaignList");
				pause(10000);
				enterText(Pages1.Campaign_Title, campName, campName);
				pause(5000);
				btnClick(Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				WebElement redbendStatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, " Campaign Status ");


				childTest.log(Status.PASS, "RedBend Status : "+redbendStatus.getText());
				//childTest.addScreenCaptureFromPath(captureScreen());

				pause(2000);
				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);

	*/
		pause(4000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	
		
		btnClick_link(campName);
		childTest.log(Status.INFO,"Click on "+campName);
		pause(4000);
		click(LocType.xpath, SCOMOStep2_Page.ExecutionLogs, "Execution Logs");

		pause(7000);
		scrollPageBy(0, 750);
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");

		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		readDownloadLastFile();

		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		readDownloadLastFile();

		pause(5000);
	}



	public static void SCOMOMultiIVInIVC(String ECUType1,String ECUType2) throws InterruptedException, IOException {
		
		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);

		campName="SCOMOMultiIVInIVC - "+ getTimeStamp(); 
		childTest.log(Status.INFO, "URL : "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(7000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);

		pause(2000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", "IVI");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", "IVC");

		pause(2000);
		click(LocType.id, SCOMOStep2_Page.ADDButton, " ADD Button");
		pause(4000);
		movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		scrollPageBy(0, -20);
		movetoElement(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		click(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		pause(2000);
		
		select_Dropdown_Value(LocType.name, "campaignScomoIdList", "TCU.SOFTWARE", "TCU.SOFTWARE");
		click(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[1]/input", "TCU.SOFTWARE - Checkbox");
		
		pause(2000);
		select_Dropdown_Value(LocType.name, "campaignScomoIdList", "RDO.SOFTWARE", "RDO.SOFTWARE");
		click(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[1]/input", "RDO.SOFTWARE - Checkbox");
		//click(LocType.xpath, SCOMOStep2_Page.TCUSoftware_checkbox, "TCU Software - checkbox");
		pause(2000);
		scrollPageBy(0, 2000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, "Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());
		btnClick("//input[@data-campname='"+campName+"']", "CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign, "Run_Campaign");
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		childTest.log(Status.PASS, "Run campaign Passed. ");
		//childTest.addScreenCaptureFromPath(captureScreen());

		
		/*
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, "URL :  "+AdminPortal.Redbend_URL);
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				//childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				btnClick(Pages1.xLogin, "Login Button");
				pause(9000);
				btnClick(Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				btnClick(Pages1.xCampaignList, "CampaignList Button");
				//btnClick(Pages1.xCampaignList, "xCampaignList");
				pause(10000);
				enterText(Pages1.Campaign_Title,  " Campaign Name ", campName);
				pause(5000);
				btnClick(Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				getTextFromElement(Pages1.xCampaignStatus, " Campaign Status ");


				childTest.log(Status.PASS, "RedBend Status : ");
				//childTest.addScreenCaptureFromPath(captureScreen());

				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);
		 */
		
		pause(4000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	

		btnClick_link(campName);
		pause(4000);
		click(LocType.xpath, SCOMOStep2_Page.ExecutionLogs, "Execution Logs");

		pause(7000);
		scrollPageBy(0, 750);
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");

		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		readDownloadLastFile();


		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		readDownloadLastFile();

		pause(5000);
	}	

	public static void SCOMOMono_ECUType_WITHFULLCONTENT(String campName,String ECUType,String contentVersion) throws InterruptedException, IOException {
		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		//campName="SCOMOMono_FULL-"+ getTimeStamp(); 
		
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(7000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);

		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", "SCOMO");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.ddCampaignTypeStep, " Step :  ", "Step 2");
		select_Dropdown_Value(LocType.id, NRECampaignsPage.availabeEculist, " ECU Type :  ", ECUType);

		pause(2000);
		click(LocType.id, SCOMOStep2_Page.ADDButton, " ADD Button");
		pause(4000);
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(SCOMOstep2_vin_SIT);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_SIT);	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(SCOMOstep2_vin_STG);
			childTest.log(Status.INFO,"File upload: "+SCOMOstep2_vin_STG);
		}

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		scrollPageBy(0, -20);
		movetoElement(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		click(LocType.xpath, SCOMOStep2_Page.Contents, " Contents ");
		pause(2000);
		//208012222X
		if (AdminPortal.campaignPortal_URL.contains("sit")) {

			movetoElement(LocType.xpath, "//td[.='"+contentVersion+"']//parent::td//preceding::td[6]", "Content Software - checkbox");
			click(LocType.xpath, "//td[.='"+contentVersion+"']//parent::td//preceding::td[6]", "Content Software - checkbox");
			
			
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			movetoElement(LocType.xpath, "//td[.='"+contentVersion+"']//parent::td//preceding::td[6]", "Content Software - checkbox");
			click(LocType.xpath, "//td[.='"+contentVersion+"']//parent::td//preceding::td[6]", "Content Software - checkbox");
		}
		//td[.='208012222X']//parent::td//preceding::td[6]
		//click(LocType.xpath, "//table[@id='content-grid']/tbody/tr[1]/td[1]/input", "TCU Software - checkbox");
		pause(2000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");

		click(LocType.xpath, SCOMOStep2_Page.SaveButton, "SAVE Button");
		pause(2000);
		enterUrl(AdminPortal.campaignPortal_URL);
		//campName="SCOMOMono_FULL-"+ getTimeStamp(); 
		
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		
		DTA_SendKeys(LocType.id, SCOMOStep2_Page.txtCampaignName, "Campaign Name :  ", campName);
		click(LocType.xpath, SCOMOStep2_Page.ApplyButton, "Apply Button");

		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());
		btnClick("//input[@data-campname='"+campName+"']", "CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign, "Run_Campaign");
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		childTest.log(Status.PASS, "Run campaign Passed. ");
		//childTest.addScreenCaptureFromPath(captureScreen());

		pause(2000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	
		/*
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, "URL :  "+AdminPortal.Redbend_URL);
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				btnClick(Pages1.xLogin, "Login Button");
				pause(9000);
				btnClick(Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				btnClick(Pages1.xCampaignList, "CampaignList");
				//btnClick(Pages1.xCampaignList, "xCampaignList");
				pause(10000);
				enterText(Pages1.Campaign_Title, campName, campName);
				pause(5000);
				btnClick(Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				getTextFromElement(Pages1.xCampaignStatus, " Campaign Status ");


				childTest.log(Status.PASS, "RedBend Status : ");
				//childTest.addScreenCaptureFromPath(captureScreen());

				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);
		*/

		btnClick_link(campName);
		pause(4000);
		click(LocType.xpath, SCOMOStep2_Page.ExecutionLogs, "Execution Logs");

		pause(7000);
		scrollPageBy(0, 750);
		pause(5000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");
		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.MOREButton, " MORE buttton");

		pause(2000);
		click(LocType.xpath, SCOMOStep2_Page.InventoryJSONButton, "Inventory JSON");
		pause(7000);
		readDownloadLastFile();


		click(LocType.xpath, SCOMOStep2_Page.EventshistoryJSONButton, "Events history JSON");
		pause(7000);
		readDownloadLastFile();

		pause(5000);
		
		
		
	}
	

	public static void SCOMOMONO_ECU_DELTA_Rerun() throws IOException, InterruptedException {
		String fromVersion=excel(file,6,1,2);
		campName="SCOMOMONO_ECU_DELTA"+ getTimeStamp();
		SCOMOMONO_ECU_DELTA(campName,"IVI", fromVersion);
		
		pause(2000);
		movetoElement(LocType.xpath, SCOMOStep2_Page.ApplyButton, " x close button ");
		click(LocType.xpath, SCOMOStep2_Page.MOREButton1_close, " x close button ");
	
		click(LocType.xpath, SCOMOStep2_Page.STOPButton, " STOP Button");
		click(LocType.xpath, SCOMOStep2_Page.STOP_YES_Button, "You are going to stop Campaign - YES button");
		stopCampaign1();
	}
	
	
	public static void stopCampaign1() throws InterruptedException {
		pause(15000);
		
		driver.navigate().refresh();
		pause(5000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		
		
		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
				//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());
		
		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
				//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());
		
		
		
		childTest.log(Status.INFO, "Campaign Portal Status : "+INVstatusOfCampaign_Finish.getText());
		//childTest.addScreenCaptureFromPath(captureScreen());


	}
}
