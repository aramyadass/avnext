package CampaignPortal_Auto;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;

public class USBKeyGeneration_Auto extends ReUsableMethods{

	static String CampName;
	static String campType;
	static String ECUType;
	static String mode;

	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}

	@Test(priority=1)
	public static void YellowKey_USB_1214930() throws InterruptedException, IOException {
		mode="Yellow Key";
		CampName=mode+" - USB- "+getTimeStamp();
		
		USBkey_Generation(CampName,mode);
	}
	
	//@Test(priority=2)
	public static void OTS_USB_1214930() throws InterruptedException, IOException {
		mode="OTS";
		CampName=mode+" - USB- "+getTimeStamp();
		USBkey_Generation(CampName,mode);
	}
	
	//@Test(priority=3)
	public static void DTB_USB_1214930() throws InterruptedException, IOException {
		mode="DTB";
		CampName=mode+" - USB- "+getTimeStamp();
		USBkey_Generation(CampName,mode);
	}
	
	
	public static void USBkey_Generation(String CampName, String mode) throws InterruptedException, IOException {

		//mode="Yellow Key";
		
		campType="USB Key Generation";
		ECUType="IVI";
		
		//ECUType="IVC";

		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(5000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, "campaignName", "Campaign Name : ", CampName);
		select_Dropdown_Value(LocType.id, "txtBrand", "Brand : ", "RENAULT");

		select_Dropdown_Value(LocType.id, "campaignType", "Campaign Type", campType);
		pause(2000);
		//	
		pause(1000);
		//select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", "IVC");
		if (CampName.startsWith("Yellow Key - USB-")) {
			pause(2000);
			click(LocType.id, "btnAddAllECU", "ADDAll Button");
		} else {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");
		}

		//mode
		click(LocType.id, mode, mode+" - Radio button");

		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[3]/span", "Contents Tab");
		if (CampName.startsWith("Yellow Key - USB-")) {
			select_Dropdown_Value(LocType.name, "campaignScomoIdList", "ScomoIdList : ", "TCU.SOFTWARE");
			pause(2000);
			click(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[1]/input", "TCU Scomo ID checkbox");

			pause(2000);
			select_Dropdown_Value(LocType.name, "campaignScomoIdList", "ScomoIdList : ", "RDO.SOFTWARE");
			pause(1000);
			click(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[1]/input", "RDO Scomo ID checkbox");
		} 
		else {
			pause(2000);
			select_Dropdown_Value(LocType.name, "campaignScomoIdList", "ScomoIdList : ", "RDO.SOFTWARE");
			pause(1000);
			click(LocType.xpath, "//*[@id='content-grid']/tbody/tr[1]/td[1]/input", "RDO Scomo ID checkbox");
		}


		pause(2000);
		select_Dropdown_Value(LocType.name, "campaignScomoIdList", "ScomoIdList : ", "Select Scomo Id");


		click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[4]/span", "Restriction Policy Tab");

		if (CampName.startsWith("OTS - USB-")) {
			pause(2000);
			DTA_SendKeys(LocType.xpath, "//*[@name='UsbRestrictionForm']/div/div//div[9]/div[1]/div/div/input", "OTS Reference* : ", "12345678R");
			DTA_SendKeys(LocType.id, "criteriaCode", "Criteria Code* : ", "12345");
		} else {
			System.out.println("Yellow key,DTB");
		}
		//click(LocType.xpath, "btnRemoveAllDP", "RemoveAll DP Button");


		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[1]/span", "Description");
		
		scrollPageBy(0, 100);
		click(LocType.id, "btnSave", "SAVE Button");

		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);

		//enterUrl(AdminPortal.campaignPortal_URL+"/campaigns");
		//refresh();

		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, " Campaign Name :  ", CampName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);
		pause(2000);
		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+CampName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, CampName + "  -  Status :  "+status1.getText());

		pause(1000);

		if (CampName.startsWith("Yellow Key - USB-")) {
			click(LocType.xpath,"//td[.='"+CampName+"']//parent::td//preceding::td[1]", CampName+" Campaign-Checkbox");
			click(LocType.xpath,"//td[.='"+CampName+"']//parent::td//preceding::td[1]", CampName+" Campaign-Checkbox");
		} 
		else if (CampName.startsWith("OTS - USB-")) {
			click(LocType.xpath,"//td[.='"+CampName+"']//parent::td//preceding::td[1]", CampName+" Campaign-Checkbox");
			click(LocType.xpath,"//td[.='"+CampName+"']//parent::td//preceding::td[1]", CampName+" Campaign-Checkbox");
		}
		else {
			click(LocType.xpath,"//td[.='"+CampName+"']//parent::td//preceding::td[1]", CampName+" Campaign-Checkbox");
		}
		
		pause(5000);
		click(LocType.xpath,Pages1.Run_Campaign,"RUN button");

		pause(7000);
		WebElement web = driver.findElementByXPath("//td[.='"+CampName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);

		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", CampName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());


		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		
		click(LocType.linkText, CampName, CampName);
		pause(2000);
		if (CampName.startsWith("Yellow Key - USB-")) {
			scrollPageBy(0, 100);
			childTest.log(Status.INFO, " Download button  displayed");
			System.out.println(" Download button  displayed");
			
			click(LocType.id, "btnDownloadUSB", "DownloadUSB");
			pause(50000);
			String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
			String lastDownloadFile=selectLastDownloadedFile(downloadPath);
			System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
			childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
			pause(7000);
			childTest.log(Status.INFO,"File : "+downloadPath+lastDownloadFile);
			System.out.println(downloadPath+lastDownloadFile);
			pause(2000);
		} 
		
		else {
			
			scrollPageBy(0, 100);
			childTest.log(Status.INFO, " Download button not displayed");
		System.out.println(" Download button not displayed");
		}
		
	}

}
