package CampaignPortal_Auto;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import AdminPortal_Auto.ContentManagement_Step1;
import AdminPortal_Auto.ContentMgt_Step2;
import AdminPotal_Pages.ContentManagement_Page;

public class Additionalteststep2 extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;


	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		parentTest=extent.createTest("SCOMOStep2");
		childTest=parentTest.createNode("loginwithMicrosoft");
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}


	//@Test(priority = 1)
	public static void FOATSanity2_ContentManagementDTCRules_1084994() throws IOException, InterruptedException {

		String step="Step 0-1";
		childTest=parentTest.createNode("FOATSanity2_ContentManagementDTCRules_1084994");
		System.out.println(" TC : FOATSanity2_ContentManagementDTCRules_1084994");
		FOATSanity2_ContentManagement_FULL_DTCRules(step, "00", "FFFFFF");

	}

	//@Test(priority = 2)
	public static void FOATSanity2_ContentManagementstep2_1084995() throws InterruptedException, IOException {

		String version=getDateStamp()+"7R";
		String deltaFrom=getDateStamp()+"5R";
		String FromSupplierSoftwareVersion="SSV0";
		String FromSupplierSoftwareId="SSid0";
		String SupplierSoftwareVersion="SSV1";
		String SupplierSoftwareId="SSid1";
		String SupplierSoftwareVersion2="SSV2";

		childTest=parentTest.createNode("FOATSanity2_ContentManagementstep2_1084995");
		System.out.println(" TC : FOATSanity2_ContentManagementstep2_1084995");
		ContentMgt_Step2.Create_Delta_contentStep2(version, deltaFrom, FromSupplierSoftwareVersion, FromSupplierSoftwareId, SupplierSoftwareVersion, SupplierSoftwareId);
		pause(1000);
		WebElement errorMsg=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, "Notification Message :  "+errorMsg.getText());
		//enterUrl(AdminPortal.adminPortal_URL);
		pause(4000);
		ContentMgt_Step2.Create_Delta_contentStep2(version, deltaFrom, FromSupplierSoftwareVersion, FromSupplierSoftwareId, SupplierSoftwareVersion, SupplierSoftwareId);
		pause(1000);
		WebElement errorMsg1=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, " Notification Message :  "+errorMsg1.getText());

		pause(4000);
		ContentMgt_Step2.Create_Delta_contentStep2(version, deltaFrom, FromSupplierSoftwareVersion, FromSupplierSoftwareId, SupplierSoftwareVersion2, SupplierSoftwareId);
		pause(1000);
		WebElement NotificationMsg1=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, " Notification Message :  "+NotificationMsg1.getText());
	}

	
	//@Test(priority = 3)
	public static void LGE_FULLstep2component_1084996() throws InterruptedException, IOException {
		String SupplierSoftwareVersion="SSV1";
		String SupplierSoftwareId="SSid2";	

		String SupplierSoftwareVersion2="SSV2";

		String version=getDateStamp()+"7R";

		childTest=parentTest.createNode("LGE_FULLstep2component_1084996");
		System.out.println(" TC : LGE_FULLstep2component_1084996");
		ContentMgt_Step2.Create_Full_content(version,SupplierSoftwareVersion,SupplierSoftwareId);
		pause(1000);
		WebElement NotificationMsg=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, " Notification Message :  "+NotificationMsg.getText());
		pause(4000);

		ContentMgt_Step2.Create_Full_content(version,SupplierSoftwareVersion,SupplierSoftwareId);
		pause(1000);
		WebElement DuplicateMsg1=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, " Notification Message :  "+DuplicateMsg1.getText());
		pause(4000);
		ContentMgt_Step2.Create_Full_content(version,SupplierSoftwareVersion2,SupplierSoftwareId);
		pause(1000);
		WebElement NotificationMsg1=identifyElement(LocType.xpath, "//*[@id='lblnotificationMessage']");
		childTest.log(Status.INFO, " Notification Message :  "+NotificationMsg1.getText());

	}


	//@Test(priority = 4)
	public static void DTCRules_validationStep0_1_1084997() throws IOException, InterruptedException {
		String step="Step 0-1";
		childTest=parentTest.createNode("DTCRules_validationStep0_1_1084997");
		System.out.println(" TC : DTCRules_validationStep0_1_1084997");
		FOATSanity2_ContentManagement_FULL_DTCRules(step, "00", "FFFFFF");

	}

	//@Test(priority = 5)
	public static void DTCRules_validationStep2_1084998() throws IOException, InterruptedException {
		String step="Step 2";
		String uploadfilepath=System.getProperty("user.dir")+"\\UploadFiles\\16122020AAP.7RF";
		String ECUName="RDO";
		String Caterory="Software";
		String SCOMOId="RDO.CONFIGURATION";
		String Manufacturer="LGE";
		String ContenttType="Full";
		String versionName=getDateStamp()+"7R";
		String DTALogic= excel(file,6,3,3);
		String DTCValue="FFFFFF";
		String version=getDateStamp()+"7R";
		childTest=parentTest.createNode("DTCRules_validationStep2_1084998");
		System.out.println(" TC : DTCRules_validationStep2_1084998");
		Create_DTCRuleStep2_Full_content(step,uploadfilepath,ECUName,Caterory,SCOMOId,Manufacturer,ContenttType,versionName,DTALogic,DTCValue);
	}

	//@Test(priority = 6)
	public static void campTemp_vespa_1085034() throws IOException, InterruptedException {
		enterUrl(AdminPortal.adminPortal_URL);
		childTest=parentTest.createNode("campTemp_vespa_1085034");
		System.out.println(" TC : campTemp_vespa_1085034");
		String campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		campName=excel(file, 3, 1, 1) + getTimeStamp();
		Campaign_Templates.CreateTemplate(campTempName);
		Campaign_Templates.createCampaign_Using_CampaignTemplate(campTempName, campName,"VESPA : Software",excel(file, 3,1,3));

	}



	public static void FOATSanity2_ContentManagement_FULL_DTCRules(String step,String DTALogic,String DTCValue) throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		childTest.log(Status.INFO, " URL : "+AdminPortal.adminPortal_URL);
		String uploadfilepath=System.getProperty("user.dir")+"\\UploadFiles\\16122020AAP.7RF";
		ContentManagement_Step1.UploadingSCOMOFiles(step, "RDO", "Software", "RDO.CONFIGURATION", "BOSCH","Full" , getDateStamp()+"7R", uploadfilepath);
		pause(2000);
		scrollPageBy(0, 1500);
		//movetoElement(LocType.xpath, ContentManagement_Page.Save_Btn,"Save Button");
		pause(2000);
		click(LocType.xpath, "//*[@id='metadata']/div/div/div[21]/div/div/div[2]/div/div/div/button", "DTC Rules-Add New Item");
		pause(2000);
		DTA_SendKeys(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcLogic']", "DTC Logic", DTALogic);
		pause(2000);
		DTA_SendKeys(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcValue']", "DTC Value", DTCValue);
		pause(5000);
		click(LocType.xpath, ContentManagement_Page.Save_Btn,"SAVE Button");
		pause(1000);
		WebElement saveSCOMOFile=identifyElement(LocType.xpath, ContentManagement_Page.lblnotificationMessage);
		childTest.log(Status.INFO, "Notification Message :  " +saveSCOMOFile.getText());
		//Assert.assertEquals(saveSCOMOFile.getText(), "File has been created successfully.");
		pause(1000);

	}

	public static void Create_DTCRuleStep2_Full_content(String Step,String uploadfilepath,String ECUName,String Caterory,String SCOMOId,String Manufacturer,String ContenttType,String versionName,String DTALogic,String DTCValue) throws InterruptedException, IOException {
		refresh();
		enterUrl(AdminPortal.adminPortal_URL);
		click(LocType.linkText, ContentManagement_Page.ContentManagement,"Content Management");
		pause(2000);
		click(LocType.linkText, ContentManagement_Page.SCOMOFiles,"SCOMO Files");
		pause(20000);
		click(LocType.xpath, ContentManagement_Page.createBtn,"Create Button");
		pause(5000);
		select_Dropdown_Value(LocType.id, ContentManagement_Page.ddCampaignStep," Step : ", Step);
		pause(4000);
		click(LocType.xpath, ContentManagement_Page.BrowseBtn,"Browse Button");
		drawBorder(driver, LocType.xpath, ContentManagement_Page.BrowseBtn);
		pause(2000);
		try {
			//pause(1000);
			uploadFileAutoit(uploadfilepath);
			pause(2000);
			System.out.println("File is Uploaded");
			childTest.log(Status.INFO, "File is Uploaded : "+uploadfilepath);
			childTest.addScreenCaptureFromPath(captureScreen());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("File not Uploaded");
			childTest.log(Status.INFO, "File is Uploaded");
		}	

		select_Dropdown_Value(LocType.xpath, ContentManagement_Page.ECUname, "ECU Name : ",ECUName);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, ContentManagement_Page.ContentDetails_Category, "Category  :   ", Caterory);
		select_Dropdown_Value(LocType.xpath, ContentManagement_Page.ContentDetails_ObjectName, "Scomo ID  :  ", SCOMOId);
		pause(2000);
		DTA_SendKeys(LocType.name, ContentManagement_Page.ContentDetails_Manufacturer, "Manufacturer :  ", Manufacturer);
		pause(5000);
		WebElement ContentType=identifyElement(LocType.xpath, ContentManagement_Page.ContentDetails_ContentType1);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, ContentManagement_Page.ContentDetails_ContentType, " Content Type :  ", ContenttType);
		pause(10000);
		select_Dropdown_Value(LocType.xpath, ContentManagement_Page.ContentDetails_ContentType," Content Type :  ", ContenttType);
		pause(10000);
		scrollPageBy(0, 20);
		pause(1000);
		DTA_SendKeys(LocType.xpath, ContentManagement_Page.ContentDetails_VersionName,"Version Name :  ", versionName);
		//DTA_SendKeys(LocType.name, ContentManagement_Page.ContentDetails_Description, "Description :  ", versionName);
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		scrollPageBy(0, 1500);
		movetoElement(LocType.xpath, ContentManagement_Page.Save_Btn,"Save Button");

		pause(2000);
		click(LocType.xpath, "//*[@id='metadata']/div/div/div[21]/div/div/div[2]/div/div/div/button", "DTC Rules-Add New Item");


		movetoElement(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcLogic']", "DTC Logic");
		pause(4000);
		DTA_SendKeys(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcLogic']", "DTC Logic", DTALogic);
		pause(2000);
		DTA_SendKeys(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcValue']", "DTC Value", DTCValue);
		pause(2000);
		ClearText("//*[@name='GatewayInfo_DtcRule_0_DtcLogic']");
		pause(5000);
		DTA_SendKeys(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcLogic']", "DTC Logic", DTALogic);
		pause(2000);
		click(LocType.xpath, "//*[@name='GatewayInfo_DtcRule_0_DtcValue']", "DTC Value");

		pause(5000);
		click(LocType.xpath, ContentManagement_Page.Save_Btn,"SAVE Button");
		pause(1000);
		WebElement saveSCOMOFile=identifyElement(LocType.xpath, ContentManagement_Page.lblnotificationMessage);
		childTest.log(Status.INFO, "Notification Message :  " +saveSCOMOFile.getText());
		//Assert.assertEquals(saveSCOMOFile.getText(), "File has been created successfully.");
		pause(1000);

	}

}
