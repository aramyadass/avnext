package CampaignPortal_Auto;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
//import org.sikuli.script.FindFailed;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
//import com.relevantcodes.extentreports.LogStatus;

import AdminPortal_Auto.AdminPortal;

//import com.relevantcodes.extentreports.LogStatus;

import CampaignPortal_Auto.BaseClass;
import CampaignPortal_Pages.CampaignPortalReg_Page1;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.PagesVinManagement;

public class NR_VinManagement extends ReUsableMethods {
	String b = "window.open('https://outlook.office365.com/mail/inbox','_blank')";
	static String vinSTG=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My_STG.csv";
	static String vinSIT=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My - SIT.csv";
	
	
	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}


	@Test(priority=1)
	public static void NR_VinManagement_FilterUserprofiles_95621() throws InterruptedException, IOException
	{
		enterUrl(AdminPortal.campaignPortal_URL);
	
		click(LocType.linkText,PagesVinManagement.VINManagement,"VIN Management");
		childTest.log(Status.INFO, "Click on VIN Management");
		pause(2000);
		DTA_SendKeys(LocType.xpath, PagesVinManagement.pageGridSize, "Page Size :  ", "5");
		btnClick(PagesVinManagement.VinMgt_Import, "Import Radio Button");
		scrollPageBy(0, 500);
		btnClick(PagesVinManagement.VinMgt_ExportAllSCV, "Export All Csv Button");
		pause(2000);
		btnClick(PagesVinManagement.VinMgt_ImportcsvErrOk,"*Please upload a CSV file - OK Button");
		pause(5000);
		scrollPageBy(0, -500);
		click(LocType.xpath, PagesVinManagement.VinMgt_Manual, "Manual Radio Button");
		System.out.println("click on manual radio button");
		pause(2000);
		select_Dropdown_Value(LocType.xpath, PagesVinManagement.Not_In, "Opertor :  ", "Not In");
		DTA_SendKeys(LocType.xpath, PagesVinManagement.VINCriteria, "VIN Criteria :  ", "VINFAKE0021022019");
	
		pause(2000);
		
		movetoElement(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		click(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		scrollPageBy(0, 100);
		pause(5000);
		WebElement taHeaders=identifyElement(LocType.xpath, PagesVinManagement.VinManagementHeaders);
		childTest.log(Status.INFO, "Vin Management Headers :  "+taHeaders.getText());
		
		WebElement tdData=identifyElement(LocType.xpath, PagesVinManagement.VinManagementDATA);	
		childTest.log(Status.INFO, "Vin Management Data :  "+tdData.getText());
	
		pause(4000);
		childTest.log(Status.INFO, "Filter Campaign Properties ");
		scrollPageBy(0, -40);
		movetoElement(LocType.xpath, PagesVinManagement.CampaignType, "Campaign Type");
		select_Dropdown_Value(LocType.xpath, PagesVinManagement.CampaignType, "Campaign Type :  ", "Inventory");
		pause(2000);
		select_Dropdown_Value(LocType.xpath, PagesVinManagement.Brand, "Brand  : ", "RENAULT");
		pause(2000);
	
		click(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		
		scrollPageBy(0, 100);
		pause(5000);
		childTest.addScreenCaptureFromPath(captureScreen());
		WebElement FilterTdData=identifyElement(LocType.xpath, PagesVinManagement.VinManagementDATA);	
		childTest.log(Status.INFO, "Vin Management Data :  "+FilterTdData.getText());
		pause(2000);
		
		movetoElement(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		click(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		pause(4000);
		
		click(LocType.xpath, PagesVinManagement.Reset_Button, "Reset Button");
		
		pause(2000);
		click(LocType.xpath, PagesVinManagement.ApplyButton, "Apply Button");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
	}

	
	@Test(priority=2)
	public static void NR_VinManagement_ExportALL_95622() throws InterruptedException, IOException
	{
		enterUrl(AdminPortal.campaignPortal_URL);
		
	
		click(LocType.linkText, PagesVinManagement.VINManagement,"VIN Management");
		btnClick(PagesVinManagement.VinMgt_Import, "Import Radio Button");
		scrollPageBy(0, 500);
		btnClick(PagesVinManagement.VinMgt_ExportAllSCV, "Export All Csv Button");
		pause(2000);
		btnClick(PagesVinManagement.VinMgt_ImportcsvErrOk,"OK Button");
		pause(7000);
		scrollPageBy(0,-200);
		//movetoElement(LocType.xpath,PagesVinManagement.VinMgt_browse, "BROWSE");
		//btnClick(PagesVinManagement.VinMgt_browse, "BROWSE");
		btnClick(PagesVinManagement.Browse_Button, "BROWSE");
		//btnClick(PagesVinManagement.VinMgt_browse, "Browse Button");
		pause(2000);

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			uploadFileAutoit(vinSIT);
		} 
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			uploadFileAutoit(vinSTG);
		}
		
		pause(5000);
		btnClick(PagesVinManagement.VinMgt_ExportAllSCV, "Export All Csv");
		pause(2000);
		btnClick(PagesVinManagement.VinMgt_ExportcsvSuccessOk, "Export All Success Ok");

		//driver.executeScript(b);
		pause(7000);

		String win=driver.getWindowHandle();
		((JavascriptExecutor)driver).executeScript("window.open(arguments[0])", AdminPortal.outlook_URL);
		childTest.log(Status.INFO, "URL : "+AdminPortal.outlook_URL);
		pause(2000);
		String winpage=driver.getWindowHandle();
		int i=0;
		Set<String> ins=driver.getWindowHandles();
		System.out.println("wins : "+ins);

		getSwitchWindow(1);
		pause(2000);
		System.out.println(" switch to win1");
	
		pause(7000);

		click(LocType.xpath, PagesVinManagement.Search, "Search");
		movetoElement(LocType.xpath, CampaignPortalReg_Page1.Search,"Search :  ");
		pause(2000);
		
		DTA_SendKeys(LocType.xpath, CampaignPortalReg_Page1.Search,"Search :  ", "Email Service VinsManagement");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());

		WebElement searchbox=identifyElement(LocType.xpath, CampaignPortalReg_Page1.Search);
		searchbox.sendKeys(Keys.ENTER);
		pause(5000);
		click(LocType.xpath, PagesVinManagement.Filter, "Filter Dropdown");
		pause(2000);
		click(LocType.xpath,PagesVinManagement.Unread," Unread");
		pause(4000);
		click(LocType.xpath, CampaignPortalReg_Page1.EmailService,"Email");
		pause(7000);
		click(LocType.xpath, CampaignPortalReg_Page1.MAILLink,"Mail link");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(50000);
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);
		childTest.log(Status.INFO,"File : "+downloadPath+lastDownloadFile);
		System.out.println(downloadPath+lastDownloadFile);
		
		
		pause(50000);
		driver.close();
	
        zipFile(downloadPath+lastDownloadFile);
		driver.switchTo().window(win);
		
		getSwitchWindow(0);
		pause(2000);
		getSwitchWindow(1);
		pause(2000);
		closeBrowser();
		pause(2000);
		driver.switchTo().window(win);
		pause(2000);
	
	}

}
