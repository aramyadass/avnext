package CampaignPortal_Auto;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import AdminPortal_Auto.AdminPortal;
import AdminPotal_Pages.DHMI_Page;
import CampaignPortal_Pages.CampaignPor_TemplatePage;
import CampaignPortal_Pages.CampaignPortalReg_Page1;

public class Campaign_Templates extends ReUsableMethods{

	static String campTempName;
	static String campName;

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String fileDHMI=System.getProperty("user.dir")+"\\TestData\\AdminPortal.xlsx";


	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}

	@Test(priority = 1)
	public static void createCampTemplate_82722() throws IOException, InterruptedException {
		
		childTest.log(Status.INFO, "URl : " + AdminPortal.campaignPortal_URL);
		campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		CreateTemplate(campTempName);
	}

	@Test(priority = 2)
	public static void DeleteCampTemplate_82723() throws IOException, InterruptedException {
		
		campTempName=excel(file, 3, 1, 0)+getTimeStamp();
		refresh();
		pause(4000);
		//CreateTemplate(campTempName);
		Delete_CampaignTemplate(campTempName);
	}

	//Azure storage

	@Test(priority = 4)
	public static void NewEditDeletebuttons_82725() throws InterruptedException, IOException {
		refresh();
		campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		String campNAme=excel(fileDHMI, 1, 2, 1)+getTimeStamp();
		enterUrl(AdminPortal.campaignPortal_URL);
		
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"Campaign Templates");
		pause(2000);
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaign,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignModal_NAME, " CampaignTemplate Name :  ", campTempName);		
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignModal_SAVE,"SAVE Button");
		pause(4000);
		WebElement camp1=identifyElement(LocType.xpath, CampaignPor_TemplatePage.grid_TR1);
		childTest.log(Status.INFO, "Created CampaignTemplate Details : " +camp1.getText());
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(5000);
		click(LocType.linkText, campTempName,"CampaignTemplate link : " + campTempName);
		//click(LocType.linkText,campNAme,campNAme+"- Checkbox");
		//drawBorder(driver, LocType.linkText,campNAme);
		//javaScriptClick(LocType.linkText,campNAme);
		pause(4000);
		select_Dropdown_Value(LocType.id, DHMI_Page.txtBrand, " Brand :  ",excel(fileDHMI, 1, 2, 2));
		select_Dropdown_Value(LocType.id, DHMI_Page.campaignType, " CampaignType :  ", excel(fileDHMI, 1, 2, 3));
		pause(2000);
		select_Dropdown_Value(LocType.xpath, DHMI_Page.campaignTypeCampDescForm, " ECU Type :  ",excel(fileDHMI, 1, 2, 4));
		DTA_SendKeys(LocType.id, DHMI_Page.campaignVinCriteria, " VinCriteria :  ",excel(fileDHMI, 1, 2, 5));
		pause(2000);

		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);
		click(LocType.xpath, DHMI_Page.Contents,"Contents");
		pause(4000);
		click(LocType.xpath, DHMI_Page.SCOMOTD1,"Low Checkbox");
		//javaScriptClick(LocType.xpath, DHMI_Page.SCOMOTD1);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		//	click(LocType.xpath, "//ng-form[@id='CampaignCreateViewForm']/div[2]/label[7]/span");
		//	DTA_SendKeys(LocType.id, "campaignMaxRetryNumber", "1");
		pause(1000);
		click(LocType.xpath, DHMI_Page.ExecutionTab,"Dynamic HMI");
		System.out.println("Click on Dynamic HMI-1");
		pause(1000);
		click(LocType.id, DHMI_Page.downloadSilent,"downloadSilent checkbox");
		click(LocType.id, DHMI_Page.installSilent,"downloadSilent checkbox");
		click(LocType.id, DHMI_Page.activateSilent,"activateSilent checkbox");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, DHMI_Page.EditCampaignTemplateFormSAVE,"SAVE Button");
		System.out.println("SAVE 1");
		movetoElement(LocType.xpath, "//div[@id='ConfirmSavePrompt']/div/div/div[2]/div/button[2]","Edit Mode");
		System.out.println("ConfirmSavePrompt");
		click(LocType.xpath, "//div[@id='ConfirmSavePrompt']/div/div/div[2]/div/button[2]","Edit Mode - NO Button");
		pause(7000);

		click(LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td",campTempName+"-Checkbox");
		pause(2000);
		click(LocType.xpath, CampaignPor_TemplatePage.DeleteCampaign,"Delete Button");
		drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.DeleteCampaign);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.DeletePrompt,"confirmation - Yes Button");
		drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.DeletePrompt);
		pause(10000);
		childTest.addScreenCaptureFromPath(captureScreen()).info(campTempName+" : Deleted");


	}

	@Test(priority = 5)
	public static void createCampaignUsingCampaignTemplate_82726() throws InterruptedException, IOException {
		
		campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		campName=excel(file, 3, 1, 1) + getTimeStamp();
		CreateTemplate(campTempName);
		refresh();
		createCampaign_Using_CampaignTemplate(campTempName, campName,excel(file, 3,1,2),excel(file, 3,1,3));
		
	}

	@Test(priority = 6)
	public static void VerifyCampaignname_Validations_82727() throws InterruptedException, IOException {
		refresh();
		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);
		
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"CampaignTemplates");
		//	pause(1000);
		click(LocType.xpath, CampaignPor_TemplatePage.CampTempTD1checkbox,"CampTempTD1 checkbox");	
		//	pause(2000);
		click(LocType.id, CampaignPor_TemplatePage.CreateCampaignUsingTemplate,"CreateCampaignUsingTemplate Button");

		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignUsingTemplateDialog,"CreateCampaignUsingTemplateDialog - YES Button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName, " CampaignName :  ",excel(file, 3, 1, 5));
		WebElement error1=identifyElement(LocType.xpath, CampaignPor_TemplatePage.CampDescForm);
		childTest.log(Status.INFO, "Error Message :  "+error1.getText());
		drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.CampDescForm);
		childTest.addScreenCaptureFromPath(captureScreen());
		//pause(2000);
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName, " CampaignName :  ",excel(file, 3, 2, 5));
		WebElement error2=identifyElement(LocType.xpath, CampaignPor_TemplatePage.CampDescForm1);
		childTest.log(Status.INFO, "Error Message :  "+error2.getText());
		drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.CampDescForm1);
		//pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
	}

	@Test(priority = 7)
	public static void Campaign_Enddategreater_Startdate_82728() throws InterruptedException, IOException {
		//	signin();
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		
		campName=excel(file, 3, 1, 1) + getTimeStamp();

		click(LocType.linkText, "Campaigns","Campaigns");
		pause(7000);
		//javaScriptClick(LocType.xpath, "//li[@id='CreateCampaign']/a");
		click(LocType.xpath, "//li[@id='CreateCampaign']/a","CreateCampaign");
		pause(2000);
		DTA_SendKeys(LocType.id, "campaignName"," CampaignName :  ","campTemp_"+getTimeStamp());
		pause(2000);
		select_Dropdown_Value(LocType.name, "campaignBrand", " Brand :  ",excel(file, 3,1,4));
		select_Dropdown_Value(LocType.id, "campaignType", " CampaignType :  ",excel(file, 3,1,2));
		DTA_SendKeys(LocType.name, "campaignVinCriteria", " VinCriteria :  ",excel(file, 3,1,3));
		pause(2000);
		click(LocType.xpath, "//ng-form[@id='CampaignCreateViewForm']/div[2]/label[7]/span","Execution Settings");

		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, "09-20-2020  05:28:00");
		childTest.log(Status.INFO, "campaigns_StartDate : 09-20-2020  05:28:00");
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, "09-15-2020  05:28:00");
		childTest.log(Status.INFO, "campaigns_EndDate : 09-15-2020  05:28:00");
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_WifiExpirationDate, "09-17-2020  05:28:00");
		childTest.log(Status.INFO, "campaigns_WifiExpirationDate : 09-17-2020  05:28:00");
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, "09-20-2020  05:28:00");

		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_WifiExpirationDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_EndDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_StartDateCAL).click();
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, "09-20-2020  05:28:00");
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, "09-15-2020  05:28:00");
		pause(3000);
		//childTest.addScreenCaptureFromPath(captureScreen());
		DTA_SendKeys(LocType.id, CampaignPortalReg_Page1.campaigns_MaxRetry," Max Retry No. :  ",excel(file, 0, 2, 12));
		pause(3000);
		WebElement errormsg=identifyElement(LocType.xpath, "//ng-form[@id='CampExecSettForm']/div/div/div/fieldset/div/div[1]/div[3]/div/span");
		childTest.log(Status.INFO, " Error info : " + errormsg.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		//click(LocType.xpath, CampaignPortalReg_Page1.btnRerun);
	}

	@Test(priority = 8)
	public static void VerifyvalidationforupdateStartTime_82729() throws IOException, InterruptedException {
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"CampaignTemplates");
		pause(1000);
		click(LocType.xpath, CampaignPor_TemplatePage.CampTempTD1checkbox,"CampTempTD1-Checkbox");	
		pause(2000);
		click(LocType.id, CampaignPor_TemplatePage.CreateCampaignUsingTemplate,"CreateCampaignUsingTemplate Button");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignUsingTemplateDialog,"CreateCampaignUsingTemplateDialog - YES Button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName," CampaignName :  ", excel(file, 3, 1, 1)+getTimeStamp());
		pause(2000);
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.txtBrand, " Brand :  ",excel(file, 3, 1, 4));
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.campaignType, " CampaignType :  ", excel(file, 3, 1, 2));
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignVinCriteria, " VinCriteria :  ",excel(file, 3, 1, 3));
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		click(LocType.xpath, CampaignPor_TemplatePage.ExecutionSettings,"ExecutionSettings");
		select_Dropdown_Value(LocType.xpath, CampaignPor_TemplatePage.Server_Initiated, " Server Initiated :  ",excel(file, 3, 1, 7));
		select_Dropdown_Value(LocType.xpath, CampaignPor_TemplatePage.Push_Time_Zone, " Push Time Zone :  ",excel(file, 3, 1, 8));
		pause(2000);
		typeDateTIMEIntheCalendar(LocType.id, CampaignPor_TemplatePage.campaignPushFromTime, excel(file, 3, 1, 9));
		pause(2000);
		//click(LocType.id, CampaignPor_TemplatePage.campaignPushFromTime);
		typeDateTIMEIntheCalendar(LocType.id, CampaignPor_TemplatePage.campaignPushToTime, excel(file, 3, 1, 10));
		pause(1000);
		click(LocType.xpath, CampaignPor_TemplatePage.campaignPushFromTimeBTN,"campaignPushFromTimeBTN");
		pause(1000);
		click(LocType.xpath, CampaignPor_TemplatePage.campaignPushToTimeBTN,"campaignPushToTimeBTN");
		pause(2000);

		click(LocType.xpath, CampaignPor_TemplatePage.campaignPushToTimeBTN,"campaignPushToTimeBTN");
		//	pause(1000);
		//	click(LocType.xpath, CampaignPor_TemplatePage.campaignPushToTimeBTN);
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.MaxRetryNum, " Max Retry No. :  ",excel(file, 3, 1, 6));

		//DTA_SendKeys(LocType.id, "campaignMaxRetryNumber", excel(file, 3, 1, 6));
		pause(10000);
		//getText(LocType.xpath, CampaignPor_TemplatePage.pushFromtimebeforepushTotime + " : ERROR");
		//STG
		WebElement errorMsg1=identifyElement(LocType.xpath, "/html/body/div/div/div/div[2]/div[2]/div/div/div[2]/ng-form/div[2]/section[5]/div/campaignexecutionsettings/ng-form/div/div/div/fieldset/div/div[1]/div[6]/div/span[2]");
		childTest.log(Status.INFO, "Errormsg :  " +errorMsg1);
		//drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.pushFromtimebeforepushTotime);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());	

	}

	@Test(priority = 9)
	public static void campaignDraft_82730() throws InterruptedException, IOException {
		
		campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		campName=excel(file, 3, 1, 1) + getTimeStamp();
		refresh();
		CreateTemplate(campTempName);
		createCampaign_Using_CampaignTemplate(campTempName, campName,excel(file, 3,1,2),excel(file, 3,1,3));
	}

	@Test(priority = 10)
	public static void campaign_Onging_82731() throws InterruptedException, IOException {
		
		campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		campName=excel(file, 3, 1, 1) + getTimeStamp();

		CreateTemplate(campTempName);
		refresh();
		createCampaign_Using_CampaignTemplate(campTempName, campName,excel(file, 3,1,2),excel(file, 3,1,3));
		//refresh();
		pause(2000);
		click(LocType.xpath,CampaignPor_TemplatePage.TD1Checkbox,"TD1-Checkbox");
		click(LocType.xpath,CampaignPor_TemplatePage.TD1Checkbox,"TD1-Checkbox");
		pause(2000);
		click(LocType.xpath, CampaignPor_TemplatePage.btnRUN,"RUN Button");
		
		pause(7000);

		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();

		DTA_SendKeys(LocType.id, "txtCampaignName"," CampaignName :  ", campName);
		pause(1000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button","Apply Button");
		pause(5000);
		//refresh();

		WebElement ongoing=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName +"- Campaign Status : "+ongoing.getText());
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
	}

	public static void CreateTemplate(String campTempName) throws InterruptedException, IOException {
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"Campaign Templates");
		pause(2000);
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaign,"NEW Button");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		DTA_SendKeys(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignModal_NAME," CampaignTemplate Name :  ", campTempName);		
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignModal_SAVE,"SAVE Button");
		//pause(2000);
		//childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		WebElement temp=identifyElement(LocType.xpath, CampaignPor_TemplatePage.grid_TR1);
		childTest.log(Status.INFO, "Created CampaignTemplate Details : "+temp.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		
	}

	public static void Delete_CampaignTemplate(String campTempName) throws IOException, InterruptedException {
		//refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		//campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		CreateTemplate(campTempName);
		//refresh();
		pause(5000);
		drawBorder(driver, LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td");
		click(LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td",campTempName+"-Checkbox");
		pause(2000);
		click(LocType.xpath, CampaignPor_TemplatePage.DeleteCampaign,"Delete Button ");

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.DeletePrompt,"Delete confirmation - Yes Button");
		drawBorder(driver, LocType.xpath, CampaignPor_TemplatePage.DeletePrompt);
		pause(10000);
		childTest.addScreenCaptureFromPath(captureScreen()).info( campTempName+" : Deleted ");
		//childTest.log(childTest.addScreenCaptureFromPath(captureScreen()).info(" : Deleted"));
	}

	public static void createCampaign_Using_CampaignTemplate(String campTempName,String campName,String campaignType,String vin) throws InterruptedException, IOException {
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"CampaignTemplates");
		click(LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td",campTempName+"-Checkbox");
		pause(2000);
		click(LocType.id, CampaignPor_TemplatePage.CreateCampaignUsingTemplate,"CreateCampaignUsingTemplate Button");
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignUsingTemplateDialog,"CreateCampaignUsingTemplateDialog - YES Button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName, " CampaignName :  ",campName);
		pause(2000);
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.txtBrand, " Brand :  ", excel(file, 3,1,4));
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.campaignType, " CampaignType :  ",campaignType);
				
		pause(2000);
		
		//select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type : ", "IVI");
		//click(LocType.id, "btnRightECU", " ADD button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignVinCriteria, " VinCriteria :  ",vin);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CampaignCreateViewForm,"Execution Settings");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.MaxRetryNum, " Max. RetryNo. :  ",excel(file, 3, 1, 6));
		click(LocType.id, CampaignPor_TemplatePage.btnSave,"SAVE Button");
		pause(5000);


		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();


		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		//refresh();
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.txtCampaignName, " CampaignName :  ", campName);
		//pause(2000);
		WebElement Draft=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " Campaign Status : "+Draft.getText());
		Assert.assertEquals(Draft.getText(), "Draft");
		drawBorder(driver, LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		//pause(4000);
		
	}
}
