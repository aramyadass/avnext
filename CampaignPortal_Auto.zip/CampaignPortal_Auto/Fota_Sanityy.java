package CampaignPortal_Auto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.CampaignPor_TemplatePage;
import CampaignPortal_Pages.CampaignPortalReg_Page1;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.PagesAdmin_CampaignLogs;
import CampaignPortal_Pages.PagesCampaignTemplate;
import CampaignPortal_Pages.PagesExtraInfo;
import CampaignPortal_Pages.PagesScomo;
import CampaignPortal_Pages.PagesSearchFunctionality;
import CampaignPortal_Pages.Pages_CheckStatus;

public class Fota_Sanityy extends ReUsableMethods{

	static String campaignName;
	static String campTempName;
	static String  campName;

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String vin="where c.vin ='VINFAKE0021022019'";
	
	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}


	@Test(priority = 1)
	public static void readCSV_Downloaded70176() throws InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("read CSV_ Downloaded 70176");
		//System.out.println(" TC : readCSV_Downloaded70176");
		click(LocType.linkText,"Campaigns", "Campaigns Module");

		pause(4000);
		click(LocType.xpath,PagesSearchFunctionality.SelectStatus,"SelectStatus");
		click(LocType.xpath,PagesSearchFunctionality.selectFinishedStatus,"selectFinishedStatus");
		click(LocType.xpath,PagesSearchFunctionality.CreatedBy,"CreatedBy");
		click(LocType.xpath,PagesSearchFunctionality.Apply,"Apply");
		pause(5000);
		click(LocType.xpath,PagesSearchFunctionality.CampaignName,"Campaign Name");


		WebElement campaign=identifyElement(LocType.xpath, PagesSearchFunctionality.CampaignName);
		//String campaignName=getText(LocType.xpath, PagesSearchFunctionality.CampaignName);
		childTest.log(Status.INFO, "Selected campaignName : "+campaign.getText());
		pause(5000);
		click(LocType.xpath,PagesExtraInfo.ExecutionLogs,"ExecutionLogs");
		pause(2000);
		WebElement getName = driver.findElementByXPath("//*[@id='content7']/div/campaignlogs/div[3]/div[2]/div/span");
		String ABC = getName.getText();
		System.out.println(ABC);
		childTest.log(Status.INFO,"Execution Logs Name : "+ABC);
		pause(2000);
		for (int i = 0; i < ABC.length(); i++) {
			String[] namesplit = ABC.split("_");
			String name = namesplit[1];
			System.out.println("The name is "+name);
			childTest.log(Status.INFO, "The name of campaign : "+name);	
		}
		pause(5000);
		click(LocType.xpath,PagesExtraInfo.Description,"Description");
		pause(4000);
		try {
			click(LocType.xpath,PagesSearchFunctionality.DownloadButton, "Download Button");	
		} catch (Exception e) {
			click(LocType.xpath,PagesSearchFunctionality.DownloadButton, "Download Button");
		}

		//TO Read lastDownloaded File
		readDownloadLastFile();

		//	btnClick("//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]", "OK Button");
		pause(4000);
	}

	@Test(priority = 2)
	public static void CampaignInventory_70177() throws IOException, InterruptedException {
		campaignName=excel(file,5,0,1)+getTimeStamp();
		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);

		//childTest=parentTest.createNode("CampaignInventory_70177");
		//System.out.println(" TC : CampaignInventory_70177");
		//childTest.log(Status.INFO, " URL :  "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText,"Campaigns", "Campaigns");
		//childTest.log(Status.INFO, "Logged into the Campaign Portal");

		pause(7000);
		click(LocType.xpath, Pages1.New,"NEW Button");
		pause(4000);
		enterText(Pages1.Campaign_Title, "CampaignName :  ", campaignName);
		selectDropdown(Pages1.SelectBrand, "Brand :  ", excel(file,5,15,1));
		selectDropdown(Pages1.SelectCampaignType, "CampaignType :  ",excel(file,5,16,1));
		enterText(Pages1.Campaign_Vin, " VIN :  ",excel(file,5,14,1));

		pause(7000);
		click(LocType.xpath, "//ng-form[@id='CampaignCreateViewForm']/div[2]/label[7]/span", "Execution Settings ");
		pause(2000);
		ClearText("//input[@id='campaignMaxRetryNumber']");
		pause(2000);
		DTA_SendKeys(LocType.xpath, "//input[@id='campaignMaxRetryNumber']", "Max Retry :  ", "5");
		//enterText("//input[@id='campaignMaxRetryNumber']", "0", "Max Retry : 2");

		pause(4000);
		click(LocType.xpath,Pages1.Save_Campaign, "Save Button");

		pause(7000);
		//ExcludedVInsPOpup();

		pause(4000);
		click(LocType.xpath,"//input[@data-campname='"+campaignName+"']", campaignName+" Campaign-Checkbox");

		click(LocType.xpath,Pages1.Run_Campaign, "Run Button");
		pause(2000);
		/*
		try {
			movetoElement(LocType.xpath, "//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]", "Excluded vins popup- YES Button");
			click(LocType.xpath, "//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]", "Excluded vins - YES Button");
		} catch (Exception e) {
			System.out.println("No Excluded vins present");
		}
		 */
		pause(10000);
		WebElement web = driver.findElementByXPath("//td[.='"+campaignName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());

		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				click(LocType.xpath,Pages1.xLogin, "Login Button");
				pause(9000);
				click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
				pause(10000);

				enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campaignName);
				pause(5000);
				click(LocType.xpath,Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
				//getText(LocType.xpath,Pages1.xCampaignStatus);

				childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
			}
		}
		driver.switchTo().window(parentWinHandle);
		driver.switchTo().window(lastWindowHandle);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");

		btnClick_link(campaignName);
		childTest.log(Status.INFO, "Click on campaign :  "+campaignName);
		pause(2000);
		scrollPageBy(0, 1000);
		click(LocType.xpath,Pages1.Stop, " STOP Button ");	
		pause(4000);
		//btnClick(Pages1.StopSure);
		btnClick(Pages1.StopConfirmation, "Stop_Campaign_Confirm Yes");
		pause(15000);

		driver.navigate().refresh();
		pause(5000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");


		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());

		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());

		childTest.log(Status.INFO, "Campaign Portal Status : "+INVstatusOfCampaign_Finish.getText());
		//childTest.addScreenCaptureFromPath(captureScreen());

		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

			}
		}

		driver.switchTo().window(parentWinHandle); 
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		// scrollToElement(excel(file,2,0,1));
		click(LocType.linkText, campaignName, campaignName);
		//btnClick_link(campaignName);
		System.out.println("Click on "+campaignName);
		childTest.log(Status.INFO, "click on  "+campaignName);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs");
		pause(1000);
		WebElement NoOfRERUN=identifyElement(LocType.xpath, "//*[@id='DivCampaignLogs']/div[2]/div/span");
		System.out.println("No Of RERUN1 : "+NoOfRERUN.getText());
		childTest.log(Status.INFO, "No Of RERUN1 : "+NoOfRERUN.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[1]/span", "Description");

		scrollPageBy(0, 1000);
		pause(5000);
		click(LocType.xpath,PagesScomo.Rerun, "RERUN Button");
		pause(5000);
		click(LocType.xpath,PagesScomo.RerunConfirm, "RerunConfirm - Yes");
		pause(4000);
		movetoElement(LocType.xpath, PagesScomo.ExecutionSettings2, "ExecutionSettings");
		click(LocType.xpath,PagesScomo.ExecutionSettings2, "ExecutionSettings");
		pause(9000);


		/*
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.Server_Initiated, excel(file, 2, 1, 6));
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.Push_Time_Zone, excel(file, 2, 1, 7));
		pause(2000);
		typeDateTIMEIntheCalendar(LocType.id, NRECampaignsPage.campaignPushFromTime, excel(file, 2, 1, 8));
		pause(2000);
		click(LocType.id, NRECampaignsPage.campaignPushFromTime,"campaignPushFromTime");
		typeDateTIMEIntheCalendar(LocType.id, NRECampaignsPage.campaignPushToTime, excel(file, 2, 1, 9));
		pause(2000);
		 */
		/*
		click(LocType.xpath, Pages1.caladerStartTime," calader StartTime : "+excel(file, 5, 1, 1));
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerStartTime, excel(file, 5, 1, 1));
		pause(2000);

		click(LocType.xpath, Pages1.caladerEndTime," calader EndTime :  "+excel(file, 5, 2, 1));
		click(LocType.xpath, Pages1.caladerEndTime," calader EndTime :  "+excel(file, 5, 2, 1));
		pause(2000);
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerEndTime, excel(file, 5, 2, 1));
		pause(2000);

		click(LocType.xpath, Pages1.caladerWIFIexpireTime," calader WIFI expireTime :  "+excel(file, 5, 3, 1));
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerWIFIexpireTime, excel(file, 5, 3, 1));
		pause(1000);
		click(LocType.xpath, Pages1.caladerStartTime," calader StartTime");
		pause(2000);
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerStartTime, excel(file, 5, 1, 1));
		pause(2000);


		pause(2000);
		ClearText("//input[@id='campaignMaxRetryNumber']");
		DTA_SendKeys(LocType.xpath, "//input[@id='campaignMaxRetryNumber']", "Max Retry :  ","2");
		pause(4000);
		 */

		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, getDateTime());
		childTest.log(Status.INFO, "campaigns_StartDate : "+getDateTime());
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, getDateTime1day(2));
		childTest.log(Status.INFO, "campaigns_EndDate : "+getDateTime1day(2));
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_WifiExpirationDate, getDateTime1day(1));
		childTest.log(Status.INFO, "campaigns_WifiExpirationDate :  "+getDateTime1day(1));
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, getDateTime());

		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_WifiExpirationDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_EndDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_StartDateCAL).click();
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, getDateTime());
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, getDateTime1day(2));
		pause(3000);
		//childTest.addScreenCaptureFromPath(captureScreen());
		DTA_SendKeys(LocType.id, CampaignPortalReg_Page1.campaigns_MaxRetry," Max Retry No. :  ","2");


		click(LocType.xpath,Pages1.Rerun, "Rerun button");
		pause(3000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath,Pages1.RerunConfirmation, "RerunConfirm2 - Yes");

		pause(15000);

		childTest.log(Status.PASS, "Rerun Campaign successful.");
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(10000);
		WebElement web1 = driver.findElementByXPath("//td[.='"+campaignName+"']//following-sibling::td[7]/label");
		String status1 = web1.getText();
		System.out.println("Caampaign status is : "+status1);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign1.getText());

		WebElement CampaignDetails_Onging1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging1.getText());

		pause(7000);

		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

			}
		}

		driver.switchTo().window(parentWinHandle); 
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		btnClick_link(campaignName);
		childTest.log(Status.INFO,  "Click on :  "+campaignName);
		pause(4000);
		click(LocType.xpath,Pages1.Stop, "Stop Campaign");	
		pause(6000);
		//btnClick(Pages1.StopSure);
		click(LocType.xpath,"//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]", "StopConfirm - Yes");
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(10000);

		WebElement CampaignStatus=identifyElement(LocType.xpath, "//td[.='"+campaignName+"']//following-sibling::td[7]/label");


		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");
		childTest.log(Status.INFO, "Campaign Status :  "+CampaignStatus.getText());
		WebElement INV_CampaignDetails_Finish1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish1.getText());

		childTest.log(Status.INFO, "Rerun Campaign stoppped");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement xCampaignStatus=identifyElement(LocType.xpath, "//*[@id='campaign-status-widget']/div/div[2]/div/span");

				//getTextFromElement("//*[@id='campaign-status-widget']/div/div[2]/div/span", "xCampaignStatus");
				childTest.log(Status.INFO, "Rerun Stopped RedBend Status :  "+xCampaignStatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle);
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		// scrollToElement(excel(file,2,0,1));
		btnClick_link(campaignName);
		System.out.println("Click on "+campaignName);
		childTest.log(Status.INFO, "click on  "+campaignName);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs");
		pause(7000);
		WebElement NoOfRERUN2=identifyElement(LocType.xpath, "//*[@id='DivCampaignLogs']/div[2]/div/span");
		System.out.println("No Of RERUN2  : "+NoOfRERUN2.getText());
		childTest.log(Status.INFO, "No Of RERUN2 : "+NoOfRERUN2.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);

		click(LocType.xpath, "//*[@id='CampaignTabs']/label[1]/span", "Description Tab");
		pause(1000);
	}

	@Test(priority = 3)
	public static void Campaign_SCOMOIVI_70178() throws IOException, InterruptedException {
		campaignName=excel(file,5,8,1)+getTimeStamp();
		//enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("Campaign_SCOMOIVI_70178");
		//System.out.println(" TC : Campaign_SCOMOIVI_70178");
		Campaign_SCOMO(campaignName,"IVI");



		//RUN : //*[@id='tab-runHistory-link']/span[2]
	}

	@Test(priority = 4)
	public static void Campaign_SCOMOIVC_70179() throws IOException, InterruptedException {
		campaignName=excel(file,5,4,1)+getTimeStamp();
		//enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("Campaign_SCOMOIVC_70179");
		//System.out.println(" TC : Campaign_SCOMOIVC_70179");
		Campaign_SCOMO(campaignName,"IVC");
	}

	@Test(priority = 5)
	public static void Searchfunctionnality_70183() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("Searchfunctionnality_70183");
		//System.out.println(" TC : Searchfunctionnality_70183");
		btnClick_link("Campaigns");

		childTest.log(Status.PASS, "Logged into the Campaign Portal");

		pause(5000);
		WebElement campaign1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[7]");
		childTest.log(Status.INFO, "Campaign status : "+campaign1.getText());
		//,"CampaignStatus");
		//getTextFromElement("//table[@id='entry-grid']/tbody/tr/td[7]","CampaignStatus");
		childTest.log(Status.INFO, "Created by is : ");
		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath,PagesSearchFunctionality.CheckCreatedBy,"CreatedBy");
		ClearText(PagesSearchFunctionality.CreatedBy);

		click(LocType.xpath,PagesSearchFunctionality.SelectStatus,"SelectStatus");
		click(LocType.xpath,PagesSearchFunctionality.selectDraftStatus,"selectDraftStatus");
		click(LocType.xpath,PagesSearchFunctionality.CreatedBy,"CreatedBy");
		click(LocType.xpath,PagesSearchFunctionality.Apply,"Apply");
		pause(5000);
		//getTextFromElement("//table[@id='entry-grid']/tbody/tr/td[9]","CampaignStatus");
		WebElement status=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]");
		childTest.log(Status.INFO, " Status is : "+status.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
	}


	@Test(priority = 6)
	public static void createCampUsingCampTemplate_70184() throws InterruptedException, IOException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("createCampUsingCampTemplate_70184");
		//System.out.println(" TC : createCampUsingCampTemplate_70184");
		createCampaignUsingCampaignTemplate_70184();

	}


	@Test(priority = 7)
	public static void CampaignExtraInfo_70185() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("CampaignExtraInfo_70185");
		//System.out.println(" TC : CampaignExtraInfo_70185");
		btnClick_link("Campaigns","Campaigns");
		pause(5000);
		select_Dropdown_Value(LocType.xpath, "//*[@id='ddType']", "Campaign Type : ", "SCOMO");
		click(LocType.xpath,PagesSearchFunctionality.SelectStatus," Campaign Status  ");
		click(LocType.xpath,PagesSearchFunctionality.selectFinishedStatus," Select Finished Status");
		click(LocType.xpath,PagesSearchFunctionality.CheckCreatedBy,"CreatedBy");
		click(LocType.xpath,PagesSearchFunctionality.Apply,"Apply");
		//driver.navigate().refresh();
		pause(9000);
		WebElement CampaignDetails=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Details : "+CampaignDetails.getText());
		click(LocType.xpath,"//table[@id='entry-grid']/tbody/tr/td[2]/a","Select Above Campaign");


		//identify the vin number in the info
		//identify the cross button
		//identify the json file button
		pause(4000);
		movetoElement(LocType.xpath,PagesExtraInfo.ExecutionLogs,"ExecutionLogs");
		click(LocType.xpath,PagesExtraInfo.ExecutionLogs,"ExecutionLogs");
		pause(7000);
		scrollToElement(PagesExtraInfo.More);
		click(LocType.xpath, PagesExtraInfo.More, "MORE button");
		pause(5000);
		click(LocType.xpath,"//*[@id='modalBody']/div/span[10]","InventoryJson");//InJson
		pause(10000);
		readDownloadLastFile();
		//  read_CSV_Total_File(new File("C:\\Users\\z028979\\Downloads\\InventoryData (2).json"));
		pause(2000);
		click(LocType.xpath,"//*[@id='modalBody']/div/span[12]","EventHistoryJson");//EvJson
		pause(10000);
		readDownloadLastFile();
		//read_CSV_Total_File(new File("C:\\Users\\z028979\\Downloads\\EventHistoryData (3).json"));
		pause(7000);
		/*
		click(LocType.xpath,"//*[@id='modalBody']/div/span[11]","InventoryView");//InVi
		click(LocType.xpath,"//*[@id='jsonview']/div/div/div[1]/button","InventoryViewClose");//InCl
		click(LocType.xpath,"//*[@id='modalBody']/div/span[13]","EventHistoryView");//EvVi

		click(LocType.xpath,"//*[@id='jsonview']/div/div/div[1]/button","EventHistoryClose");//EnCl
		click(LocType.xpath,"//*[@id='jsonview']/div/div/div[1]/button","EventHistoryClose");//EnCl
		 */
		//childTest.log(Status.PASS, "JsonEventsHistory ");
		childTest.addScreenCaptureFromPath(captureScreen());

	}


	@Test(priority = 8)
	public static void FOTASanity_CheckStatus_70187() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("FOTASanity_CheckStatus_70187");
		//System.out.println(" TC : FOTASanity_CheckStatus_70187");
		pause(7000);
		btnClick_link("Campaigns","Campaigns");
		pause(10000);	
		//childTest.log(Status.PASS, "Logged into the Campaign Portal");
		
		//test.log(LogStatus.PASS, "Logged into the Campaign Portal");
		pause(5000);

		click(LocType.xpath,PagesSearchFunctionality.SelectStatus,"Campaign Status");
		btnClick(PagesSearchFunctionality.selectFinishedStatus,"select Finished Status");
		selectDropdown(Pages_CheckStatus.Select_type,"Campign Type : ","SCOMO");
		btnClick(PagesSearchFunctionality.Apply,"Select_type");
		
		pause(2000);
		btnClick("//table[@id='entry-grid']/tbody/tr/td[2]/a","Check Campaign Status");
		btnClick(PagesExtraInfo.ExecutionLogs,"Execution Logs");
		pause(9000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[1]/span", "Description");
		pause(2000);
		btnClick(PagesExtraInfo.ExecutionLogs,"Execution Logs");
		WebElement Status1=identifyElement(LocType.xpath, Pages_CheckStatus.Ex_Status);
		pause(2000);
		childTest.log(Status.INFO, "Status : "+Status1.getText());
		pause(2000);
		//getTextFromElement(Pages_CheckStatus.Ex_Status,"Ex_Status");
		childTest.addScreenCaptureFromPath(captureScreen());
		WebElement softwareVersioin=identifyElement(LocType.xpath, Pages_CheckStatus.Ex_softwareVersion);
		childTest.log(Status.INFO, "softwareVersioin : "+softwareVersioin.getText());
		//getTextFromElement(Pages_CheckStatus.Ex_softwareVersion,"Ex_softwareVersion");
		
		
	}

	@Test(priority = 9)
	public static void CheckCampaignLogs_70189() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("CheckCampaignLogs_70189");
		//System.out.println(" TC : CheckCampaignLogs_70189");
		//driver.findElementByLinkText("Campaigns").click();
		click(LocType.linkText, "Campaigns", "Campaigns Module");
		pause(5000);	

		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"','_blank');");

		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";
		childTest.log(Status.INFO, "Navigated to Admin Portal ");
		childTest.addScreenCaptureFromPath(captureScreen());
		//test.log(LogStatus.PASS, "Navigated to Admin Portal "+test.addScreenCapture(BaseClass.captureScreen()));

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{

				driver.switchTo().window(handle);
				enterUrl(AdminPortal.adminPortal_URL);

				pause(5000);
				btnClick(PagesAdmin_CampaignLogs.Admin_CampaignManagement,"Admin_CampaignManagement");	
				pause(5000);
				btnClick(PagesAdmin_CampaignLogs.Admin_CampaignLogs,"Admin_CampaignLogs");
				pause(5000);
				enterText(PagesAdmin_CampaignLogs.Admin_KeywordSearch,"VIN* : ", "VINFAKE0021022019");
				pause(5000);
				btnClick(PagesAdmin_CampaignLogs.Admin_Search,"Admin_Search");
				//   btnClick(PagesAdmin_CampaignLogs.Admin_Search);
				pause(20000);
				btnClick("//*[@id='JColResizer1']/tbody/tr[1]/td[1]","selectCampaign");


				driver.close();
				pause(4000);
				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
				driver.switchTo().window(tabs2.get(1));  
				pause(10000);
				btnClick(PagesExtraInfo.ExecutionLogs,"ExecutionLogs");
				childTest.log(Status.INFO, "navigated to Campaign ");
				childTest.addScreenCaptureFromPath(captureScreen());
				//test.log(LogStatus.PASS, "navigated to Campaign "+test.addScreenCapture(BaseClass.captureScreen()));
				driver.switchTo().window(tabs2.get(1));  
				pause(2000);
				scrollPageBy(0, 2500);
				//scrollToElement("//table[@id='JColResizer1']/tbody/tr[1]/td[8]/a/i");
				pause(20000);
				btnClick("//*[@id='grid-entry-grid']/tbody/tr/td[13]/a","More");
				btnClick("//div[@id='modalBody']/div/span[10]","Inventory Json");//InJson
				pause(4000);
				readDownloadLastFile();

				btnClick("//div[@id='modalBody']/div/span[12]","EventHistory Json");//EvJso
				pause(4000);
				readDownloadLastFile();
				pause(4000);
				//btnClick("//*[@id='modalBody']/div/span[11]","ViewInventory");//InVi
				pause(2000);
				//btnClick("//*[@id='ExtraInfoModel']/div/div/div[1]/button/span","CloseInventory");//InCl
				//pause(4000);
				//btnClick("//*[@id='modalBody']/div/span[13]","ViewEventHistory");//EvVi
				//btnClick("//*[@id='jsonview']/div/div/div[1]/button/span","CloseEventHostory");//EnCl

				childTest.log(Status.INFO, "Status Check ");
				childTest.addScreenCaptureFromPath(captureScreen());

				pause(2000);
				//	driver.close();
				//driver.switchTo().window(winHandles);
				//test.log(LogStatus.PASS, "Status Check "+test.addScreenCapture(BaseClass.captureScreen()));
				pause(4000);
				getSwitchWindow(1);
				//driver.close()
			}
		}
	}	



	public static void Campaign_SCOMO(String campaignName,String campaignType) throws IOException, InterruptedException {

		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);

		click(LocType.linkText,"Campaigns", "Campaigns");
		//childTest.log(Status.INFO, "Logged into the Campaign Portal");

		pause(7000);
		click(LocType.xpath, Pages1.New,"NEW Button");
		pause(4000);
		enterText(Pages1.Campaign_Title,"Campaign Name :  ", campaignName);

		selectDropdown(Pages1.SelectBrand, "Brand :  ",excel(file,5,15,1));
		pause(2000);
		selectDropdown(Pages1.SelectCampaignType,"Campaign Type : ", "SCOMO");
		pause(2000);
		selectDropdown(PagesScomo.SelectECUtype,"ECU type :  ", campaignType);
		enterText(Pages1.Campaign_Vin,"VIN Criteria* - ", excel(file,5,14,1));
		pause(10000);
		click(LocType.xpath,PagesScomo.Contents,"Contents");	
		pause(7000);
		click(LocType.xpath,PagesScomo.SoftwareIVC, " Low Risk/Impact content checkbox");
		pause(5000);
		click(LocType.xpath,PagesScomo.DynamicHMI,"Dynamic HMI");
		pause(5000);
		click(LocType.xpath,PagesScomo.DownloadSilent,"Actions: Download Silent checkbox");
		pause(2000);
		click(LocType.xpath,PagesScomo.InstallSilent,"Actions: Install Silent checkbox");
		pause(2000);
		click(LocType.xpath,PagesScomo.ActivateSilent,"Actions: Activate Silent checkbox");
		btnClick(Pages1.Save_Campaign,"SAVE button");
		pause(10000);
		//childTest.log(Status.INFO, "Campaign campaign Passed");
		childTest.addScreenCaptureFromPath(captureScreen());

		//test.log(LogStatus.PASS, "Create Campaign Passed" +test.addScreenCapture(BaseClass.captureScreen()));
		//driver.navigate().refresh();
		pause(10000);

		click(LocType.xpath,"//input[@data-campname='"+campaignName+"']", campaignName+" - Campaign Checkbox");

		System.out.println("Found checkbox");
		click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
		pause(10000);

		WebElement statusICV=identifyElement(LocType.xpath, "//td[.='"+campaignName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campaignName+" status : "+statusICV.getText());
		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label","CampaignStatus");

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, campaignName+" Campaign Onging Details :  "+CampaignDetails_Onging.getText());
		//childTest.log(Status.INFO, "Run Campaign Status");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"','_blank');");

		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				click(LocType.xpath,Pages1.xLogin, "Login Button");
				pause(9000);
				click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
				pause(9000);
				click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
				pause(10000);

				enterText(Pages1.Campaign_Title, "Redbend CampaignName -: ", campaignName);
				pause(5000);
				click(LocType.xpath,Pages1.selectCampaign, "select_Campaign");
				pause(20000);
				WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);

				childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
				
			}
		}
		driver.switchTo().window(parentWinHandle);
		driver.switchTo().window(lastWindowHandle);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");
		btnClick_link(campaignName);
		childTest.log(Status.INFO, "Click on campaign :  "+campaignName);
		pause(2000);
		scrollPageBy(0, 1000);
		click(LocType.xpath,Pages1.Stop, " STOP Button ");	
		pause(4000);
		btnClick(Pages1.StopConfirmation, "Stop_Campaign_Confirm - Yes");
		pause(15000);

		driver.navigate().refresh();
		pause(5000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");

		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");		
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());

		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);

				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());
				
				

			}
		}

		//	driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(parentWinHandle); 
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		// scrollToElement(excel(file,2,0,1));
		btnClick_link(campaignName);
		System.out.println("Click on "+campaignName);
		childTest.log(Status.INFO, "click on  "+campaignName);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs");
		pause(1000);
		WebElement NoOfRERUN=identifyElement(LocType.xpath, "//*[@id='DivCampaignLogs']/div[2]/div/span");
		System.out.println("No Of RERUN0 : "+NoOfRERUN.getText());
		childTest.log(Status.INFO, "No Of RERUN0 : "+NoOfRERUN.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[1]/span", "Description");

		scrollPageBy(0, 1000);
		pause(5000);

		/*  WebElement element = driver.findElement(By.xpath("//*[@id='btnRerun']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);*/
		//scrollToElement(PagesScomo.Rerun);
		click(LocType.xpath,PagesScomo.Rerun,"Rerun Button");
		pause(2000);
		click(LocType.xpath,PagesScomo.RerunConfirm, "RerunConfirm popup - Yes");
		pause(4000);
		movetoElement(LocType.xpath,PagesScomo.ExecutionSettings2, "ExecutionSettings");
		pause(2000);
		click(LocType.xpath,PagesScomo.ExecutionSettings2, "ExecutionSettings");
		pause(5000);

		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, getDateTime());
		childTest.log(Status.INFO, "campaigns_StartDate : "+getDateTime());
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, getDateTime1day(2));
		childTest.log(Status.INFO, "campaigns_EndDate : "+getDateTime1day(2));
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_WifiExpirationDate, getDateTime1day(1));
		childTest.log(Status.INFO, "campaigns_WifiExpirationDate : "+getDateTime1day(1));
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate,getDateTime());

		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_WifiExpirationDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_EndDateCAL).click();
		pause(2000);
		driver.findElementByXPath(CampaignPortalReg_Page1.campaigns_StartDateCAL).click();
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_StartDate, getDateTime());
		typeDateTIMEIntheCalendar(LocType.id, CampaignPortalReg_Page1.campaigns_EndDate, getDateTime1day(2));
		pause(3000);
		//childTest.addScreenCaptureFromPath(captureScreen());
		DTA_SendKeys(LocType.id, CampaignPortalReg_Page1.campaigns_MaxRetry," Max Retry No. :  ","2");

		/*
		click(LocType.xpath, Pages1.caladerStartTime," calader StartTime "+excel(file, 5, 1, 1));
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerStartTime, excel(file, 5, 1, 1));
		pause(2000);

		click(LocType.xpath, Pages1.caladerEndTime," calader EndTime " +excel(file, 5, 2, 1) );
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerEndTime, excel(file, 5, 2, 1));

		pause(2000);

		click(LocType.xpath, Pages1.caladerWIFIexpireTime," calader WIFI expireTime");
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerWIFIexpireTime, excel(file, 5, 3, 1));
		pause(1000);
		click(LocType.xpath, Pages1.caladerStartTime," calader StartTime");
		pause(2000);
		typeDateTIMEIntheCalendar(LocType.xpath, Pages1.caladerStartTime, excel(file, 5, 1, 1));
		pause(2000);
		ClearText("//input[@id='campaignMaxRetryNumber']");
		DTA_SendKeys(LocType.xpath, "//input[@id='campaignMaxRetryNumber']","Max Retry No. : ", "2");
		 */
		pause(4000);
		click(LocType.xpath,PagesScomo.Rerun, "Rerun Button");
		pause(3000);
		click(LocType.xpath,"//div[@class='modal fade alert-prompt ng-scope show']/div/div/div[2]/div/button[1]", "RerunConfirm popup - Yes");
		pause(15000);

		childTest.log(Status.PASS, "Rerun Campaign successful.");
		childTest.addScreenCaptureFromPath(captureScreen());


		pause(10000);
		WebElement web1 = driver.findElementByXPath("//td[.='"+campaignName+"']//following-sibling::td[7]/label");
		String status1 = web1.getText();
		System.out.println("Caampaign status is : "+status1);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign1.getText());

		WebElement CampaignDetails_Onging1=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging1.getText());

		pause(7000);

		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

			}
		}

		driver.switchTo().window(parentWinHandle); 
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		btnClick_link(campaignName);
		pause(4000);
		click(LocType.xpath,Pages1.Stop, "StopCampaign");	
		pause(6000);
		//btnClick(Pages1.StopSure);
		click(LocType.xpath,"//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]", "StopConfirm");
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(10000);

		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");

		WebElement statuss1=identifyElement(LocType.xpath, "//td[.='"+campaignName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campaignName+" Campaign Status : "+statuss1.getText());


		WebElement INV_CampaignDetails_Finish2=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish2.getText());



		childTest.log(Status.INFO, "Rerun Campaign stoppped");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement campaignst2=identifyElement(LocType.xpath, "//*[@id='campaign-status-widget']/div/div[2]/div/span");
				childTest.log(Status.INFO, campaignName+" Redbend status : "+campaignst2.getText());

				//getTextFromElement("//*[@id='campaign-status-widget']/div/div[2]/div/span", "xCampaignStatus");


				childTest.log(Status.INFO, "Rerun Stopped RedBend Status");
				childTest.addScreenCaptureFromPath(captureScreen());
				driver.close();
			}
		}

		driver.switchTo().window(parentWinHandle);
		pause(7000);
		childTest.log(Status.INFO, "Go to campaign portal");
		// scrollToElement(excel(file,2,0,1));
		btnClick_link(campaignName);
		System.out.println("Click on "+campaignName);
		childTest.log(Status.INFO, "click on  "+campaignName);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs Tab");
		pause(4000);
		WebElement NoOfRERUN2=identifyElement(LocType.xpath, "//*[@id='DivCampaignLogs']/div[2]/div/span");
		System.out.println("No Of RERUN1  : "+NoOfRERUN2.getText());
		childTest.log(Status.INFO, "No Of RERUN1 : "+NoOfRERUN2.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(7000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[1]/span", "Description Tab");
		pause(2000);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs Tab");
		pause(4000);
	}
	
	public static void createCampaignUsingCampaignTemplate_70184() throws InterruptedException, IOException
	{
		String tempName = "CampTempFotasanity"+getTimeStamp();
		//excel(file,2,13,1);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(5000);
		btnClick_link("Campaign Templates");
		
		pause(4000);

		btnClick(PagesCampaignTemplate.NewTemplate, "New Button");
		pause(2000);
		//btnClick(PagesCampaignTemplate.CampaignTemplate_Name,"CampaignTemplate_Name");
		enterText(PagesCampaignTemplate.CampaignTemplate_Name, "Temp Name : ",tempName); 
		childTest.addScreenCaptureFromPath(captureScreen());
		btnClick(PagesCampaignTemplate.CampaignTemplate_Save,"Save Button");
		//test.log(LogStatus.PASS, "Created Campaign Template"+test.addScreenCapture(BaseClass.captureScreen()));
		pause(5000);
		movetoElement(LocType.linkText, tempName,  tempName);
		click(LocType.linkText, tempName,tempName);
		//test.log(LogStatus.PASS, "Navigated to Campaign Portal "+test.addScreenCapture(BaseClass.captureScreen()));
		pause(2000);
		selectDropdown(Pages1.SelectBrand,"Brand", "RENAULT");
		selectDropdown(Pages1.SelectCampaignType,"Campaign Type","Inventory");
		enterText(Pages1.Campaign_Vin, vin,"Campaign_Vin");
		btnClick(PagesCampaignTemplate.CreateCampaign_Template,"CreateCampaign_Template");
		pause(5000);
		btnClick("//*[@data-ng-click='ConfirmCreateCampaignFromTemplate()']","ConfimTemplateCreation");
		//btnClick(PagesCampaignTemplate.CreateCampaign_Template_YES);
		pause(10000);
		ClearText("//*[@id='campaignName']");
		enterText(Pages1.Campaign_Title,"Campaign_Title : ", tempName);
		selectDropdown(Pages1.SelectBrand,"Brand : ", "RENAULT");
		selectDropdown(Pages1.SelectCampaignType,"Campaign Type : ", "Inventory");
		ClearText(Pages1.Campaign_Vin);
		enterText(Pages1.Campaign_Vin,"Vin criteria* : ", vin);
		childTest.addScreenCaptureFromPath(captureScreen());
		btnClick(Pages1.Save_Campaign,"Save_Campaign");
		pause(15000);
		//test.log(LogStatus.PASS, "Create Campaign Passed" +test.addScreenCapture(BaseClass.captureScreen()));
		//test.log(LogStatus.FAIL,sname+" Button click failed"+test.addScreenCapture(TestBase.captureScreen(xpath)));

		btnClick("//input[@data-campname='"+tempName+"']","SelectCheckbox");

		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign,"Run Button");
		pause(10000);
		getTextFromElement("//td[.='"+tempName+"']//following-sibling::td[7]/label","TemplateName");

		//driver.executeScript("window.open('https://xota.sit.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		//driver.executeScript("window.open('https://xota.stg.emea.avnext.net:8443/otaportal/#/auth/sign-in?next=%2Fdashboard', '_blank');");
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(10000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				enterText(Pages1.xUsername, AdminPortal.RedbendUser,AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, AdminPortal.RedbendPassword,AdminPortal.RedbendPassword);
				click(LocType.xpath,Pages1.xLogin, "Login Button");
			
				pause(9000);
				btnClick(Pages1.xCampaignManagement,"xCampaignManagement");
				pause(9000);
				btnClick(Pages1.xCampaignList,"xCampaignList");
				pause(10000);
				enterText("//*[@id='campaignName']","campaignName", tempName);
				pause(5000);
				btnClick("//*[@class='card-body-wrapper clearfix']/section/section/div/div/div/div","SelectCampaign");
				
				pause(20000);
				childTest.addScreenCaptureFromPath(captureScreen());
				getTextFromElement("//*[@id='campaign-status-widget']/div/div[2]/div/span","xCampaignStatus");

				//test.log(LogStatus.PASS, "Redbend Status "+test.addScreenCapture(BaseClass.captureScreen()));
			}
		}
		driver.switchTo().window(parentWinHandle);
		//close the parent window
		//driver.close();
		//at this point there is no focused window, we have to explicitly switch back to some window.
		driver.switchTo().window(lastWindowHandle);
		pause(5000);

		btnClick_link(tempName);
		btnClick(Pages1.Stop,"STOP Button");
		pause(6000);
		//btnClick(Pages1.StopSure);
		btnClick("//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]","STOP Confirm");
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(15000);
		driver.navigate().refresh();
		pause(10000);
		childTest.addScreenCaptureFromPath(captureScreen());
		getTextFromElement("//td[.='"+tempName+"']//following-sibling::td[7]/label","TemplateName");

		//test.log(LogStatus.PASS, "Campaign Portal Status"+test.addScreenCapture(BaseClass.captureScreen()));
		// driver.switchTo().window(handle);


		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				childTest.addScreenCaptureFromPath(captureScreen());
				getTextFromElement("//*[@id='campaign-status-widget']/div/div[2]/div/span","xCampaignStatus");

				//test.log(LogStatus.PASS, "Redbend Status "+test.addScreenCapture(BaseClass.captureScreen()));
				driver.close();
			}
		}
		driver.switchTo().window(parentWinHandle); 
	}
}

