package CampaignPortal_Auto;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.Pages1;

public class NRECampaignsSoftwareIVC extends ReUsableMethods{

	
	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String FotaType;
	static String ECUModel;
	static String campType;
	static String vin;
	static String fileNREswIVC=System.getProperty("user.dir")+"\\API mockfiles\\NRE SW IVC\\MockVespaVINFAKE0021022019.json";
	
	static String URL="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VINFAKE0021022019/upload";
	
	
	//@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}

	//@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");
		pause(2000);
	}
	
	public static void APicall(String file1) {
		myFirstRestAssuredClass.APICall(URL,file1);
	}
	
	
	//@Test(priority = 2)
	public static void NREswIVCPushMSG_82760() throws IOException, InterruptedException {
		campName="IVCPushMsg sw-"+ excel(file, 2, 1, 0)+ getTimeStamp(); 
		ECUModel=excel(file, 2, 1,3); 
		FotaType=excel(file, 2, 2, 5); 
		campType=excel(file, 2, 1, 2);
		
		getSwitchWindow(0);
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		String vin="where c.vin = 'VINFAKE0021022019'";
		NRECampaignsSoftwareIVI.NREIVCPushmsg(campName, campType, ECUModel,vin, FotaType);
	}

	//@Test(priority = 3)
	public static void NREIVCCampMultiVIN_82761() throws InterruptedException, IOException {

		campName="IVCMultiVIN sw-"+excel(file, 2, 1, 0)+ getTimeStamp();
		ECUModel=excel(file, 2, 1, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	//@Test(priority = 4)
	public static void NREIVCCampECUModel_82762() throws IOException, InterruptedException {

		campName="IVCECUModel sw-"+excel(file, 2, 1, 0) + getTimeStamp();
		ECUModel=excel(file, 2, 1, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);		
	}

	//@Test(priority = 5)
	public static void NREIVCLowRisk_82763() throws IOException, InterruptedException {

		campName="IVCLowRisk sw-"+excel(file, 2, 1, 0) + getTimeStamp();
		ECUModel=excel(file, 2, 1, 3);
		FotaType=excel(file, 2, 1, 5);
		campType=excel(file, 2, 1, 2);
		vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);
	}

	//@Test(priority = 6)
	public static void NREIVCRegularRisk_82764() throws IOException, InterruptedException {

		campName="IVCRegularRisk sw-"+excel(file, 2, 1, 0)+ getTimeStamp();
		ECUModel=excel(file, 2, 1, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
	}

	@Test(priority = 7)
	public static void NREIVCCriticalRisk_82765() throws IOException, InterruptedException {

		campName="IVCCriticalRisk -sw"+excel(file, 2, 1, 0)+ getTimeStamp();
		ECUModel=excel(file, 2, 1, 3);
		FotaType=excel(file, 2, 3, 5);
		campType=excel(file, 2, 1, 2);
		vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVC);
	/*
		System.out.println("File name : "+fileNREswIVC);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);
	*/
	}	
	
}
