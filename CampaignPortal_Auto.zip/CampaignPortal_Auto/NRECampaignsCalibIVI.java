package CampaignPortal_Auto;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;

public class NRECampaignsCalibIVI extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String FotaType;
	static String ECUModel;
	static String campType;


	static	String fileNRECallib=System.getProperty("user.dir")+"\\API mockfiles\\NRE calib\\MockVespaVINFAKE0021022019.json";
	static String URL="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VINFAKE0021022019/upload";


	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");

		pause(2000);

	}

	@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");

		pause(2000);
	}

	public static void APicall(String file1) {
		//childTest=parentTest.createNode("APicall");
		//	file1="C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE sw IVI\\MockNreSWVINFAKE0021022019.json";
		myFirstRestAssuredClass.APICall(URL,file1);
	}

	@Test(priority = 2)
	public static void NRECalibrationIVIPushMSG_82790() throws IOException, InterruptedException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("NRECalibrationIVIPushMSG_82790");
		System.out.println(" TC : NRECalibrationIVIPushMSG_82790");
		campName=excel(file, 2, 1, 0)+"calibIVIPushMsg" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 3, 2);

		//	String fileNRECallib=System.getProperty("user.dir")+"\\API mockfiles\\NRE calib\\MockVespaVINFAKE0021022019.json";
		//"C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE calib\\MockVespaVINFAKE0021022019.json";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNRECallib);
		System.out.println("File name : "+fileNRECallib);
		pause(2000);
		//VINFAKE0014092020
		String vin="where c.vin = 'VINFAKE0021022019'";
		NRECampaignsSoftwareIVI.NREIVCPushmsg(campName, campType, ECUModel,vin, FotaType);

	}

	@Test(priority = 3)
	public static void NRECalibrationIVIMultiVIN_82791() throws IOException, InterruptedException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("NRECalibrationIVIMultiVIN_82791");
		System.out.println(" TC : NRECalibrationIVIMultiVIN_82791");
		campName=excel(file, 2, 1, 0)+"calibIVIMultiVIN" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 3, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";

		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNRECallib);
		System.out.println("File name : "+fileNRECallib);
		pause(2000);
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType, ECUModel, FotaType, "where c.vin = 'VF1XHNFTAS2VAL002'");

		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);

	}

	@Test(priority = 4)
	public static void NRECalibrationIVIECUModel_82792() throws IOException, InterruptedException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		campName=excel(file, 2, 1, 0)+"calibIVIECUModel" + getTimeStamp();
		System.out.println(" TC : NRECalibrationIVIECUModel_82792");
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 3, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		//childTest=parentTest.createNode("NRECalibrationIVIECUModel_82792");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VINFAKE0021022019'");
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);

	}

	@Test(priority = 5)
	public static void NRECalibrationIVILowRisk_82793() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		campName=excel(file, 2, 1, 0)+"calibIVILowRisk" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 1, 5);
		campType=excel(file, 2, 3, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		//childTest=parentTest.createNode("NRECalibrationIVILowRisk_82793");
		System.out.println(" TC : NRECalibrationIVILowRisk_82793");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VINFAKE0021022019'");
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel, vin,FotaType);

	}

	@Test(priority = 6)
	public static void NRECalibrationIVIRegularRisk_82794() throws IOException, InterruptedException {
		//enterUrl(AdminPortal.campaignPortal_URL);
		campName=excel(file, 2, 1, 0)+"calibIVIRegularRisk" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 3, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		//childTest=parentTest.createNode("NRECalibrationIVIRegularRisk_82794");
		System.out.println(" TC : NRECalibrationIVIRegularRisk_82794");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VINFAKE0021022019'");
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);
	}

	@Test(priority = 7)
	public static void NRECalibrationIVICriticalRisk_82795() throws IOException, InterruptedException {
		
		campName=excel(file, 2, 1, 0)+"calibIVICritRisk" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 3, 5);
		campType=excel(file, 2, 3, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		//childTest=parentTest.createNode("NRECalibrationIVICriticalRisk_82795");
		//System.out.println(" TC : NRECalibrationIVICriticalRisk_82795");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VINFAKE0021022019'");
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);

	}

	@Test(priority = 8)
	public static void NRECalibrationIVIReadExportDATA_95607() throws IOException, InterruptedException {
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest=parentTest.createNode("NRECalibrationIVIReadExportDATA_95607");
		//System.out.println(" TC : NRECalibrationIVIReadExportDATA_95607");
		campName=excel(file, 2, 1, 0)+"IVIReadExportDATA-"+ getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 3, 2);

		NRECampaignsSoftwareIVI.NRECampaign(campName, campType , ECUModel, FotaType);

		//movetoElement(LocType.linkText, campName,campName);
		pause(5000);

		click(LocType.linkText, campName,campName);
		//click(LocType.linkText, campName,campName);
		//doubleClick(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[2]/a");

		pause(7000);
		try {
			click(LocType.xpath, NRECampaignsPage.CSVDownload,"CSV Download");
			click(LocType.xpath, NRECampaignsPage.CSVDownload,"CSV Download");
		} catch (Exception e) {
			click(LocType.id, "btnNrecomp","CSV Download");
		}

		//drawBorder(driver, LocType.id, "btnNrecomp");

		pause(17000);

		childTest.addScreenCaptureFromPath(captureScreen());

		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);

		read_File_Data(new File(downloadPath+lastDownloadFile));
		pause(4000);
	}

	@Test(priority = 9)
	public static void progressiveGrouppath_95608() throws InterruptedException {
		String uurl="https://camportal.sit.emea.avnext.net/";
		String campName="ProgressiveGroup_campName - "+getTimeStamp();
		String groupName="Groups"+getTimeStamp();
		enterUrl(uurl);
		//childTest=parentTest.createNode("progressiveGrouppath_95608");
		System.out.println(" TC : progressiveGrouppath_95608");
		click(LocType.linkText, NRECampaignsPage.campaign,"campaigns");
		pause(7000);

		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		drawBorder(driver, LocType.xpath, NRECampaignsPage.CreateCampaignnew);
		pause(2000);

		//javaScriptClick(LocType.xpath, NRECampaignsPage.CreateCampaignnew);
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", "RENAULT");
		pause(4000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, "Campaign Type :  ","Inventory");

		pause(2000);
		click(LocType.xpath, NRECampaignsPage.ProgressiveChekbox, "Progressive Chekbox");
		pause(4000);
		click(LocType.xpath, NRECampaignsPage.GroupsTab, "Groups Tab");

		DTA_SendKeys(LocType.id, NRECampaignsPage.groupName, "Groups Name :  ", groupName);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.Model_Code, "Criteria :  ", "Model_Code");
		DTA_SendKeys(LocType.xpath, NRECampaignsPage.XFE, "Value :  ", "XFE");

		pause(2000);
		click(LocType.id, "btnAddGroup", NRECampaignsPage.ADDGROUPbutton);

		pause(2000);
		movetoElement(CampaignPortal_Auto.LocType.id, "btnSave", "SAVE button");
		click(LocType.id, "btnSave", "SAVE button");


		pause(5000);
		DTA_SendKeys(LocType.id, "txtCampaignName", "Campaigns Name :  ", campName);
		pause(1000);
		click(LocType.xpath, "//*[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");

		pause(2000);
		//GET campaign status
		WebElement statusICV=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		System.out.println(campName+" status : "+statusICV.getText());
		childTest.log(Status.INFO, campName+" status : "+statusICV.getText());
		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label","CampaignStatus");

		WebElement CampaignDetails_Draft=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, campName+" Campaign Draft Details :  "+CampaignDetails_Draft.getText());

		pause(5000);
		click(LocType.linkText, campName, "campaing Name - "+campName);
		pause(2000);

		movetoElement(LocType.xpath, "//*[@id='CampaignTabs']/label[2]/span", "Groups Tab");
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[2]/span", "Groups Tab");
		pause(4000);
		//movetoElement(LocType.id, "btnRunCampaignGroup", "Run Button");
		click(LocType.id, "btnRunCampaignGroup", "RUN button");
		pause(2000);
		click(LocType.xpath, "//*[@id='SuccessMessageModalGroup']/div/div/div[2]/div[2]/button", "Campaign RUN Successfully. - OK button");
		pause(5000);

		//enterUrl("https://camportal.stg.emea.avnext.renault-nissan.com/campaigns/");
		//	enterUrl(uurl);
		//	click(LocType.linkText, NRECampaignsPage.campaign,"campaigns");
		pause(2000);

		DTA_SendKeys(LocType.id, "txtCampaignName", "Campaigns Name :  ", campName);
		pause(1000);
		click(LocType.xpath, "//*[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");

		//click(LocType.linkText, campName, "campaing Name - "+campName);

		//GET campaign status
		WebElement status_Onging=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName+" status : "+status_Onging.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, campName+" Campaign Onging Details :  "+CampaignDetails_Onging.getText());


		pause(5000);
		click(LocType.linkText, campName, "campaing Name - "+campName);
		pause(2000);

		movetoElement(LocType.xpath, "//*[@id='CampaignTabs']/label[2]/span", "Groups Tab");
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[2]/span", "Groups Tab");
		pause(2000);
		click(LocType.id, "btnStopCampaignGroup", "STOP button");
		pause(2000);
		click(LocType.xpath, "//*[@id='SuccessMessageModalGroup']/div/div/div[2]/div[2]/button", "Campaign Stopped Successfully. - OK button");

		pause(7000);
		refresh();
		pause(5000);
		refresh();
		pause(5000);
		refresh();
		//GET campaign status
		pause(2000);
		DTA_SendKeys(LocType.id, "txtCampaignName", "Campaigns Name :  ", campName);
		pause(1000);
		click(LocType.xpath, "//*[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		
		WebElement status_Finish=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName+" status : "+status_Finish.getText());

		WebElement CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, campName+" Campaign Finish Details :  "+CampaignDetails_Finish.getText());

	}
}
