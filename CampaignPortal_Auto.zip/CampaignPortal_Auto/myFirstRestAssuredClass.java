package CampaignPortal_Auto;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class myFirstRestAssuredClass extends BaseClass {

	static String file1;
	//="C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE sw IVI\\MockNreSWVINFAKE0021022019.json";
			//"C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE SW IVC\\MockVespaVINFAKE0021022019.json";
	//static String URL;="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VINFAKE0021022019/upload";
			//"C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE SW IVC\\MockVespaVINFAKE0021022019.json";

	public SSLContext getFactory(File pKeyFile, String password) {
		//Load Client certificate in a key store
		KeyStore keyStore = null;
		try {
			// Read supported format which you require
			keyStore = KeyStore.getInstance("PKCS12");
		} catch (KeyStoreException e) {
			System.out.println(e.getMessage());
		}
		//Convert string to char
		char[] clientCertificateKey=password.toCharArray();
		try {
			// Load certificates
			if(keyStore!=null){
				keyStore.load(new FileInputStream(pKeyFile), clientCertificateKey);
			}
		} catch (IOException | NoSuchAlgorithmException | CertificateException e) {
			System.out.println(e.getMessage());
		}

		KeyManagerFactory keyManagerFactory = null;
		try {
			keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		// Initialise Key manager
		try {
			if(keyManagerFactory!=null){
				keyManagerFactory.init(keyStore,clientCertificateKey);
			}
		} catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
			System.out.println(e.getMessage());
		}

		// set to always trust the server
		X509TrustManager tm = new X509TrustManager() {

			public void checkClientTrusted(X509Certificate[] arg0, String arg1) {
			}

			public void checkServerTrusted(X509Certificate[] arg0, String arg1) {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}

		};


		//Set SSL context
		SSLContext context = null;
		try {
			context = SSLContext.getInstance("TLS");
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		try {
			if(context!=null){
				if(keyManagerFactory!=null)
					context.init(keyManagerFactory.getKeyManagers(), new TrustManager[]{tm}, new SecureRandom());
			}
		} catch (KeyManagementException e) {
			System.out.println(e.getMessage());
		}
		return context;
	}
	//Set up your http client
	public HttpComponentsClientHttpRequestFactory requestFactory(String certificateName, String password) {
		//String fileName="C:\\Users\\z024513\\Desktop\\AIC\\FOTA\\VESPA\\2021_certificat_testing Tools_VespaNRE\\"+certificateName;
		String fileName=System.getProperty("user.dir")+"\\TestData\\"+certificateName;
				//"C:\\Users\\z028979\\Desktop\\NREVespa Camp\\"+certificateName;
		//testingtools-client2-SIT.pfx";
		
		SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(getFactory(new File(fileName),password));
		//Set SSL Context in http client
		boolean useProxy = Boolean.parseBoolean(System.getProperty("useProxy"));
		HttpClient httpClient;
		if(useProxy){
			String proxy=System.getProperty("proxy");
			int port=Integer.parseInt(System.getProperty("port"));
			HttpHost httpProxy = new HttpHost(proxy,port);
			httpClient = HttpClients.custom()
					.setProxy(httpProxy)
					.setSSLSocketFactory(socketFactory)
					.build();
		}else{
			httpClient = HttpClients.custom()
					.setSSLSocketFactory(socketFactory)
					.build();
		}

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setHttpClient(httpClient);
		return requestFactory;
	}
	
	
	//@Test
	public void postService(String URL,String file1) throws HttpClientErrorException {

		//REST TEMPLATE	 
		//Set Http headers
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
		httpHeaders.add("Ocp-Apim-Subscription-Key", "2975404eec0b42f8b644589643fcef9d");
		httpHeaders.add("Content-Length",   String.valueOf(file1.length()));

		//Body
		LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
		map.add("VespaConfigFile", new FileSystemResource(file1));

		//Certificate
		RestTemplate restTemplate = new RestTemplate(requestFactory("testingtools-client2-SIT.pfx","iS9hLdTYuF8v"));

		//URL
		URI uri = null;
		try {
			uri = new URI(URL);
		} catch (URISyntaxException e) {
			System.out.println(e.getMessage());
		}

		HttpStatus httpStatus = HttpStatus.CREATED;
		ResponseEntity<String> responseEntity;

		try{   

			//RequestEnntity
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<MultiValueMap<String, Object>>(map, httpHeaders);

			//ResponseEntity
			responseEntity =restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
			System.out.println("pass");
			System.out.println(responseEntity);
			childTest.log(Status.INFO, " responseEntity : "+responseEntity);
			
			
			HttpStatus statuscode=responseEntity.getStatusCode();
			childTest.log(Status.INFO, " responseEntity : "+statuscode);
			
		}
		catch (HttpStatusCodeException e) {
			httpStatus = HttpStatus.valueOf(e.getStatusCode().value());
			//  responseEntity = e.getResponseBodyAsString();
			System.out.println(HttpStatus.valueOf(e.getStatusCode().value()));
			System.out.println(HttpStatus.valueOf(e.getResponseBodyAsString()));


		}
		catch (Exception e) {
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
			//  responseEntity = e.getMessage();
			System.out.println("fail2");

		}

	}

	@Test
	public static void APICall(String URL,String file1) {
		myFirstRestAssuredClass readcerts = new myFirstRestAssuredClass();
		readcerts.postService(URL,file1);
	}
	
	
	public static void main(String[] args) {
		myFirstRestAssuredClass readcerts = new myFirstRestAssuredClass();
		//readcerts.postService(URL,file1);

	}
}
