package CampaignPortal_Auto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.jetty.util.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.server.DefaultDriverFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.internal.TestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
//import com.relevantcodes.extentreports.LogStatus;

import AdminPortal_Auto.AdminPortal;

import CampaignPortal_Auto.ReUsableMethods;

public class BaseClass {

	//BeforeSuite
	public static DesiredCapabilities cap;
	public static RemoteWebDriver driver;
	public static String userDir;

	
	//Beforeclass
	protected static ExtentHtmlReporter htmlReports;
	protected static ExtentReports extent;
	protected static ExtentTest test;
	protected static ExtentTest parentTest;
	protected static ExtentTest childTest;
	
	public static String parentName;

	//BeforeMethod
	public static String className=null;
	public static String testName;
	
	
	//Reusable components/Methods
	public static WebElement element;
	public static WebDriverWait wait;
	public static List<String> expRe;

	

	

	//properties file
	public static File setupPropFile;
	public static FileReader reader;
	public static Properties prop ;

	
	// String filePath=System.getProperty("user.dir")+"\\Reports\\"+ReUsableMethods.DateStamp()+"\\+"+className+ReUsableMethods.getTimeStamp()+".html";
	
			
	//Reports
	public static String ProjectName=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "ProjectName");		
	public static String SIT=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "SIT");
	public static String Deploymentversion=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "Deploymentversion");
	public static String javaVersion=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "javaVersion");
	public static String ReportName=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "ReportName");
	public static String DocumentTitle=ReUsableMethods.getProperty(System.getProperty("user.dir")+"\\config.properties", "DocumentTitle");

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	@SuppressWarnings("deprecation")
	@BeforeSuite
	public static void LaunchBrowser() {
		System.setProperty("webdriver.chrome.driver", ".//Drivers/chromedriver.exe");
		String userDir=System.getProperty("user.dir");
		String downloadFilepath = System.getProperty("user.dir")+"\\Downloads";
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);
		chromePrefs.put("safebrowsing.enabled", "true"); 
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		//options.addArguments("--start-maximized");

		cap = new DesiredCapabilities();
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(cap);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	@BeforeTest
	public void setReports() {

		className=getClass().getSimpleName();
		System.out.println("class Name :  "+className);
		//String filePath="C:\\Users\\"+AdminPortal.userID+"\\eclipse-workspace\\"+AdminPortal.ProjectName+"\\Reports\\"+ReUsableMethods.DateStamp()+"\\"+className+"-"+ReUsableMethods.getTimeStamp()+".html";
		String filePath=System.getProperty("user.dir")+"\\Reports\\"+ReUsableMethods.DateStamp()+"\\"+className+ReUsableMethods.getTimeStamp()+".html";
		htmlReports=new ExtentHtmlReporter(filePath);
		extent=new ExtentReports();
		extent.attachReporter(htmlReports);

		extent.setSystemInfo("User Name", AdminPortal.user);
		extent.setSystemInfo("OS", "Windows 10");
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			extent.setSystemInfo("Environment", "SIT");	
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			extent.setSystemInfo("Environment", "STG");
		}
		
		extent.setSystemInfo("Version", Deploymentversion);
		extent.setSystemInfo("Java Version", javaVersion);
		//	extent.setSystemInfo("Host Name", "INLH104543");
		htmlReports.config().setReportName(ReportName);
		htmlReports.config().setTheme(Theme.STANDARD);
		//htmlReports.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReports.config().setDocumentTitle(DocumentTitle);
		
		parentTest=extent.createTest(className);
		System.out.println("className : "+className);
	}

	
	@BeforeMethod
	public void testName(Method method) {
		
		testName = method.getName();
		System.out.println("Testcase is : "+testName);
		childTest=parentTest.createNode(testName);
		//childTest.log(Status.INFO, "Testcase is : "+testName);
	}

	
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	@AfterMethod
	public static void afterExecution(ITestResult result) throws IOException {
		if (result.getStatus()==result.SUCCESS) {
			System.out.println(testName+ " : TestCase Passed");
			childTest.log(Status.PASS, "Testcase is Pass : "+testName);
		} else if(result.getStatus()==result.FAILURE){
			System.out.println(testName+ " : TestCase Failed");
			childTest.log(Status.FAIL, "Testcase is Failed : "+testName);
			//childTest.log(Status.FAIL, result.getThrowable());
			childTest.addScreenCaptureFromPath(ReUsableMethods.captureScreen());
		}
		else if(result.getStatus()==result.SKIP){
			System.out.println(testName+ " : TestCase Skip");
			childTest.log(Status.SKIP, "Testcase is SKIP : "+testName);
			childTest.log(Status.SKIP, result.getThrowable());
			childTest.addScreenCaptureFromPath(ReUsableMethods.captureScreen());
		}
	}

	@AfterTest
	public static void closeReports() {
		extent.flush();
		System.out.println("Test method execution is done.");

	}

	//@AfterSuite
	public static void closeBrowser() {
		driver.close();
	}

	
	


}
