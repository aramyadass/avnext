package CampaignPortal_Auto;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.SwitchToWindow;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;

public class NRECampaignsSoftwareIVI extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String FotaType;
	static String ECUModel;
	static String campType;
	static String vin;
	//static String file1;

	
	static String fileNREswIVC=System.getProperty("user.dir")+"\\API mockfiles\\NRE SW IVC\\MockVespaVINFAKE0021022019.json";
	static String fileNREswIVI=System.getProperty("user.dir")+"\\API mockfiles\\NRE sw IVI\\MockVespaVINFAKE0021022019.json";
			//MockNreSWVINFAKE0021022019.json";
	//static String fileNREConfig=System.getProperty("user.dir")+"\\API mockfiles\\NRE config\\MockVespaVINFAKE0021022019.json";
	
	static String fileNREConfig=System.getProperty("user.dir")+"\\API mockfiles\\NRE config\\MockVespaVINFAKE0021022019.json";
	static	String fileNRECallib=System.getProperty("user.dir")+"\\API mockfiles\\NRE calib\\MockVespaVINFAKE0021022019.json";
	
	static String URL="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VINFAKE0021022019/upload";
	
	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
	
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}

	@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");

		pause(2000);
	}

	public static void APicall(String file1) {
		//childTest=parentTest.createNode("APicall");
	//	file1="C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE sw IVI\\MockNreSWVINFAKE0021022019.json";
		myFirstRestAssuredClass.APICall(URL,file1);
	}
	
	
	@Test(priority = 2)
	public static void NREswIVIPushMSG_82766() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"swIVIPushMsg" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		//childTest.log(Status.INFO, markup)
		//vin="VINFAKE0021022019";
		String vin="where c.vin = 'VINFAKE0021022019'";
		NREIVCPushmsg(campName, campType, ECUModel,vin, FotaType);

	}

	@Test(priority = 3)
	public static void NREIVIMultiVIN_82767() throws IOException, InterruptedException {
		campName=excel(file, 2, 1, 0)+"swIVIMultiVIN" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		
		//String vin="where c.vin = 'VINFAKE0014092020'";
		String vin="where c.vin = 'VINFAKE0021022019'";
		//NRECampaign(campName, campType , ECUModel, FotaType);
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	@Test(priority = 4)
	public static void NREIVIECUModel_82768() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"swIVIECUModel" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		//String vin="where c.vin = 'VINFAKE0014092020'";
		String vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		pause(2000);
		NREOngingFinish2(campName, campType , ECUModel, vin,FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
	}

	@Test(priority = 5)
	public static void NREIVILowRisk_82769() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"swIVILowRisk" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 1, 5);
		campType=excel(file, 2, 1, 2);
		//String vin="where c.vin = 'VINFAKE0014092020'";
		String vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		pause(2000);
		NREOngingFinish2(campName, campType , ECUModel,vin, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
	}

	@Test(priority = 6)
	public static void NREIVIRegularRisk_82770() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"swIVIRegularRisk" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 1, 2);
		//String vin="where c.vin = 'VINFAKE0014092020'";
		String vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		pause(2000);
		NREOngingFinish2(campName, campType , ECUModel, vin,FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
	}

	@Test(priority = 7)
	public static void NREIVICriticalRisk_82771() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"swCritical" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 3, 5);
		campType=excel(file, 2, 1, 2);
		//String vin="where c.vin = 'VINFAKE0014092020'";
		String vin="where c.vin = 'VINFAKE0021022019'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREswIVI);
		pause(2000);
		NREOngingFinish2(campName, campType , ECUModel, vin,FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
	}

	
	public static void NREConfigIVIPushMSG_82778() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"configIVIPushMsg" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		childTest=parentTest.createNode("NREConfigIVIPushMSG_82778");
		System.out.println(" TC : NREConfigIVIPushMSG_82778");
		
		//String fileNREConfig=System.getProperty("user.dir")+"\\API mockfiles\\NRE config\\MockVespaVINFAKE0021022019.json";
				//"C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE config\\MockVespaVINFAKE0021022019.json";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		
		NREIVCPushmsg(campName, campType, ECUModel,vin, FotaType);
	}

	
	public static void NREConfigIVIMultiVIN_82779() throws IOException, InterruptedException {
		getSwitchWindow(0);
		refresh();
		campName="NREconfigIVIMultiVIN" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		childTest=parentTest.createNode("NREConfigIVIMultiVIN_82779");
		System.out.println(" TC : NREConfigIVIMultiVIN_82779");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	
	}

	
	public static void NREConfigIVIECUModel_82780() throws IOException, InterruptedException {
		campName="NREconfigIVIECUModel-" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		childTest=parentTest.createNode("NREConfigIVIECUModel_82780");
		System.out.println(" TC : NREConfigIVIECUModel_82780");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel, vin,FotaType);
	
	}

	
	public static void NREConfigIVILowRisk_82781() throws IOException, InterruptedException {

		campName="NREconfigIVILowRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 1, 5);
		campType=excel(file, 2, 2, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		childTest=parentTest.createNode("NREConfigIVILowRisk_82781");
		System.out.println(" TC : NREConfigIVILowRisk_82781");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	
	public static void NREConfigIVIRegularRisk_82782() throws IOException, InterruptedException {

		campName="NREconfigIVIRegularRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		childTest=parentTest.createNode("NREConfigIVIRegularRisk_82782");
		System.out.println(" TC : NREConfigIVIRegularRisk_82782");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin = 'VF1XHNFTAS2VAL002'");
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	
	public static void NREConfigIVICriticalRisk_82783() throws IOException, InterruptedException {

		campName="NREconfigIVICritRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 3, 5);
		campType=excel(file, 2, 2, 2);
		String vin="where c.vin = 'VINFAKE0021022019'";
		childTest=parentTest.createNode("NREConfigIVICriticalRisk_82783");
		System.out.println(" TC : NREConfigIVICriticalRisk_82783");
		//NRECampaign(campName, campType , ECUModel, FotaType);
		//NRECampaigns(campName, campType , ECUModel, FotaType,"where c.vin='AIVISTNTI0L6003ZB'");
		pause(2000);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	


	public static void NREOngingFinish(String campName,String campType,String ECUModel,String FotaType) throws IOException, InterruptedException {
		//NREIVIECUModel_82768();
		//NRECampaign(campName,campType,ECUModel,FotaType);
		String vin1=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My.csv";
		//String vin2=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My2.csv";
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		childTest.log(Status.INFO, " URL : "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign," Campaigns");
		pause(7000);

		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew," NEW Button");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.CreateCampaignnew);

		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", excel(file, 2, 1, 1));
		pause(4000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ",campType);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, "ECU Model :  ",ECUModel);
		scrollPageBy(0, 70);
		pause(5000);

		/*
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import Radio Button");
		pause(4000);
		click(LocType.id, NRECampaignsPage.uploadBtn," BROWSE Button");
		//drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		uploadFileAutoit(vin1);
		 */

		DTA_SendKeys(LocType.xpath, "//*[@id='campaignVinCriteria']", " VIN : ", "where c.vin = 'VINFAKE0021022019'");

		//Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\autoit\\FileUpload.exe");
		pause(4000);

		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ", excel(file, 2, 1, 4));
		//drawBorder(driver, LocType.id, NRECampaignsPage.MaxRetryNum);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.DynamicHMI);

		pause(1000);
		if (FotaType.equals(excel(file, 2, 1, 5))) {
			System.out.println("FotaType - Silent ");
		} else {
			click(LocType.id, NRECampaignsPage.downloadSilent,"checkBox - DownloadSilent");
			click(LocType.id, NRECampaignsPage.installSilent,"checkBox - InstallSilent");
			click(LocType.id, NRECampaignsPage.activateSilent,"checkBox - ActivateSilent");		
		}
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE Button");
		//pause(4000);

		pause(10000);

		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();

		
		
		//pause(5000);
		//enterUrl(AdminPortal.campaignPortal_URL);
		refresh();
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, "Campaign Name :  ",campName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);

		WebElement status2=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " -  Status :  "+status2.getText());
		System.out.println(campName + " Campaign status : "+status2.getText());
		//drawBorder(driver,LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);

	//	pause(2000);

		//String s = null;
		if (campName.contains("NRE-sw")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(4000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			//pause(7000);
		} else {
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");

			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		//	pause(7000);
		}
		pause(7000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());

		//	pause(5000);
		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		pause(2000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(7000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				click(LocType.xpath,Pages1.xLogin, "Login Button");
				pause(5000);
				click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
				pause(5000);
				click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
				pause(7000);

				enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
				pause(5000);
				click(LocType.xpath,Pages1.selectCampaign, "select_Campaign");
				pause(15000);
				WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
				//getText(LocType.xpath,Pages1.xCampaignStatus);

				childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);


		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	

		btnClick_link(campName);
		childTest.log(Status.INFO, "Click on campaign :  "+campName);
		pause(2000);
		scrollPageBy(0, 1000);
		click(LocType.xpath,Pages1.Stop, " STOP Button ");	
		pause(4000);
		//btnClick(Pages1.StopSure);
		btnClick(Pages1.StopConfirmation, "Stop_Campaign_Confirm Yes");
		pause(7000);

		driver.navigate().refresh();
		pause(5000);
		driver.navigate().refresh();
		pause(10000);
		driver.navigate().refresh();
		pause(10000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");


		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());

		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());

		childTest.log(Status.INFO, "Campaign Portal Status : "+INVstatusOfCampaign_Finish.getText());
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

				pause(5000);
				//driver.close();

			}
		}
		driver.switchTo().window(parentWinHandle); 
		pause(4000);
		childTest.log(Status.INFO, "Go to campaign portal");
	}

	public static void NRECampaign(String campName,String campType,String ECUModel,String vin,String FotaType) throws InterruptedException, IOException {
		String vin1=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My.csv";
		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		childTest.log(Status.INFO, "URL : "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		click(LocType.linkText, NRECampaignsPage.campaign,"campaigns");
		pause(5000);

		pause(5000);

		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew," NEW Button");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.CreateCampaignnew);

		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", excel(file, 2, 1, 1));
		pause(4000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ",campType);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, "ECU Model :  ",ECUModel);
		scrollPageBy(0, 70);
		pause(5000);

		/*
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import Radio Button");
		pause(4000);
		click(LocType.id, NRECampaignsPage.uploadBtn," BROWSE Button");
		//drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		uploadFileAutoit(vin1);
		 */

		DTA_SendKeys(LocType.xpath, "//*[@id='campaignVinCriteria']", " VIN : ", vin);

		//Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\autoit\\FileUpload.exe");
		pause(4000);

		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ", excel(file, 2, 1, 4));
		//drawBorder(driver, LocType.id, NRECampaignsPage.MaxRetryNum);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.DynamicHMI);

		pause(1000);
		if (FotaType.equals(excel(file, 2, 1, 5))) {
			System.out.println("FotaType - Silent ");
		} else {
			click(LocType.id, NRECampaignsPage.downloadSilent,"checkBox - DownloadSilent");
			click(LocType.id, NRECampaignsPage.installSilent,"checkBox - InstallSilent");
			click(LocType.id, NRECampaignsPage.activateSilent,"checkBox - ActivateSilent");		
		}
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE Button");
		/*
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		drawBorder(driver, LocType.xpath, NRECampaignsPage.CreateCampaignnew);
		pause(2000);

		//javaScriptClick(LocType.xpath, NRECampaignsPage.CreateCampaignnew);
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", excel(file, 2, 1, 1));
		pause(4000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, "Campaign Type :  ",campType);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, " ECU Model :  ",ECUModel);
		scrollPageBy(0, 70);
		pause(2000);
		DTA_SendKeys(LocType.id, "campaignVinCriteria", " VIN :  ",VIN);

		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ",excel(file, 2, 1, 4));
		drawBorder(driver, LocType.id, NRECampaignsPage.MaxRetryNum);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");
		drawBorder(driver, LocType.xpath, NRECampaignsPage.DynamicHMI);
		pause(2000);
		if (FotaType.equals(excel(file, 2, 1, 5))) {
			System.out.println("FotaType - Silent ");
		} else {
			click(LocType.id, NRECampaignsPage.downloadSilent,"downloadSilent");
			click(LocType.id, NRECampaignsPage.installSilent,"installSilent");
			click(LocType.id, NRECampaignsPage.activateSilent,"activateSilent");		
		}
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE");
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);


		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();
		

		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName," Campaign Name :  ", campName);
		drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);
		pause(2000);
		WebElement Processed=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		drawBorder(driver, LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName+ " - Status :  "+Processed.getText());

		//Assert.assertEquals("Processed", Processed);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(7000);
	
	*/
	}

	public static void NRECampaign(String campName,String campType,String ECUModel,String FotaType) throws InterruptedException, IOException {
		String vin1=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My.csv";
		//String vin2=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My2.csv";
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		childTest.log(Status.INFO, " URL : "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign," Campaigns");
		pause(7000);

		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew," NEW Button");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.CreateCampaignnew);

		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", excel(file, 2, 1, 1));
		pause(4000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ",campType);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, "ECU Model :  ",ECUModel);
		scrollPageBy(0, 70);
		pause(5000);

		/*
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import Radio Button");
		pause(4000);
		click(LocType.id, NRECampaignsPage.uploadBtn," BROWSE Button");
		//drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		uploadFileAutoit(vin1);
		 */

		DTA_SendKeys(LocType.xpath, "//*[@id='campaignVinCriteria']", " VIN : ", "where c.vin = 'VINFAKE0021022019'");

		//Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\autoit\\FileUpload.exe");
		pause(4000);

		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ", excel(file, 2, 1, 4));
		//drawBorder(driver, LocType.id, NRECampaignsPage.MaxRetryNum);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.DynamicHMI);

		pause(1000);
		if (FotaType.equals(excel(file, 2, 1, 5))) {
			System.out.println("FotaType - Silent ");
		} else {
			click(LocType.id, NRECampaignsPage.downloadSilent,"checkBox - DownloadSilent");
			click(LocType.id, NRECampaignsPage.installSilent,"checkBox - InstallSilent");
			click(LocType.id, NRECampaignsPage.activateSilent,"checkBox - ActivateSilent");		
		}
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE Button");
		//pause(4000);

		pause(12000);

		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();

		

		pause(2000);
		refresh();
		pause(5000);

		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, "Campaign Name :  ",campName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);

		WebElement status2=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " -  Status :  "+status2.getText());
		System.out.println(campName + " Campaign status : "+status2.getText());
		//drawBorder(driver,LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(7000);

	}	
	
	public static void NREIVCPushmsg(String campName,String campType,String ECUModel,String vin,String FotaType) throws InterruptedException, IOException {
		String vin1=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My.csv";
		//String vin2=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My2.csv";
		//pause(4000);
		getSwitchWindow(0);
		refresh();
		
		enterUrl(AdminPortal.campaignPortal_URL);
		//childTest.log(Status.INFO, "URL : "+AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(5000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");

		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName,"Campaign Name :  ", campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand," Brand :  ", excel(file, 2, 1, 1));
		pause(2000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ", campType);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, " ECU Model :  ", ECUModel);
		pause(2000);
		scrollPageBy(0, 70);
		/*
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
		pause(2000);
		click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
		drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		*/
		pause(2000);
		
		DTA_SendKeys(LocType.xpath, "//*[@id='campaignVinCriteria']", " VIN : ", vin);

		//Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\autoit\\FileUpload.exe");
		//pause(000);
		//uploadFileAutoit(vin1)
		childTest.log(Status.INFO,"VIN : "+vin1);

		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		//pause(4000);
		pause(2000);
		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.ExecutionSetting);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.Server_Initiated, " Server Initiated :  ",excel(file, 2, 1, 6));
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.Push_Time_Zone, " Time Zone :  ",excel(file, 2, 1, 7));
		pause(1000);
		typeDateTIMEIntheCalendar(LocType.id, NRECampaignsPage.campaignPushFromTime, ISTtimeMinAdd(2));
		childTest.log(Status.INFO, " Push From Time :  "+ISTtimeMinAdd(2));
		pause(1000);
		click(LocType.id, NRECampaignsPage.campaignPushFromTime,"campaignPushFromTime");
		typeDateTIMEIntheCalendar(LocType.id, NRECampaignsPage.campaignPushToTime, ISTtimeMinAdd(5));
		childTest.log(Status.INFO, " Push To Time :  "+ISTtimeMinAdd(7));
		pause(2000);
		click(LocType.xpath, NRECampaignsPage.campaignPushFromTimeBTN,"campaignPushFromTime CalenderBtn");
		pause(2000);
		click(LocType.xpath, NRECampaignsPage.campaignPushToTimeBTN,"campaignPushToTime CalenderBtn");
		pause(2000);

		click(LocType.xpath, NRECampaignsPage.campaignPushToTimeBTN,"campaignPushToTime CalenderBtn");
		pause(1000);
		click(LocType.xpath, NRECampaignsPage.campaignPushToTimeBTN,"campaignPushToTime CalenderBtn");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ",excel(file, 2, 1, 4));
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");

		pause(1000);
		click(LocType.id, NRECampaignsPage.downloadSilent," DownloadSilent checkBox ");
		click(LocType.id, NRECampaignsPage.installSilent," InstallSilent checkBox");
		click(LocType.id, NRECampaignsPage.activateSilent," ActivateSilent checkBox");

		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE Button");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(10000);
		
		//code cchange 4000 above
		
		if(AdminPortal.campaignPortal_URL.contains("sit")) {
			//enterUrl()
			
			enterUrl("https://camportal.sit.emea.avnext.net/");
			//childTest.log(Status.INFO, "URL : "+AdminPortal.campaignPortal_URL);
			click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
			
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			enterUrl("https://camportal.stg.emea.avnext.renault-nissan.com/");
			click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
			
		}
		
		//pause(4000);
		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, " Campaign Name :  ", campName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);
		pause(2000);
		refresh();
		pause(2000);
		refresh();
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, " Campaign Name :  ", campName);
		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + "  -  Status :  "+status1.getText());
		//drawBorder(driver, LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(2000);

		//swivi push/multivin/Low 1click    ECU/Regular/critical 2click
 		//sw ivc push 2click
		
		
		//String s = null;
		if (campName.contains("NRE-sw")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]/input", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
			//pause(7000);
		} 
		
		else if (campName.contains("IVCPushMsg sw-")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		
		
		
		else if (campName.contains("NRE-config")) {
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		else if (campName.contains("NRE-calib")) {
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			//click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			System.out.println("clicked RUN button");
			//click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		}
		

		pause(7000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);
		
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());

		//	pause(5000);

		pause(2000);
		
		getSwitchWindow(1);
		//redbendLogin();
		pause(2000);
		if (campName.contains("swIVCPushMsg")) {
			pause(1000);
			click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
			pause(1000);
			click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
			pause(1000);	
		} else {
			pause(1000);
			//enterUrl(AdminPortal.Redbend_URL);
			System.out.println("RedBend portal onging ");
			click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
			pause(2000);
			click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
			//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
			//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
			pause(2000);
			click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
			System.out.println("click on CampaignList");
			
			pause(2000);
		}
		pause(2000);
		ClearText(Pages1.Campaign_Title);
		pause(2000);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		click(LocType.xpath,Pages1.selectCampaign, "select_Campaign");
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());

		/*
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		String lastWindowHandle = "";

		pause(5000);
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(4000);
				childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
				enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
				enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
				click(LocType.xpath,Pages1.xLogin, "Login Button");
				pause(5000);
				click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
				pause(5000);
				click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
				pause(7000);

				enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
				pause(5000);
				click(LocType.xpath,Pages1.selectCampaign, "select_Campaign");
				pause(15000);
				WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
				//getText(LocType.xpath,Pages1.xCampaignStatus);

				childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
			}
		}
		driver.switchTo().window(parentWinHandle);

		driver.switchTo().window(lastWindowHandle);
		*/
		
		getSwitchWindow(0);
		//refresh();
		pause(4000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	

		btnClick_link(campName);
		childTest.log(Status.INFO, "Click on campaign :  "+campName);
		pause(2000);
		scrollPageBy(0, 1000);
		click(LocType.xpath,Pages1.Stop, " STOP Button ");	
		pause(2000);
		//btnClick(Pages1.StopSure);
		btnClick(Pages1.StopConfirmation, "Stop_Campaign_Confirm Yes");
		pause(15000);

		driver.navigate().refresh();
		pause(2000);
		driver.navigate().refresh();
		pause(5000);
		driver.navigate().refresh();
		pause(7000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");


		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());

		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());

		childTest.log(Status.INFO, "Campaign Portal Status : "+INVstatusOfCampaign_Finish.getText());
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		
		getSwitchWindow(1);
		driver.navigate().refresh();
		pause(10000);
		WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
		//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
		childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		
		/*
		for(String handle: winHandles)
		{
			if(!handle.equals(parentWinHandle))
			{
				driver.switchTo().window(handle);
				pause(5000);
				driver.navigate().refresh();
				pause(15000);
				WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
				//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
				childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
				childTest.addScreenCaptureFromPath(captureScreen());

				pause(5000);
				//driver.close();

			}
		}
		
		driver.switchTo().window(parentWinHandle); 
		*/
		
		getSwitchWindow(0);
		pause(2000);
		childTest.log(Status.INFO, "Go to campaign portal");

		click(LocType.linkText, campName, campName);
		pause(2000);
		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs");
		pause(2000);
		movetoElement(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr/td[13]/a", "MORE button");
		click(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr/td[13]/a", "MORE button");
		
		
		pause(10000);
		click(LocType.xpath, "//*[@id='modalBody']/div[3]/span[12]", "JSON Button");
		pause(7000);
		readDownloadLastFile();
		
		//click(LocType.xpath, "//*[@id='ExecLogDataErrorMessageModal']/div/div/div[2]/div[2]/button", "Azax : OK button");
		
		pause(2000);
		click(LocType.xpath, "//*[@id='modalBody']/div[3]/span[13]", "VIEW button");
		pause(4000);
		click(LocType.xpath, "//*[@id='nav']/ul/li[1]/span", "Expand All");

		pause(3000);
		//WebElement staatus1=identifyElement(LocType.xpath, "//*[@id='tree']/ul/li/div/div/ul/li/div/div/ul/li[2]/div/div/ul/li[22]/span[2]/span");
		//childTest.log(Status.INFO, "Operation Id status : "+staatus1.getText());
		
		
	}

	
	public static void NREOngingFinish2(String campName,String campType,String ECUModel,String vin,String FotaType) throws IOException, InterruptedException {
		//NREIVIECUModel_82768();
		//NRECampaign(campName,campType,ECUModel,FotaType);
		
		String vin1=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_My.csv";
		pause(2000);
		getSwitchWindow(0);
	//	refresh();
		pause(2000);
		enterUrl(AdminPortal.campaignPortal_URL);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		
		pause(5000);

		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew," NEW Button");
		
		pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.campaignName, " Campaign Name :  ",campName);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.txtBrand, " Brand :  ", excel(file, 2, 1, 1));
		pause(2000);
		select_Dropdown_Value(LocType.id, NRECampaignsPage.campaignType, " Campaign Type :  ",campType);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.ECUModel, "ECU Model :  ",ECUModel);
		scrollPageBy(0, 70);
		pause(5000);

		/*
		click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import Radio Button");
		pause(4000);
		click(LocType.id, NRECampaignsPage.uploadBtn," BROWSE Button");
		//drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
		pause(4000);

		uploadFileAutoit(vin1);
		 */

		DTA_SendKeys(LocType.xpath, "//*[@id='campaignVinCriteria']", " VIN : ", vin);

		//Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\autoit\\FileUpload.exe");
		pause(4000);

		childTest.addScreenCaptureFromPath(captureScreen());

		click(LocType.xpath, NRECampaignsPage.ExecutionSetting,"Execution Settings");
		DTA_SendKeys(LocType.id, NRECampaignsPage.MaxRetryNum, " Max Retry No. :  ", excel(file, 2, 1, 4));
		//drawBorder(driver, LocType.id, NRECampaignsPage.MaxRetryNum);
		pause(2000);
		select_Dropdown_Value(LocType.xpath, NRECampaignsPage.FOTATYPE, " FOTA Type :  ",FotaType);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, NRECampaignsPage.DynamicHMI,"Dynamic HMI");
		//drawBorder(driver, LocType.xpath, NRECampaignsPage.DynamicHMI);

		pause(1000);
		if (FotaType.equals(excel(file, 2, 1, 5))) {
			System.out.println("FotaType - Silent ");
		} else {
			click(LocType.id, NRECampaignsPage.downloadSilent,"checkBox - DownloadSilent");
			click(LocType.id, NRECampaignsPage.installSilent,"checkBox - InstallSilent");
			click(LocType.id, NRECampaignsPage.activateSilent,"checkBox - ActivateSilent");		
		}
		pause(4000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.id, NRECampaignsPage.btnSave,"SAVE Button");
		//pause(4000);

		pause(10000);

		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();

		
		
		//pause(5000);
		//enterUrl(AdminPortal.campaignPortal_URL);
		//refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(2000);
		refresh();
		pause(4000);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, "Campaign Name :  ",campName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);

		WebElement status2=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " -  Status :  "+status2.getText());
		System.out.println(campName + " Campaign status : "+status2.getText());
		//drawBorder(driver,LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(2000);

	//	pause(2000);

		//String s = null;
		if (campName.contains("NRE-sw")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("sw click checkbox");
			pause(4000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN Button");
			//pause(7000);
		}
		
		else if (campName.contains("IVCMultiVIN sw-")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		
		else if (campName.contains("IVCECUModel sw-")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		
		else if (campName.contains("IVCLowRisk sw-")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		
		else if (campName.contains("IVCRegularRisk sw-")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			System.out.println("clicked RUN button");
		}
		
		else if (campName.contains("NRE-calib")) {
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			//click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			System.out.println("clicked RUN Button");
			//click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		}
		
		else {
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+campName+"']//parent::td//preceding::td[1]", campName+" Campaign-Checkbox");

			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			
			click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		//	
			pause(7000);
			System.out.println("clicked RUN Button");
		}
		//pause(7000);
		WebElement web = driver.findElementByXPath("//td[.='"+campName+"']//following-sibling::td[7]/label");
		//String status = web.getText();
		System.out.println("Caampaign status is : "+web.getText());
		
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());

		//	pause(5000);
		pause(5000);
		
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", campName);
		pause(2000);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+campName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);
		
		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	

		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		btnClick_link(campName);
		childTest.log(Status.INFO, "Click on campaign :  "+campName);
		pause(2000);
		scrollPageBy(0, 1000);
		click(LocType.xpath,Pages1.Stop, " STOP Button ");	
		pause(4000);
		//btnClick(Pages1.StopSure);
		btnClick(Pages1.StopConfirmation, "Stop_Campaign_Confirm Yes");
		pause(12000);

		pause(2000);
		refresh();
		pause(5000);
		refresh();
		pause(10000);
		refresh();
		pause(10000);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(2000);
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "Campaign Name :  ",campName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");


		WebElement INVstatusOfCampaign_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Campaing status : "+INVstatusOfCampaign_Finish.getText());

		//getTextFromElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "CampaignStatus");

		WebElement INV_CampaignDetails_Finish=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Finish Details : "+INV_CampaignDetails_Finish.getText());

		childTest.log(Status.INFO, "Campaign Portal Status : "+INVstatusOfCampaign_Finish.getText());
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(4000);
		
		
		getSwitchWindow(1);
		System.out.println("Redbend closed status : ");
		
		driver.navigate().refresh();
		pause(7000);
		WebElement RedBendstatus=identifyElement(LocType.xpath, Pages1.xCampaignStatus);
		//getTextFromElement(Pages1.xCampaignStatus, "xCampaignStatus");
		childTest.log(Status.INFO, "RedBend campaign Status :  "+RedBendstatus.getText());
		childTest.addScreenCaptureFromPath(captureScreen());		
		
		
		getSwitchWindow(0);
		//driver.switchTo().window(parentWinHandle); 
		pause(4000);
		childTest.log(Status.INFO, "Go to campaign portal");

		
	}
	
	
	
}
