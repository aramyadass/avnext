package CampaignPortal_Auto;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.CampaignPor_TemplatePage;
import CampaignPortal_Pages.NRECampaignsPage;
import CampaignPortal_Pages.Pages1;

public class VespaCampaigns extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String VespaCampName;
	static String EcuType;
	static String VINcriteria;
	static String campType;
	static String ECUType2;


	static String MuiltiVIN_Mockfile=System.getProperty("user.dir")+"\\UploadFiles\\MultiVIN_vespa.csv";
	//MOckfiles:
	//Vespa SW 
	static String fileVESPAswIVI=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVI\\MockVespaVF1SYMMPU240NA446.json";
	static String fileVESPAswIVI2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVI\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAswIVI1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVI\\MockVespaFOTATEAMCCS200003.json";
	//FOTATEAMCCS200003

	//System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSWIVI\\MockVespaVF1SYMMPU240NA446.json";
	static String fileVESPAswIVC=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVC\\MockVespaVF1SYMMPU240NA446.json";
	static String fileVESPAswIVC1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVC\\MockVespaFOTATEAMCCS200003.json";
	static String fileVESPAswIVC2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWIVC\\MockVespaVF1TSTBMSFG200001.json";

	static String fileVESPAswTDB=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWTDB\\MockVespaVF1TSTBMSFG200001.json";

	//"C:\\Users\\z028979\\eclipse-workspace\\AvNext_Portal5\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWTDB\\MockVespaVF1TSTBMSFG200001.json";
	//System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWTDB\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAswADAS=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWADAS\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAswHMD=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWHMD\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAswAAP=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWAAP\\MockVespaVF1TSTBMSFG200001.json";

	static String fileVESPAReprogConfigADASIVI=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogADASIVI\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAswADASTDB=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWADASTBD\\MockVespaVF1TSTBMSFG200001.json";	


	//vespa calib
	static String fileVESPAcalibIVI=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibIVI\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAcalibIVI1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibIVI\\MockVespaFOTATEAMCCS200003.json";
	static String fileVESPAcalibADAS=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibADAS\\MockVespaFOTATEAMCCS200003.json";
	static String fileVESPAcalibADAS1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibADAS\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAcalibTDB=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibTDB\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAcalibHMD=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaCalib\\VespacaIibHMD\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAcalibAAP=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaSoftware\\VespaSWAAP\\MockVespaVF1TSTBMSFG200001.json";


	//Vespa Reprog
	static String STG_fileVespaReprogIVI=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogIVI\\MockVespaVF1SYMMPU150NA446.json";

	static String fileVespaReprogIVC1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogIVC\\MockVespaFOTATEAMCCS200003.json";
	static String fileVespaReprogIVC2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogIVC\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVespaReprogIVI1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogIVI\\MockVespaFOTATEAMCCS200003.json";
	static String fileVespaReprogIVI2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogIVI\\MockVespaVF1TSTBMSFG200001.json";



	static String fileVespaReprogADAS=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogADAS\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVespaReprogTDB=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogTDB\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVespaReprogHMD=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogHMD\\MockVespaFOTATEAMCCS200003.json";

	//System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaReprog\\VespaReprogHMD\\MockVespaVF1TSTBMSFG200001.json";


	//Vespa Config
	static String fileVespaConfigIVI1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigIVI\\MockVespaFOTATEAMCCS200003.json";
	static String fileVespaConfigIVI2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigIVI\\MockVespaVF1TSTBMSFG200001.json";
	//"C:\\Users\\z028979\\Downloads\\MockVespaVF1TSTBMSFG200001.json";

	static String fileVespaConfigIVC1=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigIVC\\MockVespaFOTATEAMCCS200003.json";
	static String fileVespaConfigIVC2=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigIVC\\MockVespaVF1TSTBMSFG200001.json";

	static String fileVespaConfigADAS=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigADAS\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVespaConfigTDB=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigTDB\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVespaConfigHMD=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaHazem\\Reprog_config\\test Multiecu sauf IVI\\HMD\\MockVespaVF1TSTBMSFG200001.json";

	static String fileVespaConfigAAP=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigAAP\\MockVespaVF1TSTBMSFG200001.json";
	//"C:\\Users\\z028979\\Downloads\\MockVespaVF1TSTBMSFG200001.json";
	//System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigTDB\\MockVespaVF1TSTBMSFG200001.json";
	static String fileVESPAConfigADASIVI=System.getProperty("user.dir")+"\\API mockfiles\\VespaCampaigns\\VespaConfig\\VespaConfigADASIVI\\MockVespaVF1TSTBMSFG200001.json";

	//vespa SW URL's
	static String URL_VespaSWMonoType_709078_79="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VF1SYMMPU240NA446/upload";
	static String URL_VespaMonoTypeVF1TSTBMSFG200001="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VF1TSTBMSFG200001/upload";
	static String URL_VespaMonoTypeVF1SYMMPU150NA446="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VF1SYMMPU150NA446/upload";



	//vespa calib
	static String URL_VespaVINFOTATEAMCCS200003="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/FOTATEAMCCS200003/upload";
	static String URL_VespaCALIBTDBHMDMonoType="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VF1TSTBMSFG200001/upload";

	//@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}

	//@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);

		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");

	}


	public static void APicall(String URL,String file1) {
		//childTest=parentTest.createNode("APicall");
		//	file1="C:\\Users\\z028979\\Desktop\\NREVespa Camp\\NRE sw IVI\\MockNreSWVINFAKE0021022019.json";
		myFirstRestAssuredClass.APICall(URL,file1);
	}


	public static void callAPI() throws InterruptedException {

		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswADASTDB);
		//APicall(URL_VespaSWMonoType_709078_79,fileVESPAswIVI);
	}


	////@Test(priority = 2)
	public static void VespaSWmonoIVIType_709078() throws InterruptedException, IOException {

		//APicall(URL_VespaSWMonoType_709078_79,fileVESPAswIVI);
		//APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswIVI1);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAswIVI2);

		pause(2000);
		EcuType="IVI";
		VespaCampName="VespaSW-"+EcuType+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		//VespaMonoECUType(VespaCampName, campType, ECUType, VINCriteria);
	}

	////@Test(priority = 3)
	public static void VespaSWmonoIVCType_709079() throws InterruptedException, IOException {

		//APicall(URL_VespaSWMonoType_709078_79,fileVESPAswIVC);
		//APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAswIVC1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswIVC2);

		pause(2000);
		EcuType="IVC";
		VespaCampName="VespaSW -"+EcuType+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";

		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		pause(2000);


	}

	////@Test(priority = 4)
	public static void VespaSWADASTDBType_709080() throws InterruptedException, IOException {

		//APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAReprogConfigADASIVI)
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswADASTDB);
		campType="VESPA : Software";
		EcuType="ADAS";
		VespaCampName="MultiECU_VesReprogADASTDB-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}
	
	////@Test(priority = 5)
	public static void multiVIN_vespSW_IVI_709081() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAswIVI1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswIVI2);
		pause(2000);

		campType="VESPA : Software";
		EcuType="IVI";
		VespaCampName="MutilVINVespaSWIVI-"+getTimeStamp();
		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority = 6)
	public static void multiVIN_vespSW_IVC_709082() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAswIVC1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswIVC2);
		pause(2000);

		campType="VESPA : Software";
		EcuType="IVC";
		VespaCampName="MutilVINVespaSWIVC-"+getTimeStamp();
		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}

	////@Test(priority = 7)

	////@Test(priority = 8)
	public static void VespaSWmonoADASType_1085019() throws InterruptedException, IOException {
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswADAS);
		pause(2000);
		EcuType="ADAS";
		VespaCampName="VespaSW -"+EcuType+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";

		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		pause(2000);

	}

	////@Test(priority = 9)
	public static void VespaSWmonoTDBType_1085020() throws InterruptedException, IOException {
		pause(4000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswTDB);
		pause(2000);
		EcuType="TDB";
		VespaCampName="VespaSW -"+EcuType+" - "+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";

		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		pause(2000);

	}

	////@Test(priority = 10)
	public static void VespaSWmonoHMDType_1085021() throws InterruptedException, IOException {
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswHMD);
		pause(2000);
		EcuType="HMD";
		VespaCampName="VespaSW -"+EcuType+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";

		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		pause(2000);

	}

	////@Test(priority = 11)
	public static void VespaSWmonoAAPType_1088163() throws InterruptedException, IOException {

		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswAAP);
		pause(2000);
		//AAP-VespaSW -
		EcuType="AAP";
		VespaCampName=EcuType+"-VespaSW -"+getTimeStamp();
		campType="VESPA : Software";

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";

		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		pause(2000);


	}

	//Vespa Reprog
	//@Test(priority = 12)
	public static void VespaReprogmonoIVIType_709085() throws InterruptedException, IOException {

		pause(2000);
		campType="VESPA : Reprog";
		EcuType="IVI";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogIVI1);
			//APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogIVI2);
			pause(2000);
			VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
			VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			APicall(URL_VespaMonoTypeVF1SYMMPU150NA446,STG_fileVespaReprogIVI);
			pause(2000);

			VINcriteria="where c.vin = 'VF1SYMMPU150NA446'";
			VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		}

	}

	//@Test(priority = 13)
	public static void VespaReprogIVCType_709086() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogIVC1);
		//APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogIVC2);
		
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="IVC";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}
	
	//@Test(priority = 14)
	public static void VespaReprogADASIVIType_709087() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAReprogConfigADASIVI);
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="ADAS";
		VespaCampName="MultiECU_VesReprogADASIVI-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}
	
	//@Test(priority = 15)
	public static void multiVIN_vespaReprog_IVI_709088() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogIVI1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogIVI2);
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="IVI";
		VespaCampName="MutilVINVespaReprogIVI-"+getTimeStamp();
		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	//@Test(priority = 16)	
	public static void multiVIN_vespaReprog_IVC_709089() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogIVC1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogIVC2);
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="IVC";
		VespaCampName="MutilVINVespaReprogIVC-"+getTimeStamp();
		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority = 17)

	
	@Test(priority = 18)
	public static void VespaReprogADASType_1085023() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogADAS);
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="ADAS";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		//VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	//@Test(priority = 19)
	public static void VespaReprogTDBType_1085024() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaReprogTDB);
		pause(2000);

		campType="VESPA : Reprog";
		EcuType="TDB";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	//@Test(priority = 20)
	public static void VespaReprogHMDType_1085025() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogHMD);
		pause(2000);
		campType="VESPA : Reprog";
		EcuType="HMD";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	//@Test(priority = 21)
	public static void VespaReprogAAPType_1088164() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigAAP);
		campType="VESPA : Reprog";
		EcuType="AAP";
		VespaCampName="Vespa Reprog -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}
	
	

	//Vespa Calib
	////@Test(priority = 22)
	public static void VespacalibIVIType_709092() throws InterruptedException, IOException {

		pause(2000);

		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAcalibIVI);

		pause(2000);

		campType="VESPA : Calib";
		EcuType="IVI";
		VespaCampName="Vespa calib -"+EcuType+"-"+getTimeStamp();
		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
		//VespaMonoECUType(VINcriteria, campType, ECUType, VINCriteria);
	}

	////@Test(priority = 23)
	public static void VespacalibADASType_709093() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAcalibADAS);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="ADAS";
		VespaCampName="Vespa calib -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority = 24)
	public static void VespaCalibADASTDBType_709094() throws InterruptedException, IOException {


		//APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAReprogConfigADASIVI)
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAswADASTDB);
		campType="VESPA : Calib";
		EcuType="ADAS";
		VespaCampName="MultiECU_VesCalibADASTDB-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}
	
	////@Test(priority = 25)
	public static void multiVIN_vespCalib_IVI_709095() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAcalibIVI1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAcalibIVI);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="IVI";
		VespaCampName="MutilVINVespaCalibIVI-"+getTimeStamp();
		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}
	
	
	////@Test(priority = 26)
	public static void multiVIN_vespCalib_ADAS_709096() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVESPAcalibADAS);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAcalibADAS1);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="ADAS";
		VespaCampName="MutilVINVespaCalibADAS-"+getTimeStamp();

		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}
	
	////@Test(priority = 27)
	
	
	////@Test(priority = 28)
	public static void VespacalibTDBType_1085026() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAcalibTDB);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="TDB";
		VespaCampName="Vespa calib -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority = 29)
	public static void VespacalibHMDType_1085027() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaCALIBTDBHMDMonoType,fileVESPAcalibHMD);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="HMD";
		VespaCampName="Vespa calib -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority=30)
	public static void VespacalibAAPType_1088165() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAcalibAAP);
		pause(2000);

		campType="VESPA : Calib";
		EcuType="AAP";
		VespaCampName="Vespa calib -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);	

	}


	//Vespa Config
	////@Test(priority=31)
	public static void VespaConfigIVIType_709100() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigIVI2);
		pause(2000);
		campType="VESPA : Config";
		EcuType="IVI";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority=32)
	public static void VespaConfigIVCType_709101() throws InterruptedException, IOException {

		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigIVC2);
		pause(2000);
		campType="VESPA : Config";
		EcuType="IVC";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority = 33)
	public static void VespaConfigADASIVIType_709102() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVESPAConfigADASIVI);
		pause(2000);

		campType="VESPA : Config";
		EcuType="ADAS";
		VespaCampName="MultiECU_VesConfADASIVI-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);

	}

	////@Test(priority=34)
	public static void multiVIN_vespConfig_IVI_709103() throws InterruptedException, IOException {
		pause(2000);
		//APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigIVI);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaConfigIVI1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigIVI2);
		
		pause(2000);
		campType="VESPA : Config";
		EcuType="IVI";
		VespaCampName="MutilVINVespaConfigIVI-"+getTimeStamp();

		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}
	
	
	////@Test(priority=35)
	public static void multiVIN_vespConfig_IVC_709104() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaConfigIVC1);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigIVC2);
		pause(2000);
		campType="VESPA : Config";
		EcuType="IVC";
		VespaCampName="MutilVINVespaConfigIVC-"+getTimeStamp();

		VINcriteria=MuiltiVIN_Mockfile;
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}

	////@Test(priority=36)
	
	
	////@Test(priority=37)
	public static void VespaConfigADASType_1085028() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigADAS);
		pause(2000);

		campType="VESPA : Config";
		EcuType="ADAS";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();
		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}

	////@Test(priority=38)
	public static void VespaConfigTDBType_1085029() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigTDB);
		pause(2000);

		campType="VESPA : Config";
		EcuType="TDB";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}
	
	////@Test(priority=39)
	public static void VespaConfigHMDType_1085030() throws InterruptedException, IOException {

		//APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigHMD);
		pause(2000);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaReprogHMD);
		pause(2000);
		campType="VESPA : Config";
		EcuType="HMD";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}


	////@Test(priority=40)
	public static void VespaConfigAAPType_1088166() throws InterruptedException, IOException {
		pause(2000);
		APicall(URL_VespaMonoTypeVF1TSTBMSFG200001,fileVespaConfigAAP);
		pause(2000);

		campType="VESPA : Config";
		EcuType="AAP";
		VespaCampName="Vespa Config -"+EcuType+"-"+getTimeStamp();

		VINcriteria="where c.vin = 'VF1TSTBMSFG200001'";
		VespaMonoECUType(VespaCampName,campType,EcuType,VINcriteria);
	}


	////@Test(priority=41)
	public static void campTemp_vespa_1085034() throws IOException, InterruptedException {

		//enterUrl(AdminPortal.adminPortal_URL);

		String campTempName=excel(file, 3, 1, 0) +getTimeStamp();
		campName=excel(file, 3, 1, 1) + getTimeStamp();
		Campaign_Templates.CreateTemplate(campTempName);
		APicall(URL_VespaVINFOTATEAMCCS200003,fileVespaConfigTDB);
		pause(2000);
		campType="VESPA : Config";
		EcuType="TDB";
		VINcriteria="where c.vin = 'FOTATEAMCCS200003'";
		//createCampaign_Using_CampaignTemplate(campTempName, campTempName, campaignType, ECUType, vin);(campTempName, campTempName, campaignType, vin);
		createCampaign_Using_CampaignTemplate(campTempName, campName,campType,EcuType,VINcriteria);

	}






	public static void VespaMonoECUType(String VespaCampName,String campType,String ECUType,String VINCriteria) throws InterruptedException, IOException {

		//ECUType2="IVI";
		getSwitchWindow(0);
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(5000);
		click(LocType.xpath, NRECampaignsPage.CreateCampaignnew,"NEW Button");
		pause(2000);
		DTA_SendKeys(LocType.id, "campaignName", "Campaign Name : ", VespaCampName);
		select_Dropdown_Value(LocType.id, "txtBrand", "Brand : ", "RENAULT");

		select_Dropdown_Value(LocType.id, "campaignType", "Campaign Type", campType);
		//);

		click(LocType.id, "IsVespaMockup", "Vespa Mock-up Checkbox");
		pause(2000);

		if (VespaCampName.startsWith("MultiECU_VesReprogADASIVI")) {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");

			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", "IVI");
			click(LocType.id, "btnRightECU", "ADD Button");
		}
		else if (VespaCampName.startsWith("MultiECU_VesReprogADASTDB")) {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");

			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", "TDB");
			click(LocType.id, "btnRightECU", "ADD Button");
		}
		else if (VespaCampName.startsWith("MultiECU_VesCalibADASTDB")) {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");

			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", "TDB");
			click(LocType.id, "btnRightECU", "ADD Button");
		}
		else if (VespaCampName.startsWith("MultiECU_VesConfADASIVI")) {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");

			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", "IVI");
			click(LocType.id, "btnRightECU", "ADD Button");
		}
		else {
			select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type", ECUType);
			click(LocType.id, "btnRightECU", "ADD Button");
		}


		if (VespaCampName.startsWith("MutilVINVespa")) {
			pause(4000);
			movetoElement(LocType.xpath, NRECampaignsPage.ImportRadio_Btn, "Import Button");
			click(LocType.xpath, NRECampaignsPage.ImportRadio_Btn," Import RadioButton");
			pause(2000);
			click(LocType.id, NRECampaignsPage.uploadBtn,"BROWSE Button");
			drawBorder(driver, LocType.id, NRECampaignsPage.uploadBtn);
			pause(4000);
			uploadFileAutoit(VINCriteria);
			childTest.log(Status.INFO,"File upload: "+VINCriteria);	
			//MuiltiVIN_Mockfile

		} else {
			DTA_SendKeys(LocType.id, "campaignVinCriteria", "VIN Criteria : ",VINCriteria);
		}
		//VF1SYMMPU240NA446

		//"where c.vin = 'VF1SYMMPU240NA446'");


		pause(2000);
		scrollPageBy(0, -50);
		movetoElement(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[7]/span", "Execution Settings");
		click(LocType.xpath, "//*[@id='CampaignCreateViewForm']/div[2]/label[7]/span", "Execution Settings");
		DTA_SendKeys(LocType.id, "campaignMaxRetryNumber", "*MaxRetryNumber :  ", "0");

		pause(2000);
		click(LocType.id, "btnSave", "SAVE Button");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		//refresh();

		//pause(2000);
		//refresh();
		//pause(2000);
		//refresh();
		//pause(2000);
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, " Campaign Name :  ", VespaCampName);
		//drawBorder(driver, LocType.id, NRECampaignsPage.txtCampaignName);
		pause(2000);
		refresh();
		DTA_SendKeys(LocType.id, NRECampaignsPage.txtCampaignName, " Campaign Name :  ", VespaCampName);
		WebElement status1=identifyElement(LocType.xpath, "//td[.='"+VespaCampName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, VespaCampName + "  -  Status :  "+status1.getText());

		//drawBorder(driver, LocType.xpath, "//td[.='"+VespaCampName+"']//following-sibling::td[7]/label");
		pause(1000);
		childTest.addScreenCaptureFromPath(captureScreen());

		pause(2000);

		//String s = null;
		if (VespaCampName.contains("Vespa")) {
			System.out.println("If LOOP -  NRE-sw camp");
			click(LocType.xpath,"//td[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(5000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			//click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
			//pause(7000);
		} 
		else if (VespaCampName.contains("VespaSW-IVC")) {
			click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			//	click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			//click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		}
		else if (VespaCampName.contains("NRE-calib")) {
			click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			//click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
			//click(LocType.xpath, "//*[@id='RunNreCampaignConfirmationDialog']/div/div/div[2]/div/button[1]", " Run - proceed");
		}
		else {
			click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			//click(LocType.xpath,"//*[.='"+VespaCampName+"']//parent::td//preceding::td[1]", VespaCampName+" Campaign-Checkbox");
			System.out.println("click checkbox");
			pause(3000);
			click(LocType.xpath,Pages1.Run_Campaign,"RUN button");
		}


		pause(7000);
		WebElement web = driver.findElementByXPath("//td[.='"+VespaCampName+"']//following-sibling::td[7]/label");
		String status = web.getText();
		System.out.println("Caampaign status is : "+status);

		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", VespaCampName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement statusOfCampaign=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr/td[9]/label");
		childTest.log(Status.INFO, "Status of Campaign :  "+statusOfCampaign.getText());

		WebElement CampaignDetails_Onging=identifyElement(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		//getText(LocType.xpath, "//table[@id='entry-grid']/tbody/tr[1]");
		childTest.log(Status.INFO, "Campaign Onging Details :  "+CampaignDetails_Onging.getText());
		System.out.println("Caampaign status is : "+CampaignDetails_Onging.getText());
		//	pause(5000);

		pause(2000);
		getSwitchWindow(1);
		pause(2000);
		//enterUrl(AdminPortal.Redbend_URL);
		System.out.println("RedBend portal onging ");
		childTest.log(Status.INFO, "RedBend URL : "+AdminPortal.Redbend_URL);
		childTest.log(Status.INFO, "Moved to RedBend portal");

		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/div", "side bar");
		pause(2000);
		click(LocType.xpath, "//*[@id='wrapper']/app-sidebar/nav/ul/li[3]/ul/li[1]/a", "Campaings");
		//click(LocType.xpath, "//*[@id='breadcrumbs-flex-container']/div[4]/a/div", "CampaignList");
		//click(LocType.xpath,Pages1.xCampaignManagement, "CampaignManagement");
		pause(2000);
		click(LocType.xpath,Pages1.xCampaignList, "CampaignList");
		System.out.println("click on CampaignList");
		pause(2000);

		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", VespaCampName);
		pause(2000);
		refresh();
		pause(3000);
		ClearText(Pages1.Campaign_Title);
		enterText(Pages1.Campaign_Title, "Redbend CampaignName : ", VespaCampName);
		click(LocType.xpath,Pages1.selectCampaign, "Select_Campaign : "+VespaCampName);
		pause(5000);
		WebElement campaignStatus=identifyElement(LocType.xpath,Pages1.xCampaignStatus);
		//getText(LocType.xpath,Pages1.xCampaignStatus);

		childTest.log(Status.INFO, "Redbend campaign status : "+campaignStatus.getText());
		System.out.println( "Redbend campaign status : "+campaignStatus.getText());

		pause(2000);
		getSwitchWindow(0);

		refresh();
		pause(5000);
		childTest.log(Status.INFO, "Go to campaign Portal ");	

		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", VespaCampName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		btnClick_link(VespaCampName);
		childTest.log(Status.INFO, "Click on campaign :  "+VespaCampName);
		pause(2000);

		click(LocType.xpath, "//*[@id='CampaignTabs']/label[3]/span", "Execution Logs");

		pause(2000);
		scrollPageBy(0, 2400);
		movetoElement(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr/td[13]/a", "MORE Button");
		click(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr/td[13]/a", "MORE Button");

		pause(4000);
		click(LocType.xpath, "//*[@id='modalBody']/div/span[10]", "Inventory JSON");
		pause(7000);
		readDownloadLastFile();

		pause(2000);

		pause(4000);
		click(LocType.xpath, "//*[@id='modalBody']/div/span[12]", "Events history JSON");
		pause(7000);
		readDownloadLastFile();

		pause(4000);
		click(LocType.xpath, "//*[@id='ExtraInfoModel']/div/div/div[1]/button/span", " x button");
		pause(2000);
		scrollPageBy(0, 20);
		if (VespaCampName.startsWith("MutilVINVespa")) {
			System.out.println("more 2 loop");
			pause(4000);
			movetoElement(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr[2]/td[13]/a", "MORE Button");
			click(LocType.xpath, "//*[@id='grid-entry-grid']/tbody/tr[2]/td[13]/a", "MORE Button");

			pause(4000);
			click(LocType.xpath, "//*[@id='modalBody']/div/span[10]", "Inventory JSON");
			pause(7000);
			readDownloadLastFile();

			pause(2000);

			pause(4000);
			click(LocType.xpath, "//*[@id='modalBody']/div/span[12]", "Events history JSON");
			pause(7000);
			readDownloadLastFile();

			click(LocType.xpath, "//*[@id='ExtraInfoModel']/div/div/div[1]/button/span", " x button");
		}
		else {

		}
		pause(4000);

	}

	public static void createCampaign_Using_CampaignTemplate(String campTempName,String campName,String campaignType,String ECUType,String vin) throws InterruptedException, IOException {
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		click(LocType.linkText, CampaignPor_TemplatePage.CampaignTemplates,"CampaignTemplates");
		click(LocType.xpath, "//td[.='"+campTempName+"']//parent::td//preceding::td",campTempName+"-Checkbox");
		pause(2000);
		click(LocType.id, CampaignPor_TemplatePage.CreateCampaignUsingTemplate,"CreateCampaignUsingTemplate Button");
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CreateCampaignUsingTemplateDialog,"CreateCampaignUsingTemplateDialog - YES Button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignName, " CampaignName :  ",campName);
		pause(2000);
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.txtBrand, " Brand :  ", excel(file, 3,1,4));
		select_Dropdown_Value(LocType.id, CampaignPor_TemplatePage.campaignType, " CampaignType :  ",campaignType);

		pause(2000);

		click(LocType.id, "IsVespaMockup", "VespaMockup checkbox");
		select_Dropdown_Value(LocType.id, "availabeEculist", "ECU Type : ", ECUType);
		click(LocType.id, "btnRightECU", " ADD button");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.campaignVinCriteria, " VinCriteria :  ",vin);
		pause(2000);
		childTest.addScreenCaptureFromPath(captureScreen());
		click(LocType.xpath, CampaignPor_TemplatePage.CampaignCreateViewForm,"Execution Settings");
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.MaxRetryNum, " Max. RetryNo. :  ",excel(file, 3, 1, 6));
		click(LocType.id, CampaignPor_TemplatePage.btnSave,"SAVE Button");
		pause(5000);


		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();


		childTest.addScreenCaptureFromPath(captureScreen());
		//pause(5000);
		//refresh();	
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		click(LocType.linkText, NRECampaignsPage.campaign,"Campaigns");
		pause(2000);
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.txtCampaignName, " CampaignName :  ", campName);
		//pause(2000);
		WebElement Draft=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " Campaign Status : "+Draft.getText());
		//Assert.assertEquals(Draft.getText(), "Draft");
		drawBorder(driver, LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		pause(1000);
		pause(5000);
		refresh();
		DTA_SendKeys(LocType.id, CampaignPor_TemplatePage.txtCampaignName, " CampaignName :  ", campName);
		//pause(2000);
		WebElement Draft1=identifyElement(LocType.xpath, "//td[.='"+campName+"']//following-sibling::td[7]/label");
		childTest.log(Status.INFO, campName + " Campaign Status : "+Draft1.getText());
		childTest.addScreenCaptureFromPath(captureScreen());
		//pause(4000);


	}

}
