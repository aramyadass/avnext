package CampaignPortal_Auto;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.PagesExtraInfo;
import CampaignPortal_Pages.PagesScomo;
import CampaignPortal_Pages.Pages_MapCampaign;


public class NR_AutomaticMap extends ReUsableMethods {

	static String file=System.getProperty("user.dir")+"\\TestData\\TestData1.xlsx";
	String b = "window.open('"+getProperty("AdminPortal")+"','_blank')";
	
	static String ExecutionName;
		
	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(3000);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
		pause(3000);
	}
	@Test(priority=2)@Ignore
	public void CreateMapCampaign_247812() throws IOException, InterruptedException {
	String campaignName=excel(file, 1, 1, 1)+getTimeStamp();
	click(LocType.linkText,"Campaigns", "Campaigns Module");
	pause(5000);
	btnClick(Pages1.New, "New");
	pause(2000);
	enterText(Pages1.Campaign_Title, "Campaign_Title", campaignName);
	pause(2000);
	selectDropdown(Pages1.SelectBrand, "Select Brand = RENAULT", "RENAULT");
	pause(2000);
	selectDropdown(Pages1.SelectCampaignType,"Map campaign", "Automatic Map Update");
	pause(2000);
	selectDropdown(PagesScomo.SelectECUtype,"SelectECUtype", "IVI" );
	enterText(Pages1.Campaign_Vin,"Campaign_Vin","where c.vin ='VF1CUSTBJATEST001'");
	pause(2000);
	
	  btnClick(PagesScomo.ExecutionSettings,"ExecutionSettings");
	  selectDropdown(Pages1.FOTA_type,"FOTA_type","SILENT");
	 
		/*
		 * btnClick(PagesScomo.DynamicHMI,"DynamicHMI"); pause(5000);
		 * btnClick(PagesScomo.DynamicHMI,"DynamicHMI"); pause(5000);
		 * btnClick(PagesScomo.DownloadSilent,"DownloadSilent"); pause(2000);
		 * btnClick(PagesScomo.InstallSilent,"InstallSilent"); pause(2000);
		 * btnClick(PagesScomo.ActivateSilent,"ActivateSilent");
		 */
		
		
		btnClick(Pages1.Save_Campaign, "Save_Campaign");
		pause(10000);
		
		childTest.log(Status.PASS, "Create Campaign Passed");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(20000);	
		btnClick("//*[@data-campname='"+campaignName+"']" ,"CampaignCheckbox");
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign,"Run_Campaign");
		pause(10000);
		pause(10000);
		CompareText("//td[.='"+campaignName+"']//following-sibling::td[7]/label", "Ongoing","Campaign status");
		
		childTest.log(Status.PASS, "Run Campaign Passed" );
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
 	
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		pause(5000);
		Set <String> winHandles = driver.getWindowHandles();
		String parentWinHandle = driver.getWindowHandle();
		 String lastWindowHandle = "";
		
		pause(10000);
		 for(String handle: winHandles)
		 {
	            if(!handle.equals(parentWinHandle))
	            {
	            driver.switchTo().window(handle);
	            pause(5000);
	            pause(5000);
	            enterText(Pages1.xUsername, "xUsername", "sneha.sharavan-kumar@rntbci.com");
	    		enterTextSecure(Pages1.xPassword,"xPassword", "Aadithsg@1910");
	    		btnClick(Pages1.xLogin, "xLogin");
	    		pause(9000);
	    		btnClick(Pages1.xCampaignManagement, "xCampaignManagement");
	    		pause(9000);
	    		btnClick(Pages1.xCampaignList, "xCampaignList");
	    		pause(10000);
	    		enterText("//*[@id='campaignName']", "CampaignName", campaignName);
	    		pause(5000);
	         	btnClick("//*[@class='card-body-wrapper clearfix']/section/section/div/div/div/div","xSelectCampaign");
	    		pause(20000);
	    		CompareText("//*[@id=\"campaign-status-widget\"]/div/div[2]/div/span","Active","XCampaignStatus");
	    		scrollPageBy(10,500);
	    		CompareText("//*[@id='card-population']/div[2]/div[4]/div/div/div/div/span[2]/span","VF1CUSTBJATEST001", "VF1CUSTBJATEST001");
				childTest.log(Status.PASS, "Redbend Status ");
	            }
		 }
	            driver.switchTo().window(parentWinHandle); 
	
			btnClick_link(campaignName);
			btnClick(Pages1.Stop,"StopCampaign");	
			pause(6000);
			//btnClick(Pages1.StopSure);
			btnClick("//*[@id=\"StopConfirmationDialog\"]/div/div/div[2]/div/button[1]","Conifrm Stop Campaign");
			pause(15000);
			driver.navigate().refresh();
			pause(15000);
			driver.navigate().refresh();
			pause(15000);
			driver.navigate().refresh();
			pause(10000);
			if(findElementPassIfNotFound(Pages1.Stop,"stop"))
			{
				scrollToElement(Pages1.Stop);	
				pause(6000);
				//btnClick(Pages1.StopSure);
				btnClick("//*[@id='StopConfirmationDialog']/div/div/div[2]/div/button[1]","Stop_Campaign_Confirm");
				pause(3000);
				pause(3000);
				pause(3000);
				childTest.log(Status.PASS, "Redbend Status ");
				childTest.addScreenCaptureFromPath(captureScreen());
			}
			CompareText("//td[.='"+campaignName+"']//following-sibling::td[7]/label","Finished","Campaign status");
			childTest.log(Status.PASS, "Campaign Portal Status");
			// driver.switchTo().window(handle);
			
		
		pause(5000);
		 for(String handle: winHandles)
		 {
	            if(!handle.equals(parentWinHandle))
	            {
	             getSwitchWindow(1);
	           // driver.switchTo().window(handle);
	            pause(5000);
	            driver.navigate().refresh();
	            pause(15000);
	            CompareText("//*[@id=\"campaign-status-widget\"]/div/div[2]/div/span","Closed","XCampaignStatus");
	         
				childTest.log(Status.PASS, "Redbend Status ");
				childTest.addScreenCaptureFromPath(captureScreen());
				driver.close();
				 driver.switchTo().window(parentWinHandle); 
				 getSwitchWindow(0);
					/*
					 * pause(2000); getSwitchWindow(1); pause(2000); closeBrowser(); pause(2000);
					 * driver.switchTo().window(parentWinHandle); pause(10000);
					 */
	          }
		 }
			
		
	
	}
	@Test(priority=3)
	public void MapExclusion_247813() throws IOException, InterruptedException {
		//getSwitchWindow(0);
		String MapExclusion_247813 = excel(file,1,5,1)+getTimeStamp();
		enterUrl(AdminPortal.adminPortal_URL);
		
	pause(5000);
	pause(5000);

	btnClick_link("Campaigns");
		driver.executeScript(b);
		getSwitchWindow(1);
		btnClick_link("Map Management");
		btnClick_link("Exclusion Groups for Automatic Map Updates");
		pause(10000);
		btnClick(Pages_MapCampaign.Exclusion_Create, "Create");
		btnClick(Pages_MapCampaign.Exclusion_name,"Exclusion Name");
		enterText(Pages_MapCampaign.Exclusion_name , "Exclusion Name text",MapExclusion_247813);
		selectDropdown(Pages_MapCampaign.Exclusion_EcuType,"IVI","ECU type");
		btnClick(Pages_MapCampaign.Exclusion_ChooseFile,"Choose File");
		//uploadfile("C:\\Users\\z024513\\Desktop\\", "C:\\Users\\z024513\\Desktop\\AIC\\Maps\\","SITExclusion_MAP");
		pause(2000);
		uploadFileAutoit(System.getProperty("user.dir")+"\\UploadFiles\\SITExclusion_MAP.csv");
		pause(2000);
		btnClick(Pages_MapCampaign.Exclusion_Save,"Save");
		
		
		//btnClick(Pages_MapCampaign.Exclusion_Save,"Save");
		//btnClick(Pages_MapCampaign.Exclusion_Save,"Save");
		pause(7000);
		childTest.log(Status.PASS, "exclusion group created");
		childTest.addScreenCaptureFromPath(captureScreen());
		btnClick("//td[.='"+MapExclusion_247813+"']//parent::td//preceding::td[1]","Checkbox");
		btnClick(Pages_MapCampaign.Exclusion_Delete,"Delete");
		btnClick("//*[@id='okToDelete']","Delete Cofirm");
		pause(7000);
		childTest.log(Status.PASS, "exclusion group deleted");
		childTest.addScreenCaptureFromPath(captureScreen());
		driver.navigate().back();
	}
	
	@Test(priority=4)
	public void MapExecution_247813() throws IOException, InterruptedException {
		ExecutionName = excel(file,1,6,1)+getTimeStamp();
		//driver.executeScript(b);
		//getSwitchWindow(1);
		//btnClick_link("Map Management");
		btnClick_link("Execution Groups for Automatic Map Updates");
		pause(10000);
		btnClick(Pages_MapCampaign.Exclusion_Create,"Create");
		btnClick(Pages_MapCampaign.Exclusion_name,"Name");
		enterText(Pages_MapCampaign.Exclusion_name,"Name", ExecutionName);
		selectDropdown(Pages_MapCampaign.Exclusion_EcuType,"ECU Type","IVI");
		btnClick(Pages_MapCampaign.Exclusion_ChooseFile,"Choose File");
		pause(2000);
		//uploadfile("C:\\Users\\z024513\\Desktop\\", "C:\\Users\\z024513\\Desktop\\AIC\\Maps\\","SITExecutionGroup (2)");
		uploadFileAutoit(System.getProperty("user.dir")+"\\UploadFiles\\SITExecutionGroup(2).csv");
		scrollToElement(Pages_MapCampaign.Execution_Save);
		btnClick(Pages_MapCampaign.Execution_Save,"Save");
		btnClick(Pages_MapCampaign.Execution_Save,"Save");
		pause(7000);
		//btnClick("//*[@id='jsGrid']/div[3]/div/span[4]","Page2");
		pause(5000);
		scrollToElement("//*[@id='jsGrid']/div[3]/div/span[4]/a");
		pause(5000);
		//btnClick("//*[@id='jsGrid']/div[3]/div/span[4]","2");
		scrollToElement(ExecutionName);
		System.out.println("Scroll to Ex . Name - "+ExecutionName);
		pause(4000);
		btnClick("//td[.='"+ExecutionName+"']//parent::td//preceding::td[1]", "Name");
		System.out.println("Clicked on Ex Name");
		
		childTest.log(Status.PASS, "created execution group");
		childTest.addScreenCaptureFromPath(captureScreen());
		btnClick(Pages_MapCampaign.Exclusion_Delete,"Delete");
		btnClick("//*[@id='okToDelete']","Delete confirm");
        pause(7000);
		childTest.log(Status.PASS, "execution group deleted");
		childTest.addScreenCaptureFromPath(captureScreen());
		
	}
}
