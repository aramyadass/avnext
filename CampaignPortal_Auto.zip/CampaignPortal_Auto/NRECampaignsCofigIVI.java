package CampaignPortal_Auto;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Pages.Pages1;

public class NRECampaignsCofigIVI extends ReUsableMethods{

	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String campName;
	static String FotaType;
	static String ECUModel;
	static String campType;
	static String vin;

	static String fileNREConfig=System.getProperty("user.dir")+"\\API mockfiles\\NRE config\\MockVespaVINFAKE0014092020.json";


	static String URL="https://services.sit.emea.avnext.net/testingTools/mockvespaconfig/VINFAKE0021022019/upload";


	@Test(priority = 0)
	public static void LoginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft("rakesh");
	}

	@Test(priority = 1)
	public static void redbendLogin() throws IOException, InterruptedException {
		pause(5000);
		driver.executeScript("window.open('"+AdminPortal.Redbend_URL+"', '_blank');");
		childTest.log(Status.INFO, " URL :  "+AdminPortal.Redbend_URL);
		getSwitchWindow(1);
		pause(2000);
		enterText(Pages1.xUsername, " User : ",AdminPortal.RedbendUser);
		enterText(Pages1.xPassword, " ",AdminPortal.RedbendPassword);
		click(LocType.xpath,Pages1.xLogin, "Login Button");

		pause(2000);
	}

	public static void APicall(String file1) {
		myFirstRestAssuredClass.APICall(URL,file1);
	}

	@Test(priority = 2)
	public static void NREConfigIVIPushMSG_82778() throws IOException, InterruptedException {

		campName=excel(file, 2, 1, 0)+"configIVIPushMsg" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		String vin="where c.vin = 'VINFAKE0014092020'";
		NRECampaignsSoftwareIVI.NREIVCPushmsg(campName, campType, ECUModel,vin, FotaType);
	}

	@Test(priority = 3)
	public static void NREConfigIVIMultiVIN_82779() throws IOException, InterruptedException {
		getSwitchWindow(0);
		refresh();
		campName="NREconfigIVIMultiVIN" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		vin="where c.vin = 'VINFAKE0014092020'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);

	}

	@Test(priority = 4)
	public static void NREConfigIVIECUModel_82780() throws IOException, InterruptedException {
		campName="NREconfigIVIECUModel-" + getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		vin="where c.vin = 'VINFAKE0014092020'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);

	}

	@Test(priority = 5)
	public static void NREConfigIVILowRisk_82781() throws IOException, InterruptedException {

		campName="NREconfigIVILowRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 1, 5);
		campType=excel(file, 2, 2, 2);
		vin="where c.vin = 'VINFAKE0014092020'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	@Test(priority = 6)
	public static void NREConfigIVIRegularRisk_82782() throws IOException, InterruptedException {

		campName="NREconfigIVIRegularRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 2, 5);
		campType=excel(file, 2, 2, 2);
		vin="where c.vin = 'VINFAKE0014092020'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}

	@Test(priority = 7)
	public static void NREConfigIVICriticalRisk_82783() throws IOException, InterruptedException {

		campName="NREconfigIVICritRisk-"+getTimeStamp();
		ECUModel=excel(file, 2, 2, 3);
		FotaType=excel(file, 2, 3, 5);
		campType=excel(file, 2, 2, 2);
		vin="where c.vin = 'VINFAKE0014092020'";
		CampaignPortal_Auto.NRECampaignsSoftwareIVI.APicall(fileNREConfig);
		System.out.println("File name : "+fileNREConfig);
		pause(2000);
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);
		NRECampaignsSoftwareIVI.NREOngingFinish2(campName,campType , ECUModel,vin, FotaType);
	}





}
