package CampaignPortal_Auto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Optional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aventstack.extentreports.Status;



public class ReUsableMethods extends BaseClass{



	//For Excel
	private static FileInputStream fileInputStream;
	private static XSSFWorkbook workbook;
	private static XSSFSheet sheet;
	private static Cell cell;
	private static File file;

	//Autoit
	private static ProcessBuilder pb;
	private static String autoitExe;

	public static void enterUrl(String url) {
		driver.get(url);
		childTest.log(Status.INFO, " URL : "+url);
		System.out.println("URL :  "+url);
	}

	public static String getProperty(String property) {
		if (System.getProperty(property) != null) {
			return System.getProperty(property);
		}
		setupPropFile = new File("setup.properties");
		if (setupPropFile.exists()) {
			prop = new Properties();
			FileReader reader;
			try {
				reader = new FileReader(setupPropFile);
				prop.load(reader);
				reader.close();
				return prop.getProperty(property);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String getUserDir() {
		return userDir;
	}

	public static RemoteWebDriver getDriver() {
		return driver;
	}

	public static String getProperty(String propertyFile,String key) {
		if (System.getProperty(key) != null) {
			return System.getProperty(key);
		}
		File setupPropFile = new File(propertyFile);
		if (setupPropFile.exists()) {
			Properties prop = new Properties();
			FileReader reader;
			try {
				reader = new FileReader(setupPropFile);
				prop.load(reader);
				reader.close();
				return prop.getProperty(key);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String captureScreen() {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String encodedBase64 = null;
		FileInputStream fileInputStreamReader = null;
		try {
			fileInputStreamReader = new FileInputStream(scrFile);
			byte[] bytes = new byte[(int)scrFile.length()];
			fileInputStreamReader.read(bytes);
			encodedBase64 = new String(Base64.encodeBase64(bytes));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "data:image/png;base64,"+encodedBase64;
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static WebElement identifyElement(@Optional("xpath") String locType,String locValue) {
		if (locType.equalsIgnoreCase("id")) {
			element=driver.findElement(By.id(locValue));
		}
		else if (locType.equalsIgnoreCase("name")) {
			element=driver.findElement(By.name(locValue));
		}
		else if (locType.equalsIgnoreCase("className")) {
			element=driver.findElement(By.className(locValue));
		}
		else if (locType.equalsIgnoreCase("xpath")) {
			element=driver.findElement(By.xpath(locValue));
		}
		else if (locType.equalsIgnoreCase("cssSelector")) {
			element=driver.findElement(By.cssSelector(locValue));
		}
		else if (locType.equalsIgnoreCase("linkText")) {
			element=driver.findElement(By.linkText(locValue));
		}
		else if (locType.equalsIgnoreCase("partialLinkText")) {
			element=driver.findElement(By.partialLinkText(locValue));
		}
		else if (locType.equalsIgnoreCase("tagName")) {
			element=driver.findElement(By.tagName(locValue));
		}
		return element;
	}

	/*
	 * Method : .
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void LocType() {
		String id="id";
		String name="name";
		String className="className";
		String xpath="xpath";
		String cssSelector="cssSelector";
		String linkText="linkText";
		String partialLinkText="partialLinkText";
		String tagName="tagName";

	}

	public static boolean elementIsVisible(WebElement element) {
		boolean b=true;
		try {
			b=element.isDisplayed()&&element.isEnabled()?true:false;

			//test.log(LogStatus.PASS,"Element is visible "+element);
		} catch (Exception e) {

		}
		return b;
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static boolean click(String LocType,String locValue,String elementValue) {
		//String By=by;
		boolean result = false;
		int attempts = 0;
		while(attempts < 4) {
			try {
				element=identifyElement(LocType, locValue);
				pause(2000);
				movetoElement(LocType, locValue, elementValue);
				pause(2000);
				element.click();
				childTest.log(Status.PASS," Click on  "+elementValue);
				System.out.println(" Click on  "+elementValue);
				result = true;
				break;
			} catch(Exception e) {
				//	childTest.log(Status.FAIL," Element not Found , Unable to Click on  "+elementValue);

			}

			attempts++;
		}
		return result;
	}


	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void DTA_SendKeys(String locType,String locValue,String textData) {
		try {
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			element=identifyElement(locType, locValue);
			wait = new WebDriverWait (driver, 50); 
			wait.until(ExpectedConditions.visibilityOf(element));
			if (elementIsVisible(element)) {
				element.clear();
				element.sendKeys(textData);
				System.out.println("Enter a value : "+textData);
				//test.log(LogStatus.PASS,"Text entered Element "+locValue+ ": TestData : "+textData);
				childTest.log(Status.PASS,"Enter a value : "+textData);

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to perform DTA_SendKeyss on : "+locType+" :"+ locValue);
			childTest.log(Status.INFO,"Unable to perform DTA_SendKeys on  "+textData);
		}
	}


	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void DTA_SendKeys(String locType,String locValue,String eleValue,String textData) {
		try {
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			element=identifyElement(locType, locValue);
			wait = new WebDriverWait (driver, 50); 
			wait.until(ExpectedConditions.visibilityOf(element));
			if (elementIsVisible(element)) {
				element.clear();
				element.sendKeys(textData);
				System.out.println(eleValue + textData);
				//test.log(LogStatus.PASS,"Text entered Element "+locValue+ ": TestData : "+textData);
				childTest.log(Status.PASS,eleValue + textData);

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to perform DTA_SendKeyss on : "+locType+" :"+ locValue);
			childTest.log(Status.INFO,"Unable to perform DTA_SendKeys on  "+textData);
		}
	}


	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String getText(String locType,String locValue) {
		String text=null;
		element=identifyElement(locType, locValue);
		wait = new WebDriverWait (driver, 50); 
		wait.until(ExpectedConditions.visibilityOf(element));
		text=element.getText();
		System.out.println(text);
		childTest.log(Status.INFO,  " Text Data : "+text);
		return text;
	}

	/*
	 * Method : excel
	 * To get a Data from Excel sheet with passing parameter 
	 * sheet parameter is giving as "int" type .ex : 0,1..
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String excel(String file,int sheet,int rowNum,int cellNum) throws IOException {
		//String file="";
		fileInputStream=new FileInputStream(file);
		workbook=new XSSFWorkbook(fileInputStream);
		cell=workbook.getSheetAt(sheet).getRow(rowNum).getCell(cellNum);
		DataFormatter dataFormatter=new DataFormatter();
		return dataFormatter.formatCellValue(cell);
	}

	/*
	 * Method : excel
	 * To get a Data from Excel sheet with passing parameter 
	 * sheet parameter is giving as "String" type .ex : sheetName..
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String excel(String file,String sheet,int rowNum,int cellNum) throws IOException {
		//String file="";
		fileInputStream=new FileInputStream(file);
		workbook=new XSSFWorkbook(fileInputStream);
		cell=workbook.getSheet(sheet).getRow(rowNum).getCell(cellNum);
		DataFormatter dataFormatter=new DataFormatter();
		return dataFormatter.formatCellValue(cell);
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	@SuppressWarnings("unused")
	public static void select_Dropdown_Value(String locType,String locValue ,String Textvalue) {
		element=identifyElement(locType, locValue);
		wait = new WebDriverWait (driver, 50); 
		wait.until(ExpectedConditions.visibilityOf(element));
		Select select=new Select(element);
		String s="";
		int Indexvalue1;
		if(Textvalue!=null) {
			select.selectByVisibleText(Textvalue);
			childTest.log(Status.INFO," Select value : "+Textvalue);
		}
		else if (Textvalue!=null) {
			select.selectByValue(Textvalue);
			childTest.log(Status.INFO," Select value is : "+Textvalue);
		}
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	@SuppressWarnings("unused")
	public static void select_Dropdown_Value(String locType,String locValue ,String eleValue, String Textvalue) {
		element=identifyElement(locType, locValue);
		wait = new WebDriverWait (driver, 50); 
		wait.until(ExpectedConditions.visibilityOf(element));
		Select select=new Select(element);
		String s="";
		int Indexvalue1;
		if(Textvalue!=null) {
			select.selectByVisibleText(Textvalue);
			childTest.log(Status.INFO, eleValue + Textvalue);
		}
		else if (Textvalue!=null) {
			select.selectByValue(Textvalue);
			childTest.log(Status.INFO," Select value is : "+Textvalue);
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void drawBorder(WebDriver driver, String locType,String locValue){
		WebElement element_node = identifyElement(locType, locValue);
		//driver.findElement(By.xpath(xpath));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].style.border='3px solid red'", element_node);
	}

	public static void selectDropdown(String xpath, String input)
	{
		wait=new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
		Select objSelect = new Select(driver.findElementByXPath(xpath)); //dropdown
		objSelect.selectByVisibleText(input);	
		System.out.println(xpath +" located with input :  " +input);
		childTest.log(Status.INFO," Select value is : "+input);
		//test.log(LogStatus.PASS, xpath+ "Dropdown selected");

	}

	public static void Select_PrintAllDropdown(String locType,String locValue) {
		//element=identifyElement(locType, locValue);
		Select select=new Select(identifyElement(locType, locValue)); 
		//driver.findElement(By.name(nameValue));
		List<WebElement> listt=select.getOptions();
		for (int i = 0; i < listt.size(); i++) {
			String allList=listt.get(i).getText();
			childTest.log(Status.INFO," Dropdown values are Below: ");
			childTest.log(Status.INFO, allList);
			System.out.println(" - "+allList);
		}



	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void scrollToElement(String xpath) {
		JavascriptExecutor js = (JavascriptExecutor) driver;	
		wait = new WebDriverWait (driver, 15); 

		//This will scroll the page till the element is found		
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		//driver.findElementByXPath(xpath).click();
	}

	 public static void pause(Integer milliseconds){
		    try {
		    	
		        TimeUnit.MILLISECONDS.sleep(milliseconds);
		    } catch (InterruptedException e) {
		        e.printStackTrace();
		    }
		}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void refresh() {
		driver.navigate().refresh();
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	//Get Name of the last downloaded file in local folder.
	public static String selectLastDownloadedFile(String filepath) {
		String lastfileName = null;
		File uploadDirectory = new File(filepath);
		File[] downloadedFiles = uploadDirectory.listFiles();
		Arrays.sort(downloadedFiles, new Comparator<File>() {
			public int compare(File fileOne, File fileTwo) {
				return Long.valueOf(fileOne.lastModified()).compareTo(fileTwo.lastModified());
			}
		});
		for (File file : downloadedFiles) {
			if (file.isFile()) {
				lastfileName= file.getName();
				//System.out.println("Filename : "+file.getName());
				// upload file
			}
		}
		return lastfileName;
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void read_File_Data(File csvFile) {
		try {
			expRe = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new FileReader(csvFile));
			String line = "";
			StringTokenizer st = null;
			while ((line = br.readLine()) != null) {
				// use comma as token separator
				st = new StringTokenizer(line,",");
				while (st.hasMoreTokens()) {
					String sd = st.nextToken()+" ";
					if (sd != null) {
						expRe.add(sd);
					}
				}
			}
			System.out.print("Expected : "+expRe);
			System.out.println();
			childTest.log(Status.INFO," "+expRe);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void scrollINElement(String cssSelector,int yHeight) {
		EventFiringWebDriver eventFiringWebDriver=new EventFiringWebDriver(driver);
		eventFiringWebDriver.executeScript("document.querySelector('"+cssSelector+"').scrollTop="+yHeight+"");
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void scrollPageBy(int xDir,int yDir) {
		((JavascriptExecutor) driver).executeScript("window.scrollBy("+xDir+","+yDir+")");
	}

	/*
	 * Method : moveToElement
	 * The cursor is moving to the identifying element
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void movetoElement(String locType,String locValue,String elementValue) {
		try {
			element=identifyElement(locType, locValue);
			Actions actions=new Actions(driver);
			wait = new WebDriverWait (driver, 50); 
			wait.until(ExpectedConditions.visibilityOf(element));
			actions.moveToElement(element).build().perform();
			//childTest.log(Status.INFO, "Move to : "+elementValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	/*
	 * Method : assertion
	 * To used to compare expected and actual String values
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void assertion(String actual,String expected) {
		try {
			wait = new WebDriverWait (driver, 50); 
			wait.until(ExpectedConditions.visibilityOf(element));
			Assert.assertEquals(actual, expected);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String getTimeStamp() {
		String timestamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		return timestamp;
	}
	

	//'03/02/2021 22:50
	public static String getDateTime() {
		String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm").format(new Date());
		return timestamp;
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String getDateTime1day(int adddates) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		Date date = new Date();
		// System.out.println("Current Date " + dateFormat.format(date));

		Calendar c = Calendar.getInstance();
		c.setTime(date);

		c.add(Calendar.DATE, adddates);

		Date currentDatePlusOne1 = c.getTime();

		// System.out.println("Updated Date " + dateFormat.format(currentDatePlusOne1));

		return dateFormat.format(currentDatePlusOne1);

	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static String ISTtimeMinAdd(int min) {

		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Date date = new Date();
		// System.out.println("Current Date " + dateFormat.format(date));

		Calendar c = Calendar.getInstance();
		c.setTime(date);

		c.add(Calendar.MINUTE, min);

		Date currentDatePlusOne = c.getTime();

		System.out.println("Updated Date " + dateFormat.format(currentDatePlusOne));

		return dateFormat.format(currentDatePlusOne);
	}

	public static String ISTTime() {

		String timestamp = new SimpleDateFormat("HH:mm").format(new Date());
		return timestamp;

	}


	public static String DateStamp() {
		String timestamp = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		return timestamp;

	}
	//07-01-2021

	public static String getDateStamp() {
		String datestamp = new SimpleDateFormat("ddhhmmss").format(new Date());
		return datestamp;
	}

	public static String calenderTime() {
		//'01/13/2021 11:04
		String datestamp = new SimpleDateFormat("MM/dd/yyyy hh:mm").format(new Date());
		return datestamp;
	}

	public static String NextcalenderTime() {
		//09-20-2020  05:28:00
		String datestamp = new SimpleDateFormat("MM/dd"+1+"/yyyy  hh:mm:ss").format(new Date());
		return datestamp;
	}



	public static LocalDate findNextDay(LocalDate localdate)
	{

		return localdate.plusDays(1);

	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void typeDateTIMEIntheCalendar1(String locType,String locValue,Calendar calendar) {   //8/4/2020 9:46 AM
		try {
			WebElement datefield=identifyElement(locType, locValue);
			pause(1000);
			JavascriptExecutor js= (JavascriptExecutor)driver;
			js.executeScript("arguments[0].value='"+calendar+"';", datefield);
			pause(7000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void typeDateTIMEIntheCalendar(String locType,String locValue,String valueDate) {   //8/4/2020 9:46 AM
		try {
			WebElement datefield=identifyElement(locType, locValue);
			pause(1000);
			JavascriptExecutor js= (JavascriptExecutor)driver;
			js.executeScript("arguments[0].value='"+valueDate+"';", datefield);
			pause(7000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void uploadFileAutoit(String Filepath) {
		autoitExe=System.getProperty("user.dir")+"\\autoit\\autoit.exe";
		try {
			pb=new ProcessBuilder(autoitExe,Filepath);
			pb.start();	
			childTest.log(Status.INFO, "Uploaded Filepath :  "+Filepath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void uploadFileAutoit(String autoitExe,String Filepath) {
		//autoitExe=System.getProperty("user.dir")+"\\autoit\\autoit.exe";
		try {
			pb=new ProcessBuilder(autoitExe,Filepath);
			pb.start();	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void readXMLFile(String xmlFilePath,String ElementsByTagName,String ElementsAttribute) {
		try{
			String filePath = xmlFilePath;
			//System.getProperty("user.dir")+"\\TestData\\LabelsAndLanguages.xml";
			File file = new File(filePath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbf.newDocumentBuilder();
			Document doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println(doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName(ElementsByTagName);
			int tLength = nodeList.getLength();
			for(int i=0; i<tLength; i++){
				Node node = nodeList.item(i);
				if(node.getNodeType()==Node.ELEMENT_NODE){
					Element element = (Element)node;
					System.out.println(ElementsByTagName+" : "+element.getAttribute(ElementsAttribute));
					childTest.log(Status.INFO, ElementsByTagName+" : "+element.getAttribute(ElementsAttribute));
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void zipFile(String filePath) {
		try {
			File file = new File(filePath);

			String zipFileName = file.getName().concat(".zip");
			// String zipFileName = file.getName();
			FileOutputStream fos = new FileOutputStream(zipFileName);
			ZipOutputStream zos = new ZipOutputStream(fos);

			zos.putNextEntry(new ZipEntry(file.getName()));

			byte[] bytes = Files.readAllBytes(Paths.get(filePath));
			zos.write(bytes, 0, bytes.length);
			zos.closeEntry();
			zos.close();

		} catch (FileNotFoundException ex) {
			System.err.format("The file %s does not exist", filePath);
		} catch (IOException ex) {
			System.err.println("I/O error: " + ex);
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void readDownloadLastFile() throws InterruptedException {
		pause(15000);
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String lastDownloadFile=selectLastDownloadedFile(downloadPath);
		System.out.println("selectLastDownloadedFile : "+lastDownloadFile);
		childTest.log(Status.INFO,"Downloaded File : " +lastDownloadFile);
		pause(7000);
		childTest.log(Status.INFO,"Downloaded Filepath : "+downloadPath+lastDownloadFile);
		System.out.println(downloadPath+lastDownloadFile);

		read_File_Data(new File(System.getProperty("user.dir")+"\\Downloads\\"+lastDownloadFile));
		pause(5000);

	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void ExcludedVInsPOpup() {
		try {
			movetoElement(LocType.xpath, "//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]","Excluded vins popup " );
			pause(2000);
			click(LocType.xpath, "//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]","Excluded vins popup - YES" );
			pause(4000);
			System.out.println("VinExclusionConfirmationDialog - 2");	
		} catch (Exception e) {
			System.out.println("No VIN exclusive Vin's");
		}

	}

	//Sneha
	public static void enterText1(String xpath, String input, String button) throws IOException {
		String[] namesplit = xpath.split("'");
		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;

		try	{

			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));	
			driver.findElementByXPath(xpath).sendKeys(input);
			isPresent = true;

			System.out.println(xpath+"   found,  Entered values: "+input );
			childTest.log(Status.INFO,"found,  Entered values: "+button );
			//test.log(LogStatus.PASS,"Text Entered in "+button, "Entered values: "+input);
		}
		catch(Exception e){
			System.out.println(xpath+"   not found");

			childTest.log(Status.INFO,"Text not Entered in : Entered values failed: " +button);
			//test.log(LogStatus.FAIL, "Text not Entered in "+button, "Entered values failed: "+input);

		}
	}

	public static void enterText(String xpath ,String eleValue, String input) throws IOException {
		String[] namesplit = xpath.split("'");
		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;

		try	{

			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));	
			driver.findElementByXPath(xpath).sendKeys(input);
			isPresent = true;
			System.out.println(eleValue+input );
			childTest.log(Status.INFO, eleValue +" : " +input );
			//test.log(LogStatus.PASS,"Text Entered in "+button, "Entered values: "+input);
		}
		catch(Exception e){
			System.out.println(xpath+"   not found");

			childTest.log(Status.INFO,"Text not Entered in : Entered values failed: " +input);
			//test.log(LogStatus.FAIL, "Text not Entered in "+button, "Entered values failed: "+input);

		}
	}


	public static void btnClick(String xpath, String button) throws IOException {
		//		String[] namesplit = xpath.split("'");
		//		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try	{

			WebDriverWait wait = new WebDriverWait (driver, 30); 
			//wait.until(ExpectedConditions.svisibilityOfElementLocated(By.xpath(xpath)));
			movetoElement(LocType.xpath, xpath, button);
			driver.findElementByXPath(xpath).click();
			System.out.println(button+"   clicked");
			isPresent = true;	
			childTest.log(Status.PASS," Click on  "+button);
			//childTest.addScreenCaptureFromPath(captureScreen());
			//test.log(LogStatus.PASS, button +" button has been clicked");
		}
		catch(Exception e){
			isPresent = false;
			System.out.println(button+"  not found");
			childTest.log(Status.FAIL,"Unable Click on  : "+button);
			childTest.addScreenCaptureFromPath(captureScreen());
			//childTest.log(Status.INFO," unable to Click on  "+button);
			//test.log(LogStatus.FAIL, button+ "Element not found"+test.addScreenCapture(BaseClass.captureScreen()));

		}


	}

	public static void btnClick_link(String xpath,String elementValue) throws IOException {
		//		String[] namesplit = xpath.split("'");
		//		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try	{

			WebDriverWait wait = new WebDriverWait (driver, 30); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(xpath)));
			//driver.findElement(By.linkText(xpath)).click();
			driver.findElementByLinkText(xpath).click();
			System.out.println(xpath+"   clicked");
			isPresent = true;
			childTest.log(Status.PASS," Click on  "+elementValue);
			//test.log(LogStatus.PASS,"Button Clicked in "+xpath);
		}
		catch(Exception e){
			isPresent = false;
			System.out.println(xpath+"  not found");
			childTest.log(Status.INFO,"Unable Click on  "+elementValue);
			//test.log(LogStatus.FAIL, xpath+ " Element not found");

		}
	}

	public static void btnClick_link(String xpath) throws IOException {
		//		String[] namesplit = xpath.split("'");
		//		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try	{

			WebDriverWait wait = new WebDriverWait (driver, 30); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(xpath)));
			//driver.findElement(By.linkText(xpath)).click();
			driver.findElementByLinkText(xpath).click();
			System.out.println(xpath+"   clicked");
			isPresent = true;	
			//test.log(LogStatus.PASS,"Button Clicked in "+xpath);
		}
		catch(Exception e){
			isPresent = false;
			System.out.println(xpath+"  not found");
			//test.log(LogStatus.FAIL, xpath+ " Element not found");

		}
	}

	public static void getTextFromElement_1(String xpath, String expected) throws InterruptedException 
	{		
		try {
			boolean isPresent = false;

			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			WebElement web = driver.findElementByXPath(xpath);
			String text= web.getText();
			System.out.println("The text is "+text);
			//test.log(LogStatus.PASS, "the text is :" +text);
			isPresent = true;

			try {
				Assert.assertEquals(text, expected);
				childTest.log(Status.INFO, text+ " and " +expected+" results are matched");
				//.log(LogStatus.PASS, text+ " and " +expected+" results are matched");
			}
			catch(Exception e) {
				//test.log(LogStatus.PASS, text+ " and " +expected+" results are not matched");	
			}

		}		
		catch(Exception e) {
			System.out.println("Text not found");
			//test.log(LogStatus.FAIL, xpath+ "Not found");

		}
	}

	public static void datePicker(String input, String xpath) throws InterruptedException {
		try {

			WebElement datefield = driver.findElement(By.xpath(xpath));
			Thread.sleep(1000);
			JavascriptExecutor	js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].value='"+input+"'", datefield);
			System.out.println(datefield);
			/* WebElement datefield = driver.findElement(By.xpath("//div[@class='input-group datetime']/input"));
        Thread.sleep(1000);
        JavascriptExecutor js= (JavascriptExecutor)driver;
        js.executeScript("arguments[0].value='06/04/2020 09:42';", datefield);
        System.out.println(datefield);*/

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void selectDropdown(String xpath, String eleValue, String input)
	{
		try {

			WebDriverWait wait=new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			Select objSelect = new Select(driver.findElementByXPath(xpath)); //dropdown
			objSelect.selectByVisibleText(input);	
			System.out.println(eleValue+input);
			//test.log(LogStatus.PASS, button+ "  Dropdown selected");
			childTest.log(Status.INFO,eleValue+input);
		}
		catch(Exception e)
		{
			System.out.println(eleValue+"   not selected");
			//test.log(LogStatus.FAIL, button+ "Element not selected");		
		}
	}

	public static void findElement(String xpath, String button) throws IOException {
		//		String[] namesplit = xpath.split("'");
		//		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try	{

			WebDriverWait wait = new WebDriverWait (driver, 30); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath);
			System.out.println(button+"   found");
			isPresent = true;	
			//test.log(LogStatus.PASS,button+ " element has been found  ");
		}
		catch(Exception e){
			isPresent = false;
			System.out.println(button+"  not found");
			//test.log(LogStatus.FAIL, button+ " element not found");

		}	
	}


	public static void ClearText(String xpath) throws IOException {
		//			String[] namesplit = xpath.split("'");
		//			String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;
		try	{

			WebDriverWait wait = new WebDriverWait (driver, 15); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
			driver.findElementByXPath(xpath).clear();
			System.out.println(xpath+"   cleared");
			isPresent = true;	
			//test.log(LogStatus.PASS,"cleared in "+xpath);
		}
		catch(Exception e){
			isPresent = false;
			System.out.println(xpath+"  not cleared");
			//test.log(LogStatus.FAIL, xpath+ "Element not found");

		}	
	}

	public static void getTextFromElement(String xpath, String button) throws InterruptedException 
	{		
		/*String[] namesplit = xpath.split("'");
			String sname= namesplit[namesplit.length - 2];*/
		try {
			boolean isPresent = false;


			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			WebElement web = driver.findElementByXPath(xpath);
			String  text= web.getText();
			System.out.println("The text from " +button+ " is "+text);
			isPresent = true;
			childTest.log(Status.INFO,"The text from " +button+ " is :  "+text);
			//test.log(LogStatus.PASS, "the text is :" +text);
		}		
		catch(Exception e) {
			System.out.println("Text not found");
			//test.log(LogStatus.FAIL, button+ "Not found");

		}
	}

	protected static File getLatestFilefromDir(String dirPath){
		String path = "";

		File dir = new File(dirPath);
		File[] files = dir.listFiles();

		Arrays.sort(files, new Comparator<File>() {
			public int compare(File f1, File f2) {
				return Long.valueOf(f2.lastModified()).compareTo(
						f1.lastModified());
			}
		});

		for (int index = 0; index < files.length; index++) {
			// Print out the name of files in the directory
			String lastfileName=files[0].getName();
		}
		return dir;
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void read_CSV_Total_File(File csvFile) {
		try {
			expRe = new ArrayList<String>();
			//File csvFile = new File("C:\\Users\\z028979\\Downloads\\Custom Settings Configuration (Descmo).csv");
			BufferedReader br = new BufferedReader(new FileReader(csvFile));
			String line = "";
			StringTokenizer st = null;
			while ((line = br.readLine()) != null) {
				// use comma as token separator
				st = new StringTokenizer(line,",");
				while (st.hasMoreTokens()) {
					String sd = st.nextToken()+" ";
					if (sd != null) {
						expRe.add(sd);
					}
				}
			}
			System.out.print("Expected : "+expRe);
			System.out.println();
			childTest.log(Status.INFO," "+expRe);
			//   test.log(LogStatus.INFO," "+expRe);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
		 public static void uploadfile(String filepath, String inputFilePath, String doc) throws FindFailed {	       
		        Screen s = new Screen();
		        Pattern fileInputTextBox = new Pattern(filepath + "FileTextBox.PNG");
		        Pattern openButton = new Pattern(filepath + "OpenButton.PNG");
		        WebDriver driver;

		       // Click on Browse button and handle windows pop up using Sikuli
		       //driver.findElement(By.xpath(".//*[@id='photoimg']")).click();
		        //s.wait(fileInputTextBox, 20);
		        s.type(fileInputTextBox, inputFilePath + doc);
		        s.click(openButton);

		        // Close the browser
		        //driver.close();
		    }
	 *//*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void getSwitchWindow(int windowIndex) {
		String mainWin=driver.getWindowHandle();
		Set<String> wins=driver.getWindowHandles();
		List<String> winslist=new ArrayList(wins);
		driver.switchTo().window(winslist.get(windowIndex));
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void javaScriptClick(String locType,String locValue,String value) {
		try {
			element=identifyElement(locType, locValue);
			wait = new WebDriverWait (driver, 50); 
			wait.until(ExpectedConditions.visibilityOf(element));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", element);
			System.out.println(locValue + " : Clicked");
			childTest.log(Status.INFO, "click on "+ value);
			//test.log(LogStatus.PASS," Clicked on Element "+locValue);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to perform click on : "+locType+" : " + locValue);
			//test.log(LogStatus.FAIL, locValue+ "Element not found");
		}
	}
	/*
	 * Method : 
	 * Developed by Rakesh GM
	 * Date : 1-12-2020
	 */
	public static void closeDriverr() {
		if(driver!=null) {
			driver.close();
		}
	}

	public void enterTextSecure(String xpath, String button,  String input) throws IOException {
		String[] namesplit = xpath.split("'");
		String sname= namesplit[namesplit.length - 2];
		boolean isPresent = false;

		try	{

			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));	
			driver.findElementByXPath(xpath).sendKeys(input);
			isPresent = true;
			System.out.println(xpath+"   found");
			childTest.log(Status.PASS, "Text Entered in : "+button);
			//test.log(LogStatus.PASS,"Text Entered in "+button);
		}
		catch(Exception e){
			System.out.println(xpath+"   not found");
			childTest.log(Status.FAIL, "Text not Entered in  : "+button); 
			//test.log(LogStatus.FAIL, "Text not Entered in "+button);

		}
	}
public void CompareText(String xpath, String TextToBeCompared, String button) throws IOException {
		
		boolean isPresent = false;
		
		try	{
			WebDriverWait wait=new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
			String gotText = driver.findElementByXPath(xpath).getText();
		
			if(gotText.equalsIgnoreCase(TextToBeCompared)) {
				childTest.log(Status.PASS,"Actual Text: "+gotText+ " and  Expected Text: " +TextToBeCompared+ " are Matched");	
			}
			else {
				childTest.log(Status.FAIL,gotText+ " and " +TextToBeCompared+ " not matched ");
				childTest.addScreenCaptureFromPath(captureScreen());
			}
		}
		catch(Exception e){
			isPresent = false;
			childTest.log(Status.FAIL,"Element "+button+" not found");
			childTest.addScreenCaptureFromPath(captureScreen());
			
		}
}
public boolean findElementPassIfNotFound(String xpath, String button) throws IOException {
//	String[] namesplit = xpath.split("'");
//	String sname= namesplit[namesplit.length - 2];
	boolean isPresent = false;
	try	{
		
		WebDriverWait wait = new WebDriverWait (driver, 30); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		driver.findElementByXPath(xpath);
		System.out.println(button+"   found");
		isPresent = true;	
		childTest.log(Status.FAIL,button+ " element has been found  ");
	}
	catch(Exception e){
		isPresent = false;
		System.out.println(button+"  not found");
		childTest.log(Status.PASS, button+ " element not found");
		
	}
	return isPresent;	
}
}
