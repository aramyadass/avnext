package CampaignPortal_Auto;

import java.io.File;
import java.io.IOException;

import org.apache.xpath.compiler.PsuedoNames;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

//import com.relevantcodes.extentreports.LogStatus;

import AdminPortal_Auto.AdminPortal;
import CampaignPortal_Auto.BaseClass;
import CampaignPortal_Pages.Pages1;
import CampaignPortal_Pages.Pages_NR_VinExclusion;


public class NR_VinExclusion extends ReUsableMethods {
	
	static String file=System.getProperty("user.dir")+"\\TestData\\CampaignPortal_75.xlsx";
	static String vinSIT;
	static String vinSTG;
	
	
	@Test(priority = 0)
	public static void loginwithMicrosoft() throws InterruptedException, IOException {
		enterUrl(AdminPortal.campaignPortal_URL);
		AdminPortal.LoginwithMicrosoft(AdminPortal.user);
	}
	
	@Test(priority=1)
	public static void VinExclusion_click_95625() throws InterruptedException, IOException
	{
		
		enterUrl(AdminPortal.campaignPortal_URL);
		
		pause(7000);
		btnClick_link("VINs Exclusion List");
		childTest.log(Status.INFO, "Click on : VINs Exclusion List");
		childTest.addScreenCaptureFromPath(captureScreen());
		pause(5000);
	}
	
	
	@Test(priority=2)
	public static void VinExclusion_CreateVIN_95626() throws InterruptedException, IOException
	{
		vinSTG="VF1AG000261709353";
		vinSIT="VINFAKE0021022019";
		
		enterUrl(AdminPortal.campaignPortal_URL);	
		btnClick_link("VINs Exclusion List");
		childTest.log(Status.INFO, " Click on :  VINs Exclusion List");
		btnClick(Pages_NR_VinExclusion.Ex_AddVins, "AddVins");
		pause(10000);
		selectDropdown(Pages_NR_VinExclusion.Ex_txtBrand," Brand :  ", "RENAULT");

		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			enterText(Pages_NR_VinExclusion.Ex_Value, "VIN :  ",vinSIT );	
		} 
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			enterText(Pages_NR_VinExclusion.Ex_Value, "VIN :  ",vinSTG );
		}
	//	enterText(Pages_NR_VinExclusion.Ex_Value, "VIN :  ",vin );
		enterText(Pages_NR_VinExclusion.Ex_Reason," Reason :  ", "ExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInExclusionVInVInExclusionVInExclusionVInExclusionVInExclusionVIn ");
		pause(2000);
		btnClick(Pages_NR_VinExclusion.Ex_save,"SAVE");
		
		findElement(Pages_NR_VinExclusion.Ex_ReasonErr_Ok, "Ex_ReasonErr_Conifrm_OK");
		
		childTest.addScreenCaptureFromPath(captureScreen());
	
		btnClick(Pages_NR_VinExclusion.Ex_ReasonErr_Ok,"ExReasonErr - Ok");
		ClearText(Pages_NR_VinExclusion.Ex_Reason);
		pause(3000);
		btnClick(Pages_NR_VinExclusion.Ex_save,"SAVE");
		
		WebElement getVIN=identifyElement(LocType.xpath,Pages_NR_VinExclusion.Ex_GetVinValue_1);
		childTest.log(Status.INFO, " Get VIN :  "+getVIN.getText());
		childTest.log(Status.INFO, " VIN created");
		childTest.addScreenCaptureFromPath(captureScreen());
	//	test.log(LogStatus.PASS, "Created one VIN exclusion" +test.addScreenCapture(BaseClass.captureScreen()));
	//	btnClick(Pages_NR_VinExclusion.Ex_save);
		pause(2000);
	}
	
	@Test(priority=3)
	public static void VinExclusion_Filter_95628() throws InterruptedException, IOException
	{
		enterUrl(AdminPortal.campaignPortal_URL);
		pause(2000);	
		btnClick_link("VINs Exclusion List");
		childTest.log(Status.INFO, "Click on : VINs Exclusion List ");
		pause(10000);	
		
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			enterText(Pages_NR_VinExclusion.Ex_TextboxVin, "VIN  :  ",vinSIT);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			enterText(Pages_NR_VinExclusion.Ex_TextboxVin, "VIN  :  ",vinSTG);
		}
		
		
		//enterText(Pages_NR_VinExclusion.Ex_TextboxVin, "VIN  :  ",vin);
		
		btnClick(Pages_NR_VinExclusion.Ex_Apply, " APPLY Button");
		
		childTest.log(Status.INFO," VIN filter applied ");
		childTest.addScreenCaptureFromPath(captureScreen());
		
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			getTextFromElement_1(Pages_NR_VinExclusion.Ex_GetVinValue_1, vinSIT);
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			getTextFromElement_1(Pages_NR_VinExclusion.Ex_GetVinValue_1, vinSTG);
		}
		
		
		pause(2000);
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			btnClick(Pages_NR_VinExclusion.Ex_SelectCheckbox, vinSIT +" - Checkbox");
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			btnClick(Pages_NR_VinExclusion.Ex_SelectCheckbox, vinSTG +" - Checkbox");
		}
		
		//btnClick(Pages_NR_VinExclusion.Ex_SelectCheckbox, vin +" - Checkbox");
		pause(4000);
		/*
		btnClick(Pages_NR_VinExclusion.Ex_Delete,"DELETE Button");
		pause(4000);
		btnClick(Pages_NR_VinExclusion.Ex_DeleteErr_No,"DELETE Error");
		//test.log(LogStatus.PASS, "VIN not deleted"+test.addScreenCapture(BaseClass.captureScreen()));
		getTextFromElement_1(Pages_NR_VinExclusion.Ex_GetVinValue_1, vin);
		*/
		btnClick(Pages_NR_VinExclusion.Ex_Delete,"DELETE Button");
		pause(2000);
		btnClick(Pages_NR_VinExclusion.Ex_Delete_Yes,"Delete_Yes Button");
		
		if (AdminPortal.campaignPortal_URL.contains("sit")) {
			childTest.log(Status.INFO,vinSIT + " -  VIN Deleted ");
		}
		else if (AdminPortal.campaignPortal_URL.contains("stg")) {
			childTest.log(Status.INFO,vinSTG + " -  VIN Deleted ");
		}
		
		//childTest.log(Status.INFO,vin + " -  VIN Deleted ");
		childTest.addScreenCaptureFromPath(captureScreen());
		findElement(Pages_NR_VinExclusion.Ex_NoData, "Ex_NoData");
		//test.log(LogStatus.PASS, "VIN deleted"+test.addScreenCapture(BaseClass.captureScreen()));
	}
	
	@Test(priority=4)
	public static void VinExclusion_CreateCampaign_95627() throws InterruptedException, IOException
	{
		refresh();
		enterUrl(AdminPortal.campaignPortal_URL);
		String campaignName=excel(file,7,1,1)+getTimeStamp();
		pause(7000);	
		click(LocType.linkText, "Campaigns", "Campaigns");
		//driver.findElementByLinkText("Campaigns").click();
		pause(5000);
		btnClick(Pages1.New, "New Button" );
		Thread.sleep(5000);
		enterText(Pages1.Campaign_Title," CampaignName :  ",campaignName);
		selectDropdown(Pages1.SelectBrand, " Brand :  ","RENAULT");
		selectDropdown(Pages1.SelectCampaignType, " CampaignType :  ","Inventory");
		pause(4000);
		enterText(Pages1.Campaign_Vin, " Vin Value :  ",excel(file,7,2,1));
		btnClick(Pages1.Save_Campaign," Save Button");
		pause(5000);
		
		
		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();
		
		/*
		pause(7000);
		getLatestFilefromDir(System.getProperty("user.dir")+"\\Downloads");
		pause(5000);
		movetoElement(LocType.xpath, "//*[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]","Excluded VINs - YES");
		btnClick("//*[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]","Excluded VINs - YES");
		*/
		
	//	pause(7000);
		click(LocType.xpath,"//td[.='"+campaignName+"']//parent::td//preceding::td[1]", "campaign - checkbox");
		//driver.findElementByXPath("//input[@data-campname='"+campaignName+"']").click();
		System.out.println("Found checkbox");
		btnClick(Pages1.Run_Campaign,"Run Button");
		
		//pause(4000);
		//childTest.log(Status.INFO," Error message for no run of campaigns with excluded vins - ");
		/*
		btnClick("//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[2]","Excluded vins - YES");
		childTest.addScreenCaptureFromPath(captureScreen());
		//test.log(LogStatus.PASS, "Error message for no run of campaigns with excluded vins"+test.addScreenCapture(BaseClass.captureScreen()));
		pause(5000);
		btnClick("//div[@id='MessageModalCampList']/div/div/div[2]/div/button","MessageModalCampList - OK button");
		pause(8000);
		
		btnClick("//input[@data-campname='"+campaignName+"']","Campaign Checkbox");
		pause(2000);
		btnClick(Pages1.Run_Campaign,"Run Button");
		pause(2000);
		btnClick("//div[@id='VinExclusionConfirmationDialog']/div/div/div[2]/div/button[1]"," Confirmation Dialog - YES button");
		
		pause(7000);
		driver.navigate().refresh();
		*/
		//ExcludedVInsPOpup
		//ExcludedVInsPOpup();
		
		pause(7000);
		
		DTA_SendKeys(LocType.xpath, "//input[@id='txtCampaignName']", "CampaignName :  ", campaignName);
		pause(2000);
		click(LocType.xpath, "//div[@id='campaigns']/div/div[2]/div/div[5]/div/div/button", "Apply Button");
		WebElement ongoing1=identifyElement("//td[.='"+campaignName+"']//following-sibling::td[7]/label","Ongoing");
		childTest.log(Status.INFO, "Campaign Status : "+ongoing1.getText());
		//childTest.log(Status.INFO," Campaign in Ongoing status ");
		childTest.addScreenCaptureFromPath(captureScreen());
		//test.log(LogStatus.PASS, "Campaign in Ongoing status"+test.addScreenCapture(BaseClass.captureScreen()));
		pause(2000);
	}
}
